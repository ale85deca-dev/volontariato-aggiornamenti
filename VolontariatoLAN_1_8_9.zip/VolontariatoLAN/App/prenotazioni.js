'use strict';
const transportPurposes=['Visita','Trasferimento','Dimissione','Altro'];
let bookingArchiveView='pending';
const bookingTypeField=schemas.bookings.find(f=>f.key==='type');
bookingTypeField.bookingCategory=true;
schemas.bookings.splice(schemas.bookings.indexOf(bookingTypeField)+1,0,F('transportPurpose','Tipologia','select',{options:transportPurposes,required:true,transportOnly:true}));
const plannedEndField=schemas.bookings.find(f=>f.key==='end');
schemas.bookings.splice(schemas.bookings.indexOf(plannedEndField),1,F('visitAt','Orario visita','datetime-local',{transportVisit:true}));
schemas.bookings.splice(schemas.bookings.findIndex(f=>f.key==='vehicleId'),0,{...plannedEndField,transportScheduleEnd:true,label:'Fine prevista servizio',help:'Serve a riservare mezzo ed equipaggio. Alla chiusura indica la fine effettiva.'});
const beforeTransportFields=formFields;
formFields=function(fields,record={}){return fields.map(f=>{
 const transport=record.type==='Trasporto sanitario';
 if(f.bookingCategory&&transport)return '<input type="hidden" name="type" value="Trasporto sanitario">';
 if(f.transportOnly&&!transport)return '';
 if(f.transportVisit){if(!transport)return beforeTransportFields([plannedEndField],record);const visit=record.transportPurpose==='Visita';return beforeTransportFields([{...f,required:visit}],record).replace('<label ',`<label data-transport-visit ${visit?'':'hidden'} `);}
 if(f.transportScheduleEnd&&!transport)return '';
 if(f.key==='status'&&f.label==='Stato prenotazione'&&transport)return beforeTransportFields([{...f,options:['Prenotata','Completata','Annullata']}],record);
 return beforeTransportFields([f],record);
}).join('');};
function updateVisitField(form){if(!form||form._table!=='bookings'||form._record.type!=='Trasporto sanitario')return;const visit=form.elements.transportPurpose.value==='Visita',input=form.elements.visitAt,label=form.querySelector('[data-transport-visit]');if(label)label.hidden=!visit;if(input){input.required=visit;input.disabled=!visit;}const end=form.elements.end;const completing=form.elements.status.value==='Completata';if(end?.closest){const label=end.closest('label');if(label){const node=label.firstChild;if(node?.nodeType===3)node.textContent=(completing?'Fine effettiva servizio':'Fine prevista servizio')+' *';}}for(const key of ['patientId','vehicleId','origin','destination'])if(form.elements[key])form.elements[key].required=completing;const save=form.querySelector('[type="submit"]');if(save)save.textContent=completing?'Salva e completa servizio':'Salva prenotazione';}
const beforeTransportDefaults=newDefaults;
newDefaults=function(table){const r=beforeTransportDefaults(table);if(table==='bookings')r.transportPurpose='Visita';return r;};
const beforeTransportEdit=edit;
edit=function(table,id,override){let r=override||(id?state.tables[table]?.find(x=>x.id===id):undefined);if(table==='bookings'&&(r?.type||'Trasporto sanitario')==='Trasporto sanitario'){
 r={...(r||newDefaults(table))};r.transportPurpose=r.transportPurpose||'Visita';r.visitAt=r.visitAt||(r.transportPurpose==='Visita'?r.end||'':'');
 if(['Confermata','In corso'].includes(r.status))r.status='Prenotata';
 }
 if(table==='bookings'&&r&&r.type!=='Trasporto sanitario')r={...r,transportPurpose:'',visitAt:''};
 beforeTransportEdit(table,id,r);
 if(table==='bookings'&&!isVolunteer()){const form=$('#record-form');if(!form)return;updateVisitField(form);form.addEventListener('change',()=>updateVisitField(form));const status=form.elements.status;if(!id&&status&&r?.type==='Trasporto sanitario'){status.innerHTML=options(['Prenotata','Annullata'],r.status||'Prenotata',false);updateVisitField(form);}}
};
const beforeTransportCollect=collect;
collect=function(form,fields,base={}){const transport=form._table==='bookings'&&(form._record?.type||base.type)==='Trasporto sanitario';const active=fields.filter(f=>!f.transportOnly||transport);let r=beforeTransportCollect(form,active,base);if(transport){r.type='Trasporto sanitario';r.transportPurpose=form.elements.transportPurpose.value;r.visitAt=r.transportPurpose==='Visita'?form.elements.visitAt.value:'';}else if(form._table==='bookings'){r.transportPurpose='';r.visitAt='';}return r;};
function bookingDocumentHTML(b){const p=state.tables.patients.find(x=>x.id===b.patientId),rows=[['Data e ora prenotazione',dt(b.bookedAt||b.createdAt)],['Servizio',b.type],['Tipologia',b.transportPurpose||''],['Orario carico',dt(b.start)],...(b.transportPurpose==='Visita'?[['Orario visita',dt(b.visitAt)]]:[]),['Stato prenotazione',b.status],['Descrizione',b.title],['Richiedente',b.requestor],['Telefono richiedente',b.requestorPhone],['Partenza',b.origin],['Destinazione',b.destination],['Ritorno',b.returnRoute],['Indicazioni carico',b.pickupDetails],['Fine prevista servizio',dt(b.end)],['Automezzo',b.vehicleId?refName('vehicles',b.vehicleId):'Da assegnare'],['Equipaggio',(b.crewIds||[]).map(id=>refName('volunteers',id)).join(', ')||'Da assegnare'],['Note',b.notes]];
 return `<article class="document"><div class="document-top"><div>${issuerLines(state.settings).map(x=>`<div>${E(x)}</div>`).join('')}</div><div><h1>Foglio prenotazione</h1><div>Rif. ${E(b.id.slice(0,8))}</div></div></div>${p?`<div class="payer"><strong>Persona assistita: ${E(p.surname+' '+p.name)}</strong><div>${E(p.address)} · ${E(p.city)} · ${E(p.phone)}</div></div>`:'<p>Persona assistita da completare.</p>'}<table><tbody>${rows.filter(([,value])=>value!==''&&value!=null).map(([label,value])=>`<tr><th>${E(label)}</th><td>${E(value)}</td></tr>`).join('')}</tbody></table><div class="print-signatures"><span>Firma operatore ____________________</span></div></article>`;
}
function previewBooking(id){const b=state.tables.bookings.find(x=>x.id===id);if(!b||isVolunteer())return;modal('Anteprima prenotazione','Documento ricavato dai dati salvati.',bookingDocumentHTML(b)+`<div class="form-foot">${btn('print-record','Stampa prenotazione',id,'bookings')}${btn('edit','Modifica prenotazione',id,'bookings')}${btn('close','Chiudi')}</div>`);}
const beforeTransportPrint=printRecord;
printRecord=function(table,id){if(table!=='bookings')return beforeTransportPrint(table,id);const b=state.tables.bookings.find(x=>x.id===id);if(b)printHTML(bookingDocumentHTML(b));};
function openBookingCompletion(id){if(!['admin','segreteria'].includes(state.user.role))return;const b=state.tables.bookings.find(x=>x.id===id&&!x.archived);if(!b||['Completata','Annullata'].includes(b.status))return;const trip=state.tables.trips.find(t=>tripHasBooking(t,id));if(trip){edit('trips',trip.id,{...trip,status:'Concluso'});return;}edit('bookings',id,{...b,status:'Completata'});}
function afterServiceSave(table,row,isNew){if(table==='bookings'&&isNew&&row.status==='Prenotata')previewBooking(row.id);if((table==='bookings'&&row.status==='Completata')||(table==='trips'&&row.status==='Concluso')){location.hash='#activities';render();toast('Servizio salvato nelle attività svolte.');}}
const beforeTransportRows=visibleRows;
visibleRows=function(){let rows=beforeTransportRows();if(page==='bookings'&&!isVolunteer()){if(bookingArchiveView==='pending')rows=rows.filter(r=>!['Completata','Annullata'].includes(r.status));return rows.sort((a,b)=>String(a.start||'').localeCompare(String(b.start||'')));}if(page==='activities')return rows.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.performedAt||'').localeCompare(String(b.performedAt||''))||String(a.id||'').localeCompare(String(b.id||'')));return rows;};
const beforeTransportGroups=activityCalendarGroups;
activityCalendarGroups=function(table,rows){const groups=beforeTransportGroups(table,rows);return table==='activities'?groups.sort((a,b)=>a.month.localeCompare(b.month)):groups;};
for(const table of ['bookings','activities']){const before=columns[table][0][1];columns[table][0][1]=r=>before(r)+(r.transportPurpose?'<small>'+E(r.transportPurpose)+'</small>':'');}
const beforeTransportArchive=renderArchive;
renderArchive=function(){beforeTransportArchive();if(page==='bookings'&&!isVolunteer())$('#main').insertAdjacentHTML('afterbegin',`<div class="filters" aria-label="Elenco prenotazioni"><button type="button" data-action="bookings-view" data-view="pending" ${bookingArchiveView==='pending'?'class="primary"':''}>Servizi prenotati da svolgere</button><button type="button" data-action="bookings-view" data-view="all" ${bookingArchiveView==='all'?'class="primary"':''}>Tutte le prenotazioni</button></div>`);};
const beforeTransportTable=renderTable;
renderTable=function(){beforeTransportTable();if(page!=='bookings'||isVolunteer())return;const box=$('#archive-table');if(!box)return;box.innerHTML=box.innerHTML.replace(/(<button data-action="edit" data-table="bookings" data-id="([^"]+)">Apri<\/button>)/g,(all,button,id)=>{const b=state.tables.bookings.find(x=>x.id===id);return button+btn('booking-preview','Anteprima prenotazione',id)+(b&&!b.archived&&!['Completata','Annullata'].includes(b.status)&&['admin','segreteria'].includes(state.user.role)?btn('booking-complete','Completa servizio',id):'');});};
document.addEventListener('click',ev=>{const b=ev.target.closest('[data-action]');if(!b)return;const action=b.dataset.action;if(action==='booking-preview')previewBooking(b.dataset.id);else if(action==='booking-complete')openBookingCompletion(b.dataset.id);else if(action==='bookings-view'){bookingArchiveView=b.dataset.view==='all'?'all':'pending';filter={...filter,status:''};renderArchive();}});
let bookingShiftDraft=null;
function bookingShiftWarning(record){bookingShiftDraft=structuredClone(record);let box=$('#booking-shift-warning');if(!box){$('#dialog-content .modal-body')?.insertAdjacentHTML('beforeend','<div id="booking-shift-warning" class="notice"></div>');box=$('#booking-shift-warning');}if(box)box.innerHTML='<strong>Appello di inizio turno da compilare</strong><p>Completa l’appello prima di salvare il servizio come svolto.</p>'+btn('booking-shift-rollcall','Compila appello',record.id);}
const beforeBookingShiftApi=api;
api=async function(path,body,binary=false){if(path==='save'&&body?.table==='bookings'&&body.record.status==='Completata'&&missingShiftCrew({...body.record,bookingId:body.record.id}).length){bookingShiftWarning(body.record);throw new Error('Compila l’appello di inizio turno con il pulsante di richiamo.');}try{return await beforeBookingShiftApi(path,body,binary);}catch(ex){if(path==='save'&&body?.table==='bookings'&&body.record.status==='Completata'&&ex.message?.startsWith('APPELLO_TURNO:'))bookingShiftWarning(body.record);throw ex;}};
function restoreBookingShiftDraft(id){if(!bookingShiftDraft||bookingShiftDraft.id!==id)return;const draft=bookingShiftDraft;bookingShiftDraft=null;const b=state.tables.bookings.find(x=>x.id===id);if(b)edit('bookings',id,{...draft,version:b.version,status:'Completata'});}
document.addEventListener('click',async ev=>{const b=ev.target.closest('[data-action="booking-shift-rollcall"]');if(!b||!bookingShiftDraft)return;try{const draft=bookingShiftDraft;const saved=await api('save',{table:'bookings',record:{...draft,status:'Prenotata'}});await load(false);bookingShiftDraft={...saved.result,status:'Completata'};showRollcall(saved.result.id);}catch(ex){toast(ex.message,true);}});
