# Registro delle richieste concordate

Aggiornato il 14 ottobre 2026. Prima di ogni nuova modifica confrontare la richiesta con questo registro e con i sorgenti; avvisare l'utente delle funzioni già presenti ed estendere quelle esistenti, evitando archivi duplicati.

“Implementato” indica presenza nei sorgenti e nel pacchetto. Non attesta collaudo del server: compilazione, installazione Windows 11, rete, mobile e posta reale restano da verificare sul sistema di destinazione.

| Richiesta | Stato e riferimento |
|---|---|
| Windows 11, rete locale, archivio centrale, funzionamento locale offline | Installatori/server inclusi; collaudo Windows e LAN da effettuare |
| Pazienti, volontari, paganti, automezzi, prenotazioni, viaggi, attività | Implementati; dati collegati per ID, storico e revisioni condivisi |
| Trasporto sanitario, assistenza evento, emergenza 118 | Implementati |
| Volontario da Android/iPhone: assegnazioni, appello, dati mancanti viaggio e chiusura | Implementati in PWA; accesso esterno richiede collegamento VPN da predisporre |
| Carburante: litri, importo, targa, km, aggiornamento mezzo/servizio/viaggio | Già implementato prima della versione 1.5; accesso dalla targa aggiunto in 1.5 |
| Checklist | Stand-by, disabilitata; resta distinta da pulizia/sanificazione |
| Tariffa aspecifica e prezzo composto da voci; totale viaggio senza IVA | Implementati; modifica solo amministratore |
| Documenti da amministratore e/o segreteria | Implementati; lettura e volontario esclusi |
| Singole private/strutture, Contanti/POS/Bonifico/Altro | Implementate; pagamento previsto distinto dall'incasso registrato |
| Cumulative per pagante e mese solare attività | Implementate; periodo intero, stessa data effettiva mese, 118 separato |
| Pagamento cumulativa a ricevimento fattura/documento 118 | Implementato |
| Archivio fatture per anno/mese attività, bozze separate | Implementato; emissione conservata separatamente |
| Numeri fatture e fogli viaggio indipendenti con richiamo reciproco | Implementati |
| Registrazioni dal 1 gennaio 2027, pregresso manuale | Implementato; archivi da svolgimento, inserimento registrato separatamente |
| Invio fatture per email manuale con PDF | Implementato; nessun invio reale in sviluppo; prova Windows/SMTP da fare |
| Casella mittente | Configurazione rinviata a gestionale ultimato, come richiesto |
| Email cumulative verso ente/associazione/struttura pagante | Archivio Soggetti paganti già include categoria/email; invio collegato in 1.5 |
| Email singola | Aggiornata il 9 ottobre: struttura a carico proposta, altrimenti persona assistita; scelta tra contatti collegati o email specifica modificabile anche senza email in anagrafica |
| Selezione targa con inserimenti carburante, manutenzione, pulizia, sanificazione | Aggiunto in 1.5; targa fissata nei moduli aperti dal mezzo |
| Archivio attività del mezzo | Già presente; in 1.5 pannello unico con registri separati, filtri svolgimento e CSV |
| Registri manutenzione/pulizia/sanificazione | Aggiunti in 1.5, condivisi; admin/segreteria gestiscono tutti i tipi, lettura consulta; in 1.6 volontari inseriscono pulizia e sanificazione da app |
| Alert assicurazione e revisione | Già presenti prima di 1.5; confermati e integrati nel pannello della targa |
| Alert bombole, estintori, ispezione sanitaria | Aggiunti in 1.5; 30 giorni predefiniti configurabili, scaduti/oggi/in scadenza |
| Bombole/estintori multipli sullo stesso mezzo | Scelta confermata: scheda per ogni bombola DI OSSIGENO ed estintore; implementata in 1.6 con trasferimenti e alert individuali |
| Scadenze manutenzione | Campi già presenti; aggiornamento manuale, avviso data/km raggiunti |
| Verificare sempre se una nuova richiesta è già stata fatta | Concordato il 7 ottobre 2026; questo registro conserva lo stato per le prossime modifiche |
| Registro pulizie sede e alert estintori sede | Aggiunti in 1.6; estintori individuali con identificativo e posizione |
| Magazzino sanitario con carico/scarico e scadenze | Aggiunto in 1.6: materiale e lotti, giacenza derivata, smaltimento scaduti, scorta minima, CSV |
| Prelievo di materiale singolo | Confermato il 7 ottobre 2026: scarico per materiale, lotto e quantita gia presente; kit prestabiliti non richiesti. |
| Alert scadenza revisione DAE nei mezzi | Aggiunto in 1.6, data manuale per targa e avvisi locali |
| Controllo generale rispetto al singolo inserimento | Rapporto del 7 ottobre 2026 riferito alla base 1.5; implementazioni proposte e limiti ancora aperti. In 1.6 corrette etichette targa, tipo pulsanti e sincronizzazione presenze |
| Permessi magazzino: carico/scarico admin e segreteria, solo scarico volontario da app | Confermato e implementato il 7 ottobre 2026 in 1.6: nuovi scarichi mobile, lotti disponibili e propri scarichi in consultazione; nessun carico o modifica materiali. Correzioni degli scarichi salvati riservate ad amministratore e segreteria, confermato il 7 ottobre 2026; mezzo/servizio facoltativi, servizio solo se assegnato |
| Scarico: targa consigliata e opzione Altro per destinazione non automezzo | Confermato il 7 ottobre 2026 e implementato in 1.6: scelta Automezzo/Altro, descrizione facoltativa di Altro. Targa mai obbligatoria per lo scarico, proposta dal servizio; singolo movimento conserva destinazione e aggiorna giacenza. La causale resta distinta dalla destinazione |
| Pulizia e sanificazione mezzi anche da app volontario | Confermato e implementato il 7 ottobre 2026: sezione mobile dedicata, inserimento targa/data/descrizione/prodotti/note, esecutore e operatore dal proprio account, archivio condiviso del mezzo. Solo propri interventi consultabili; manutenzioni alla sede, correzioni salvati impostate alla sede |
| Richiedente distinto dalla persona assistita e da chi versa | Confermato il 9 ottobre 2026: richiedente/telefono separati; versante facoltativo sull’incasso, nessun vincolo con intestazione |
| Anagrafica unica persona assistita, richiamo per nuova prenotazione | Archivio esistente rinominato Persone assistite, senza seconda tabella; ricerca per nome/CF, nuova prenotazione dalla scheda, inserimento guidato con richiamo di possibili schede esistenti. CF duplicato rifiutato dal server |
| Intestazione fattura singola dai dati della persona trasportata | Implementato il 9 ottobre 2026: snapshot persona, nessuna nuova scheda privata pagante necessaria; struttura a carico separata. Cumulative mantengono il soggetto a carico e la persona per ogni riga |
| Libertà di modifica destinatario email | Implementata il 9 ottobre: proposta struttura/paziente e indirizzo specifico per singolo invio, senza cambiare anagrafiche/intestazione; controlli e storico dell’indirizzo effettivo. Invio sempre manuale |
| Appello obbligatorio a inizio turno; richiamo se manca alla chiusura servizio | Implementato il 9 ottobre: inizio turno richiesto, presenze riutilizzate; appello equipaggio registra eventuali turni mancanti. Avviso Compila appello conserva il viaggio; chiusura verificata dal server |
| Distinzione pulizia interna/esterna/completa | Decisione rinviata dall’utente il 7 ottobre: descrizione libera attiva |
| Alert revisione barella e sedia per targa | Nuova richiesta del 9 ottobre 2026, non gia presente: due date distinte nella scheda automezzo, integrate con gli alert della panoramica, elenco mezzi e pannello targa. Anticipo configurato condiviso; nessun invio automatico |


Suggerimenti tutti autorizzati dall’utente il 9 ottobre 2026; implementati nella versione 1.7:

| Suggerimento | Realizzazione |
|---|---|
| Controllo servizi da fatturare | Vista derivata, bozze/verifiche; attività manuale convertibile mantenendo il proprio ID |
| Rettifiche e correzioni incassi | Note di credito collegate, serie NC, limiti/importi riservati, storni e rimborsi con storico |
| Prenotazioni ricorrenti | Anteprima, esclusioni, controllo conflitti, creazione atomica e riuso tariffe |
| Formazione volontari e ore | Più corsi/abilitazioni con scadenze e allegati; ore turno e servizio distinte |
| Mezzo fuori servizio | Periodo e motivo, blocco assegnazioni; risoluzione servizi aperti prima del fermo |
| Dotazioni individuali DAE/barella/sedia | Estensione dell’archivio esistente, trasferimenti e alert per dispositivo |
| Allegati | PDF/JPEG/PNG collegati alle schede, cifrati e inclusi nel backup; 32 MiB/file, 5 GiB totali |
| Libro soci e gestione economica | Soci collegabili a volontario, quote annue, donazioni, fornitori, spese/rimborsi e prima nota derivata |
| Rendiconti | Mese/anno/periodo, filtri mezzo/volontario/pagante/convenzione, CSV e PDF; costi e saldi con criteri dichiarati |
| Fusione doppioni pazienti | Confronto e conferma, riferimenti trasferiti, originali emessi conservati e storico |
| Attività con più servizi/persone/mezzi | Gruppo principale e servizi collegati; viaggio condiviso, chilometri una volta e fatture separate |
| Scadenza pagamento | Termine per documento e avvisi di residui scaduti in panoramica |
| Pagamento spese dei registri operativi | Collegamento alla sorgente carburante/cura mezzo/pulizia sede senza costi duplicati |

Controlli disponibili: 296 verifiche UI/modelli passate, sintassi JavaScript, PWA e verifica struttura pacchetto. Nuovi test C# inclusi ma non compilati/eseguiti in questo ambiente. Collaudo Windows/LAN/mobile/posta ancora necessario. Archivio centrale massimo 256 MiB; non è un sistema contabile generale né produce XML/SDI. Le scelte rinviate rimangono rinviate.


| Prima nota cassa | Richiesta del 9 ottobre 2026: prima nota generale già in 1.7; estesa in 1.7.1 con pannello contanti, apertura confermata, riporti mensili/annuali, saldo progressivo, CSV/PDF/stampa. Admin/segreteria gestiscono, lettura consulta, volontario escluso |
| Pagamenti parziali quote/spese in prima nota | Migliorati in 1.7.1: movimenti per differenza con date/modalità distinte; storico, storni motivati, correzione ultimo pagamento. Archiviazione delle schede non cancella il denaro registrato |

296 controlli UI/modelli superati. CashSelfTest aggiunto al collaudo dell’installatore, con dodici file C#; compilazione Windows e collaudo LAN restano da effettuare.

Aggiornamento 1.7.2 - 9 ottobre 2026, separazione flussi e voci di bilancio:

| Richiesta verificata | Esito |
| --- | --- |
| Contanti separati dagli elettronici | Contanti già disponibili in 1.7.1. Aggiunta Prima nota elettronica per POS e bonifici; prima nota generale con riepiloghi separati. Altro resta distinto, da classificare |
| Voci manuali conservate e riutilizzabili | Nuovo archivio Voci di bilancio, condiviso fra PC e incluso nel backup. Creazione nello stesso salvataggio della spesa/uscita, selezione successiva, rinomina e archiviazione. Doppioni per maiuscole/spazi evitati anche nelle creazioni simultanee |
| Report dei pagamenti per voce | Nuovo prospetto per periodo, con contanti/elettronici/Altro, totale netto storni, dettaglio e origine, CSV/PDF/stampa. Per data e importo effettivi dei pagamenti parziali; spese non pagate escluse |
| Dati precedenti senza voce | Esposti in Voce da assegnare. Nessuna classificazione dedotta dal testo; collegamento manuale sulla scheda di origine |

BudgetSelfTest incluso per voci, storni, riporti dei pagamenti nei mesi corretti, permessi, rollback e riavvio; non eseguito in questo ambiente. Corretto anche il richiamo dello storico pagamento nei moduli ufficio di quote/spese, che usano operational-form. Nessuna nuova domanda necessaria per questa richiesta; Altro resta separato finché definito dalla modalità effettiva.

Aggiornamento 1.8 - 9 ottobre 2026, tutte le integrazioni autorizzate:

| Richiesta | Realizzazione |
|---|---|
| Solo un conto | Un'apertura bancaria, riporti, movimenti derivati; nessun secondo conto |
| Giroconti | Un record con due effetti sui saldi; storno separato, fuori da ricavi/spese |
| POS e commissioni | Incassi da accreditare, selezione, accredito effettivo e commissioni distinte |
| Spese con più voci | Ripartizione fino a 30 quote; pagamenti parziali e storni quadrati |
| Preventivo | Anno/voce univoci, confronto con pagamenti per data, PDF/CSV |
| Turni | Disponibilità, indisponibilità, copertura richiesta, sostituzioni, sovrapposizioni e calendario notturno; appello distinto |
| Magazzino mezzi | Giacenze per sede/targa, trasferimenti senza consumo; volontario solo scarico |
| Importazione | CSV/XLSX, mappatura, anteprima, identificativi, nessuna sovrascrittura e lotto atomico |
| Capacità | Allegati separati cifrati 32 MiB/file e 5 GiB totali; metadati 256 MiB |
| Backup | .volbundle completo, verifica, ripristino, esterno giornaliero USB/NAS cifrato con esito/errori |
| Permessi | Operazioni ufficio admin/segreteria; backup admin; lettura consulta; mobile propri turni e scarichi |
| Richieste già presenti | Prima nota, anagrafiche e appello estesi tramite i collegamenti esistenti, senza archivi duplicati |

Verificati 296 controlli UI/modelli, sintassi JavaScript, PWA e integrità del
pacchetto. Dodici sorgenti C# e nuovi test nativi inclusi; compilazione ed
esecuzione Windows non disponibili qui. Collaudo reale su Windows/LAN,
telefoni/VPN, SMTP, backup e prestazioni da eseguire prima dell'uso operativo.
Configurare sul centrale destinazione backup, casella mittente e accesso remoto.
Le copie locali .dat richiedono la cartella Allegati originale. Il limite 5 GiB
è applicativo; prestazioni a pieno volume non misurate. Checklist in stand-by.

Correzione installazione - 14 ottobre 2026:
Segnalazione: "La riserva HTTPS 8765 esiste gia". Il precedente controllo
interpretava solo LASTEXITCODE di netsh: non consente da solo di confermare
la causa sul PC dell'utente. Ora query native esatte HTTPAPI (nessun parser
localizzato), riuso della riserva con identici permessi LocalService,
blocco conservativo per permessi diversi e binding SSL, rollback limitato
alle risorse create. Aggiunto helper C# HttpConfigurazione.cs per Add-Type;
non modifica i dodici sorgenti del server. Controllo statico/pacchetto qui;
compilazione ed esecuzione Windows restano da provare sul PC destinatario.

CORREZIONE SORGENTI C# - 14 OTTOBRE 2026, SECONDA REVISIONE
Risolti i due conflitti CS0136 segnalati durante la compilazione Windows:
- Completo.cs / BuildCredit: documento locale rinominato creditDocument,
  distinto dal parametro d delle espressioni LINQ.
- Importazione.cs / ImportRecord: campo data nel foreach rinominato
  dateField, distinto dalla chiave di importazione dell'attivita.
Resi distinti anche due parametri lambda in TextPdf e PaymentShares,
rispettivamente pageObjectId e allocationIndex. Solo rinomine locali:
logica e formato degli archivi invariati.
Controllo prudenziale dei nomi e integrita pacchetto eseguiti qui;
non equivale a compilazione. Compilatore Windows non disponibile qui.
Estrarre l'intero pacchetto aggiornato in una nuova cartella e rilanciare
InstallaServer.cmd. Se compare un altro errore, conservare il testo completo.

TEST REGISTRI MEZZO - 14 OTTOBRE 2026, TERZA REVISIONE
Il log ricevuto conferma compilazione riuscita nella seconda revisione
e successi delle verifiche fino al riavvio del registro automezzi.
Il test VehicleCareSelfTest selezionava vehicles[0], che dopo l'aggiornamento
di CARE01 era CARE02. Il test ora conserva e richiama l'ID di CARE01;
controlla anche l'altro mezzo invariato e identita/tipo/descrizione/costo
della manutenzione, piu pulizia e sanificazione riaperte sul mezzo corretto.
Nessuna verifica disattivata, nessuna modifica alla persistenza operativa.
Il collaudo esegue tutte le 14 suite indipendenti, riepiloga i blocchi falliti
e mantiene codice uscita 1 e installazione bloccata per qualsiasi errore.
Dopo fallimento tenta di conservare Collaudo-installazione.txt nella cartella
del pacchetto estratto prima del rollback della cartella di installazione.
La nuova revisione resta da eseguire su Windows; eventuali altri blocchi
falliti devono essere corretti prima dell'avvio del servizio.
Nel test successivo VehicleHygieneSelfTest separati i dati manipolati
per la prova mobile dai dati validi usati dalla segreteria. Il riferimento
fittizio "altro" resta nel test difensivo mobile; una nuova verifica
conferma il rifiuto dello stesso riferimento inesistente per la sede.
Gli inserimenti validi della sede richiamano il volontario di prova reale.

TEST DOTAZIONE SEDE/MEZZO - 14 OTTOBRE 2026, QUARTA REVISIONE
Il resoconto ricevuto della terza revisione conferma compilazione e
13 suite complete superate sul PC Windows; unico blocco in SiteSelfTest.
Nel test la dotazione restituita dal salvataggio veniva modificata
direttamente: vecchia e nuova assegnazione risultavano identiche al
confronto, quindi non veniva registrata la seconda voce dello storico.
Ora il test modifica una copia della scheda, come una richiesta proveniente
dall'interfaccia; la logica operativa del gestionale non e stata cambiata.
Aggiunte verifiche di sede/data iniziali, trasferimento/mezzo/data, note
che conservano lo storico, rifiuto di data cambiata senza trasferimento
e persistenza di assegnazione/storico/scadenza estintore dopo il riavvio.
Nessun controllo eliminato. La quarta revisione va ancora eseguita su Windows.

Aggiornamento 1.8.1 - 14 ottobre 2026:
Richiesta nuova: luogo di nascita e tasto Calcola CF per persona assistita.
Non erano presenti. Aggiunti campi opzionali sesso, comune/Stato, provincia
e Belfiore; scheda normale e creazione rapida prenotazione; importazione
persone assistite. Calcolo locale, scelta comuni storici ANPR per data e
provincia, percorso manuale confermato per Stato estero/luogo non presente.
Algoritmo del codice base con conferma sostituzione e controllo duplicati;
nessuna attribuzione ufficiale o verifica esterna. Fonte comuni con ultimo
aggiornamento 16/05/2023, recuperata 14/10/2026, dichiarata nella schermata.
324 controlli UI/modelli superati. Nuova suite PatientBirthSelfTest inclusa
ma non eseguita qui. Le 14 suite e installazione HTTPS della precedente
revisione sono confermate dal resoconto Windows inviato dall'utente.
Aggiornamento con AggiornaServer.cmd; nessuna reinstallazione richiesta.

Aggiornamento 1.8.2 - 16 ottobre 2026:
- Richiesta nuova: semplificare la scheda da Prenota un servizio > Registra nuova persona.
- Soli dieci campi richiesti nell'ordine indicato, identici anche nell'archivio assistiti.
- Calcola CF accanto al codice fiscale; sesso solo nel calcolatore su richiesta.
- Provincia, codice catastale e tipo luogo gestiti internamente dalla ricerca.
- Eliminati dalla scheda modalita trasporto, referenti, note e campi tecnici permanenti.
- Conservati dati storici e controllo doppioni; nessuna demo inclusa nel pacchetto.

Aggiornamento 1.8.3 - 16 ottobre 2026:
- Nuova richiesta: riordinare la prima parte della sezione Servizio della prenotazione.
- Data e ora prenotazione per prima, poi tipologia, orario carico, orario visita e stato.
- Riquadro dedicato ai cinque campi.
- Eliminati dalla scheda ricerca persona aggiuntiva e attivita principale facoltativa.
- Conservati selettore assistito, creazione rapida e collegamenti storici.
- Data prenotazione indipendente da svolgimento, archivi mensili e fatturazione.

Aggiornamento 1.8.4 - 16 ottobre 2026:
- Nuova richiesta: voce laterale Prenotazioni rinominata Attivita.
- Al clic: dialogo con Nuova prenotazione e Registra attivita.
- Le scelte aprono i moduli gia presenti; l'archivio resta consultabile.
- Conservati permessi: creazione riservata ad amministratore/segreteria.

Aggiornamento 1.8.5 - 16 ottobre 2026:
- Nuova richiesta: eliminare il login durante la fase di costruzione.
- AvviaCostruzione.cmd aggiorna e attiva accesso automatico dal browser PC.
- Account prove con comandi completi; sessione e CSRF conservati.
- Dati di costruzione separati da archivio e credenziali ordinarie.
- RiattivaLogin.cmd ripristina accesso ordinario senza eliminare le prove.
- Nessun accesso automatico nell'installazione ordinaria; modalita attivata solo dal centrale.

Aggiornamento 1.8.6 - 16 ottobre 2026:
- Richiesta nuova: applicare aggiornamenti senza download/estrazione manuale a ogni versione.
- Pulsante e pagina Aggiorna gestionale, riservati all'amministratore.
- Installazione dal browser del centrale, controllo versione disponibile anche da altri PC.
- Fonte HTTPS configurata una volta da Windows: non e ancora disponibile una fonte online.
- Download, controllo SHA256/file/percorsi, compilazione e collaudo prima di sostituire il programma.
- Componente Windows con percorso fisso; il servizio applicativo non puo modificare codice o fonte.
- Copia precedente e archivi conservati per ripristino in caso di mancato avvio.
- Conservata la modalita costruzione e il relativo archivio separato.
- Un'ultima attivazione mediante pacchetto e necessaria per le installazioni precedenti.
- Nessuna demo modificata o aggiunta; 362 controlli UI/modelli/HTTP simulati superati.
- Collaudo Windows e download da una fonte reale ancora da eseguire.

Aggiornamento 1.8.7 - 18 ottobre 2026:
- Richiesta nuova: eliminare Emergenza 118 dalla Tipologia di Nuova prenotazione.
- Rimosso dal menu delle nuove schede; disponibili Trasporto sanitario e Assistenza evento.
- Le schede esistenti e la registrazione diretta delle attivita conservano le tipologie.
- Pacchetto predisposto per il canale GitHub gia configurato; pubblicazione necessaria.

Aggiornamento 1.8.8 - 18 ottobre 2026:
- Richiesta nuova: secondo dialogo dopo Nuova prenotazione / Registra attivita.
- Nuova prenotazione: Assistenza evento, Trasporto sanitario, nell'ordine richiesto.
- Registra attivita: Assistenza evento, Trasporto sanitario, Emergenza 118.
- Scheda aperta con tipologia impostata; Indietro e Chiudi non salvano nulla.
- Amministratore e segreteria abilitati; conservati gli altri permessi.
- 1.8.7: utente conferma installazione dal pulsante e rimozione 118 dalla nuova prenotazione.

Aggiornamento 1.8.9 - 18 ottobre 2026:
- Nuovi campi: finalita trasporto e orario visita condizionale.
- Richiesta in parte gia presente: stampa prenotazione e attivita automatica
  alla chiusura. Aggiunti anteprima dopo il salvataggio e richiamo dall'elenco.
- Orario visita indipendente dalla fine servizio, con durata prenotata per
  controlli su mezzo ed equipaggio; nessuna data visita usata come chiusura.
- Prenotazioni aperte separate dalle attivita effettivamente salvate.
- Completa servizio con convalida dati e appello; rollback e nessun doppione.
- Attivita ordinate cronologicamente per giorno, mese e anno di svolgimento.
- Vecchi stati e servizi conservati; la scheda trasporto propone i nuovi stati.
- Annullamento o dati incompleti non producono un'attivita svolta.

Aggiornamento 1.8.10 - 24 ottobre 2026:
- Nuova richiesta: Nuova prenotazione per passaggi, prima Servizio e poi anagrafica.
- Annulla, Indietro e Avanti; dati conservati tornando indietro.
- Nuovo ordine anagrafica nel percorso, con sesso visibile e calcolo CF locale.
- Calcolo CF e controllo doppioni erano gia presenti: riusati nel secondo passaggio.
- Suggerimenti indirizzi dalle anagrafiche locali, senza Internet; nuovi indirizzi manuali.
- Salvataggio finale unico di paziente e prenotazione, con rollback su errore e
  riuso della richiesta per evitare duplicazioni dopo un'interruzione di rete.
- Restanti campi conservati nel terzo passaggio; archivio assistiti e schede gia
  salvate mantengono il loro editor. Nessun dato reale incluso nel codice pubblicato.
