'use strict';
// Solo interfaccia e icone. Nessuna risposta API o dato di paziente in cache.
const CACHE='volontariato-ui-1.8.13-trasporto-dettagli';
const ASSETS=['/','/app.js','/operazioni.js','/prezzi.js','/fatture.js','/posta.js','/automezzi.js','/sede.js','/completo.js','/cassa.js','/evoluzione.js','/luoghi-cf.js','/codice-fiscale.js','/aggiornamenti.js','/prenotazioni.js','/prenotazione-guidata.js','/style.css','/manifest.webmanifest','/icon-192.png','/icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('volontariato-ui-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
 if(!ASSETS.includes(url.pathname))return;
 event.respondWith(fetch(event.request).catch(()=>caches.match(url.pathname).then(response=>response||Response.error())));
});
