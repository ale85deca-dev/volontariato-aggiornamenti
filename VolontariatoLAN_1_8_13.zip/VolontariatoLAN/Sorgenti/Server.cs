﻿// Volontariato LAN - .NET Framework 4, nessuna dipendenza esterna.
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Security.Cryptography;
using System.ServiceProcess;
using System.Threading;
using System.Web.Script.Serialization;

namespace VolontariatoLAN {
public class ApiError : Exception { public int Status; public ApiError(string message, int status = 400) : base(message) { Status = status; } }
public class User { public string Id {get;set;} public string Username {get;set;} public string Name {get;set;} public string Role {get;set;} public string VolunteerId {get;set;} public string Salt {get;set;} public string Hash {get;set;} public bool Disabled {get;set;} }
public class State {
 public int Schema {get;set;} public long Revision {get;set;}
 public Dictionary<string,object> Settings {get;set;}
 public Dictionary<string,object> MailSettings {get;set;}
 public Dictionary<string,List<Dictionary<string,object>>> Tables {get;set;}
 public List<User> Users {get;set;} public Dictionary<string,int> Counters {get;set;}
 public List<Dictionary<string,object>> Audit {get;set;}
 public State() {
  Schema=1; MailSettings=new Dictionary<string,object>();Settings=new Dictionary<string,object>{{"activityStartDate","2027-01-01"}}; Users=new List<User>(); Counters=new Dictionary<string,int>(); Audit=new List<Dictionary<string,object>>(); Tables=new Dictionary<string,List<Dictionary<string,object>>>();
  foreach(string table in new[]{"patients","volunteers","vehicles","payers","bookings","trips","activities","documents","tariffs","attendance","checklistTemplates","checklists","fuel","vehicleCare","siteCleaning","equipment","stockItems","stockMovements"}) Tables[table]=new List<Dictionary<string,object>>();
  foreach(string table in Engine.CompleteTables)Tables[table]=new List<Dictionary<string,object>>();Settings["vehicleAlertDays"]=30;Settings["association"]=""; Settings["vat"]=""; Settings["taxCode"]=""; Settings["address"]=""; Settings["email"]=""; Settings["phone"]=""; Settings["iban"]="";
  Settings["invoicePrefix"]="F"; Settings["receiptPrefix"]="R"; Settings["vatRate"]=""; Settings["taxReason"]=""; Settings["baseRate"]=0; Settings["kmRate"]=0; Settings["hourRate"]=0; Settings["paymentTerms"]=""; Settings["checklistEnabled"]=false;
 }
}
public static class J {
 public static JavaScriptSerializer Serializer(){return new JavaScriptSerializer{MaxJsonLength=384*1024*1024,RecursionLimit=100};}
 public static string Encode(object value){return Serializer().Serialize(value);}
 public static Dictionary<string,object> Parse(string json){return Serializer().Deserialize<Dictionary<string,object>>(json);}
 public static T Clone<T>(T value){return Serializer().Deserialize<T>(Encode(value));}
 public static string S(Dictionary<string,object> d,string key){object value; return d!=null && d.TryGetValue(key,out value) && value!=null ? Convert.ToString(value,CultureInfo.InvariantCulture) : "";}
 public static decimal N(Dictionary<string,object> d,string key){decimal n; string value=S(d,key).Replace(',','.'); if(value=="")return 0; if(!decimal.TryParse(value,NumberStyles.Number,CultureInfo.InvariantCulture,out n))throw new ApiError("Valore numerico non valido: "+key); return n;}
 public static bool B(Dictionary<string,object> d,string key){return S(d,key).ToLowerInvariant()=="true";}
 public static Dictionary<string,object> D(Dictionary<string,object> d,string key){object value; if(d.TryGetValue(key,out value) && value is Dictionary<string,object>)return (Dictionary<string,object>)value; return new Dictionary<string,object>();}
 public static List<string> A(Dictionary<string,object> d,string key){object value; if(!d.TryGetValue(key,out value)||value==null)return new List<string>(); var a=value as IEnumerable; if(a==null||value is string)throw new ApiError("Elenco non valido: "+key); return a.Cast<object>().Select(x=>Convert.ToString(x)).Where(x=>!string.IsNullOrEmpty(x)).Distinct().ToList();}
 public static Dictionary<string,object> Obj(params object[] values){var d=new Dictionary<string,object>(); for(int i=0;i<values.Length;i+=2)d[(string)values[i]]=values[i+1]; return d;}
 public static decimal Round(decimal n){return Math.Round(n,2,MidpointRounding.AwayFromZero);}
 public static string Now(){return DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture);}
 public static string Id(){return Guid.NewGuid().ToString("N");}
 public static void Require(bool ok,string message,int status=400){if(!ok)throw new ApiError(message,status);}
}
public static class Crypt {
 public static byte[] Random(int n){var bytes=new byte[n]; using(var rng=RandomNumberGenerator.Create())rng.GetBytes(bytes); return bytes;}
 public static string Token(){return BitConverter.ToString(Random(32)).Replace("-", "").ToLowerInvariant();}
 public static string Password(string password,string salt){using(var kdf=new Rfc2898DeriveBytes(password,Convert.FromBase64String(salt),180000))return Convert.ToBase64String(kdf.GetBytes(32));}
 public static bool Equal(byte[] a,byte[] b){int diff=a.Length^b.Length; for(int i=0;i<Math.Min(a.Length,b.Length);i++)diff|=a[i]^b[i]; return diff==0;}
 public static byte[] Export(byte[] plain,string password){
  J.Require(password!=null&&password.Length>=12,"La password della copia deve avere almeno 12 caratteri.");
  byte[] salt=Random(16),iv=Random(16),key; using(var kdf=new Rfc2898DeriveBytes(password,salt,180000))key=kdf.GetBytes(64);
  byte[] cipher; using(var aes=Aes.Create()){aes.Key=key.Take(32).ToArray();aes.IV=iv;using(var encryptor=aes.CreateEncryptor())cipher=encryptor.TransformFinalBlock(plain,0,plain.Length);}
  byte[] body=Encoding.ASCII.GetBytes("VOLLAN01").Concat(salt).Concat(iv).Concat(cipher).ToArray(); byte[] mac;using(var h=new HMACSHA256(key.Skip(32).ToArray()))mac=h.ComputeHash(body); return body.Concat(mac).ToArray();
 }
 public static byte[] Import(byte[] payload,string password){
  J.Require(payload.Length>=88&&Encoding.ASCII.GetString(payload,0,8)=="VOLLAN01","Formato copia di sicurezza non riconosciuto.");
  byte[] salt=payload.Skip(8).Take(16).ToArray(),iv=payload.Skip(24).Take(16).ToArray(),key;using(var kdf=new Rfc2898DeriveBytes(password,salt,180000))key=kdf.GetBytes(64);
  byte[] body=payload.Take(payload.Length-32).ToArray(),mac;using(var h=new HMACSHA256(key.Skip(32).ToArray()))mac=h.ComputeHash(body);
  J.Require(Equal(mac,payload.Skip(payload.Length-32).ToArray()),"Password errata o copia danneggiata.");
  using(var aes=Aes.Create()){aes.Key=key.Take(32).ToArray();aes.IV=iv;using(var dec=aes.CreateDecryptor())return dec.TransformFinalBlock(payload,40,payload.Length-72);}
 }
}
public partial class Engine : IDisposable {
 public State Data; public string Root; private FileStream fileLock;
 public Engine(string root){
  Root=root;Directory.CreateDirectory(root);fileLock=new FileStream(Path.Combine(root,"archive.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
  string file=Path.Combine(root,"archive.dat"); if(File.Exists(file)){try {Data=J.Serializer().Deserialize<State>(Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(file),null,DataProtectionScope.LocalMachine)));ValidateState(Data);CheckVault();}catch{throw new Exception("Archivio non leggibile. Nessun dato e' stato sovrascritto. Ripristinare una copia verificata.");}}
  else {Data=new State();Persist();}
 }
 public void Dispose(){fileLock.Dispose();}
 public void Persist(){
  ValidateEvolutionState(Data);ValidateSettlementLinks();PrepareAttachmentVault();
  string file=Path.Combine(Root,"archive.dat"),temp=Path.Combine(Root,"archive.new");
  byte[] plain=Encoding.UTF8.GetBytes(J.Encode(Data));J.Require(plain.Length<=256*1024*1024,"Archivio oltre 256 MiB: ampliamento necessario prima di ulteriori inserimenti.",413);byte[] bytes=ProtectedData.Protect(plain,null,DataProtectionScope.LocalMachine);
  using(var fs=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)){fs.Write(bytes,0,bytes.Length);fs.Flush(true);}
  if(File.Exists(file)){
   string dir=Path.Combine(Root,"Backups");Directory.CreateDirectory(dir);string daily=Path.Combine(dir,DateTime.Now.ToString("yyyy-MM-dd")+".dat");if(!File.Exists(daily))File.Copy(file,daily);
   foreach(var old in Directory.GetFiles(dir,"????-??-??.dat").OrderByDescending(x=>x).Skip(30))File.Delete(old);
   File.Replace(temp,file,Path.Combine(Root,"archive.previous"));
  } else File.Move(temp,file);
 }
 public void Log(User user,string action,string table,string id){Data.Audit.Add(J.Obj("at",J.Now(),"user",user.Username,"action",action,"table",table,"id",id));}
 public object Change(User user,Func<object> action,string description,string table,string id){
  J.Require(user.Role!="lettura","L'utente ha accesso in sola lettura.",403); State before=J.Clone(Data); string backupConfigFile=Path.Combine(Root,"backup-config.dat");byte[] backupConfigBefore=table=="backup"&&File.Exists(backupConfigFile)?File.ReadAllBytes(backupConfigFile):null;
  try {object result=action();Data.Revision++;Log(user,description,table,id==""&&result is Dictionary<string,object>?J.S((Dictionary<string,object>)result,"id"):id);Persist();return result;}catch{Data=before;if(table=="backup"){if(backupConfigBefore==null){if(File.Exists(backupConfigFile))File.Delete(backupConfigFile);}else {string rollback=backupConfigFile+".rollback";File.WriteAllBytes(rollback,backupConfigBefore);if(File.Exists(backupConfigFile))File.Replace(rollback,backupConfigFile,null);else File.Move(rollback,backupConfigFile);}}throw;}
 }
 public Dictionary<string,object> Find(string table,string id,bool required=true){
  J.Require(Data.Tables.ContainsKey(table),"Archivio sconosciuto.");var r=Data.Tables[table].FirstOrDefault(x=>J.S(x,"id")==id);if(required)J.Require(r!=null,"Elemento non trovato in "+table,404);return r;
 }
 public void Ref(Dictionary<string,object> row,string field,string table,bool required=false){string id=J.S(row,field);if(id==""){J.Require(!required,"Campo obbligatorio: "+field);return;}var target=Find(table,id);J.Require(!J.B(target,"archived"),"Il riferimento "+field+" e' archiviato.");}
 public void Crew(Dictionary<string,object> row){foreach(string id in J.A(row,"crewIds")){var v=Find("volunteers",id);J.Require(!J.B(v,"archived"),"Un volontario dell'equipaggio e' archiviato.");}}
 public void DateField(Dictionary<string,object> row,string field,bool required=false){string text=J.S(row,field);if(text==""){J.Require(!required,"Campo obbligatorio: "+field);return;}DateTime dt;J.Require(DateTime.TryParseExact(text,"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out dt),"Data non valida: "+field);}
 public DateTime Stamp(Dictionary<string,object> row,string field){DateTime value;J.Require(DateTime.TryParseExact(J.S(row,field),new[]{"yyyy-MM-ddTHH:mm","yyyy-MM-ddTHH:mm:ss"},CultureInfo.InvariantCulture,DateTimeStyles.None,out value),"Data e ora obbligatorie/non valide: "+field);return value;}
 public void TypeField(Dictionary<string,object> row){J.Require(new[]{"Trasporto sanitario","Assistenza evento","Emergenza 118"}.Contains(J.S(row,"type")),"Tipo di attivita' non valido.");}
 public void Nonnegative(Dictionary<string,object> row,params string[] fields){foreach(var f in fields)J.Require(J.N(row,f)>=0,"Il valore "+f+" non puo' essere negativo.");}
 public void CheckOverlap(Dictionary<string,object> row,bool sharedTrip=false){
  if(J.S(row,"status")=="Annullata")return;DateTime start=Stamp(row,"start"),end=Stamp(row,"end");J.Require(end>start,"La fine deve essere successiva all'inizio.");var crew=J.A(row,"crewIds");string vehicle=J.S(row,"vehicleId");
  foreach(var b in Data.Tables["bookings"].Where(x=>J.S(x,"id")!=J.S(row,"id")&&!J.B(x,"archived")&&J.S(x,"status")!="Annullata")){
   DateTime bs=Stamp(b,"start"),be=Stamp(b,"end");if(start<be&&end>bs){if(ShareCompatible(row,b,sharedTrip))continue;J.Require(vehicle==""||vehicle!=J.S(b,"vehicleId"),"Automezzo gia' assegnato a una prenotazione nello stesso orario.",409);J.Require(!crew.Intersect(J.A(b,"crewIds")).Any(),"Volontario gia' assegnato nello stesso orario.",409);}
  }
 }
 public void Validate(string table,Dictionary<string,object> row){
  ValidateExtra(table,row);ValidateRecordingDate(table,row);
  if(table=="patients"||table=="volunteers"){J.Require(J.S(row,"name").Trim()!=""&&J.S(row,"surname").Trim()!="","Nome e cognome sono obbligatori.");DateField(row,"birthDate");string cf=J.S(row,"taxCode").Trim().ToUpperInvariant();row["taxCode"]=cf;if(cf!="")J.Require(!Data.Tables[table].Any(x=>J.S(x,"id")!=J.S(row,"id")&&J.S(x,"taxCode").ToUpperInvariant()==cf),"Codice fiscale gia' presente in archivio.",409);}
  if(table=="patients"){
   string sex=J.S(row,"sex").Trim().ToUpperInvariant(),placeCode=J.S(row,"birthPlaceCode").Trim().ToUpperInvariant(),province=J.S(row,"birthProvince").Trim().ToUpperInvariant(),placeType=J.S(row,"birthPlaceType");
   J.Require(sex==""||new[]{"M","F"}.Contains(sex),"Sesso anagrafico non valido.");J.Require(placeType==""||new[]{"Italia","Estero"}.Contains(placeType),"Tipo luogo di nascita non valido.");
   J.Require(J.S(row,"birthPlace").Length<=150,"Luogo di nascita troppo lungo.");J.Require(province==""||System.Text.RegularExpressions.Regex.IsMatch(province,"^[A-Z]{2}$"),"Provincia di nascita: usa una sigla di due lettere.");
   J.Require(placeCode==""||System.Text.RegularExpressions.Regex.IsMatch(placeCode,"^[A-Z][0-9]{3}$"),"Codice catastale del luogo: una lettera e tre cifre.");J.Require(placeType!="Estero"||placeCode==""||placeCode.StartsWith("Z"),"Codice Stato estero non valido.");
   if(row.ContainsKey("sex"))row["sex"]=sex;if(row.ContainsKey("birthPlaceCode"))row["birthPlaceCode"]=placeCode;if(row.ContainsKey("birthProvince"))row["birthProvince"]=placeType=="Estero"?"EE":province;
  }
  if(table=="volunteers"){DateField(row,"qualificationExpiry");DateField(row,"licenceExpiry");DateField(row,"insuranceExpiry");}
  if(table=="payers")J.Require(J.S(row,"name").Trim()!="","Denominazione del soggetto pagante obbligatoria.");
  if(table=="vehicles"){
   J.Require(J.S(row,"plate").Trim()!="","Targa obbligatoria.");row["plate"]=J.S(row,"plate").Trim().ToUpperInvariant();J.Require(!Data.Tables[table].Any(x=>J.S(x,"plate")==J.S(row,"plate")&&J.S(x,"id")!=J.S(row,"id")),"Targa gia' presente.",409);
   Nonnegative(row,"initialKm","nextServiceKm");DateField(row,"inspectionExpiry");DateField(row,"insuranceExpiry");DateField(row,"cylinderExpiry");DateField(row,"extinguisherExpiry");DateField(row,"healthInspectionExpiry");DateField(row,"daeInspectionExpiry");DateField(row,"stretcherInspectionExpiry");DateField(row,"chairInspectionExpiry");DateField(row,"nextServiceDate");DateField(row,"registrationDate");if(Data.Tables["trips"].Any(x=>J.S(x,"vehicleId")==J.S(row,"id")))J.Require(J.N(row,"initialKm")<=Data.Tables["trips"].Where(x=>J.S(x,"vehicleId")==J.S(row,"id")).Min(x=>J.N(x,"kmStart")),"I chilometri iniziali non possono superare il primo viaggio registrato.");
  }
  if(table=="bookings"){
   ValidateTransportBooking(row);TypeField(row);if(J.S(row,"bookedAt")!="")Stamp(row,"bookedAt");Stamp(row,"start");Stamp(row,"end");Ref(row,"patientId","patients");Ref(row,"payerId","payers");Ref(row,"vehicleId","vehicles");Crew(row);CheckOverlap(row);
   J.Require(new[]{"Prenotata","Confermata","In corso","Completata","Annullata"}.Contains(J.S(row,"status")),"Stato prenotazione non valido.");
   Nonnegative(row,"baseRate","kmRate","hourRate","extras","discount","vatRate","estimatedKm","estimatedHours","stamp");J.Require(J.N(row,"vatRate")<=100,"IVA non valida.");
   J.Require(J.S(row,"title").Trim()!="","Descrizione del servizio obbligatoria.");
  }
  if(table=="trips"){
   Ref(row,"bookingId","bookings",true);Ref(row,"vehicleId","vehicles",true);Crew(row);DateTime start=Stamp(row,"start"),end=Stamp(row,"end");J.Require(end>=start,"Orario finale precedente all'inizio.");
   Nonnegative(row,"kmStart","kmEnd","hours","tolls");J.Require(J.N(row,"kmStart")>=J.N(Find("vehicles",J.S(row,"vehicleId")),"initialKm"),"Il contachilometri iniziale e' inferiore al valore iniziale dell'automezzo.");J.Require(J.N(row,"kmEnd")>=J.N(row,"kmStart"),"Il contachilometri finale deve essere almeno pari a quello iniziale.");
   J.Require(new[]{"Aperto","Concluso"}.Contains(J.S(row,"status")),"Stato del foglio viaggio non valido.");
   J.Require(!Data.Tables["trips"].Any(x=>TripBookingIds(x).Intersect(TripBookingIds(row)).Any()&&J.S(x,"id")!=J.S(row,"id")),"Esiste gia' un foglio viaggio per questa prenotazione.",409);
   var booking=Find("bookings",J.S(row,"bookingId"));J.Require(J.S(booking,"status")!="Annullata","Prenotazione annullata.");
   if(J.S(row,"status")=="Concluso"){
    foreach(string linked in TripBookingIds(row))ValidateTransportCompletion(Find("bookings",linked),row);
    var probe=J.Clone(booking);probe["vehicleId"]=row["vehicleId"];probe["crewIds"]=J.A(row,"crewIds");probe["start"]=row["start"];probe["end"]=row["end"];CheckOverlap(probe,true);
    foreach(var other in Data.Tables["trips"].Where(x=>J.S(x,"id")!=J.S(row,"id")&&J.S(x,"status")=="Concluso")){if(start<Stamp(other,"end")&&end>Stamp(other,"start"))J.Require(!J.A(row,"crewIds").Intersect(J.A(other,"crewIds")).Any(),"Equipaggio presente in un altro viaggio nello stesso orario.",409);}
    foreach(var t in Data.Tables["trips"].Where(x=>J.S(x,"id")!=J.S(row,"id")&&J.S(x,"vehicleId")==J.S(row,"vehicleId")&&J.S(x,"status")=="Concluso")){
     DateTime ts=Stamp(t,"start"),te=Stamp(t,"end");J.Require(!(start<te&&end>ts),"Automezzo presente in un altro viaggio nello stesso orario.",409);
     if(te<=start)J.Require(J.N(row,"kmStart")>=J.N(t,"kmEnd"),"Contachilometri iniziale inferiore a un viaggio precedente.");
     if(end<=ts)J.Require(J.N(row,"kmEnd")<=J.N(t,"kmStart"),"Contachilometri finale superiore a un viaggio successivo.");
    }
   }
  }
  if(table=="activities"){J.Require(J.S(row,"tripId")=="","Le attivita' da viaggio si generano concludendo il foglio viaggio.");TypeField(row);DateField(row,"date",true);J.Require(J.S(row,"title").Trim()!="","Descrizione attivita' obbligatoria.");Ref(row,"patientId","patients");Ref(row,"vehicleId","vehicles");Ref(row,"bookingId","bookings");Ref(row,"tripId","trips");Crew(row);Nonnegative(row,"km","hours");}
 }
 public void GuardDocuments(string bookingId){J.Require(!Data.Tables["documents"].Any(x=>DocumentHasBooking(x,bookingId)&&J.S(x,"status")!="Bozza"),"Il servizio ha un documento emesso: i dati economici e di viaggio sono bloccati.",409);}
 public Dictionary<string,object> Save(string table,Dictionary<string,object> input){
  J.Require(table!="documents"&&table!="cashOpenings"&&Data.Tables.ContainsKey(table),"Archivio non modificabile.");var row=J.Clone(input);string id=J.S(row,"id");var previous=id==""?null:Find(table,id);
  if(previous!=null)J.Require(J.N(previous,"version")==J.N(row,"version"),"Un altro operatore ha modificato questa scheda. Ricarica prima di salvare.",409);
  if(table=="bookings"&&previous==null&&J.S(row,"transportPurpose")!="")J.Require(J.S(row,"status")!="Completata","Salva prima la prenotazione; completa il servizio dopo lo svolgimento.");
  if(table=="bookings"&&previous!=null){GuardSharedBooking(row);GuardDocuments(id);J.Require(J.S(previous,"status")!="Completata"||J.S(row,"status")=="Completata","Una prenotazione completata deve restare completata.");}
  if(table=="trips"){if(previous!=null)J.Require(J.S(previous,"bookingId")==J.S(row,"bookingId"),"La prenotazione di un foglio viaggio gia creato non puo cambiare.");foreach(string linked in TripBookingIds(previous??row))GuardDocuments(linked);}
  if(table=="attendance"){if(previous!=null&&J.S(previous,"scope")=="Servizio")GuardDocuments(J.S(previous,"bookingId"));if(J.S(row,"scope")=="Servizio")GuardDocuments(J.S(row,"bookingId"));}
  if(table=="activities"&&previous!=null)J.Require(J.S(previous,"tripId")==""&&!J.B(previous,"bookingGenerated"),"Questa attivita' e' generata dal foglio viaggio: modifica il foglio viaggio.");
  J.Require(!J.B(row,"archived"),"Usa il comando Archivia per archiviare una scheda.");
  if(id==""){id=J.Id();row["id"]=id;row["createdAt"]=J.Now();}else row["createdAt"]=previous["createdAt"];
  if(table=="trips")BindTripBookings(row,previous);row["version"]=previous==null?1:J.N(previous,"version")+1;row["updatedAt"]=J.Now();row["archived"]=false;Validate(table,row);if(table=="trips")AssignTravelNumber(row,previous);
  if(previous!=null)Data.Tables[table].Remove(previous);Data.Tables[table].Add(row);
  if(table=="trips"){SyncTrip(row);SyncOperationalTrip(row);}if(table=="bookings")SyncBooking(row);return row;
 }
 public void SyncBooking(Dictionary<string,object> booking){
  if(J.S(booking,"status")!="Completata")return;
  var trip=AssociatedTrip(J.S(booking,"id"));if(trip!=null){J.Require(J.S(trip,"status")=="Concluso","Concludi il foglio viaggio prima di completare la prenotazione.");SyncTrip(trip);return;}
  ValidateTransportCompletion(booking,null);
  var existing=Data.Tables["activities"].FirstOrDefault(x=>J.S(x,"bookingId")==J.S(booking,"id")&&J.B(x,"bookingGenerated"));
  var activity=J.Obj("id",existing==null?J.Id():J.S(existing,"id"),"version",existing==null?1:J.N(existing,"version")+1,"createdAt",existing==null?J.Now():J.S(existing,"createdAt"),"updatedAt",J.Now(),"archived",false,"bookingGenerated",true,"bookingId",J.S(booking,"id"),"tripId","","type",J.S(booking,"type"),"transportPurpose",J.S(booking,"transportPurpose"),"visitAt",J.S(booking,"visitAt"),"performedAt",J.S(booking,"start"),"title",J.S(booking,"title"),"date",J.S(booking,"start").Substring(0,10),"vehicleId",J.S(booking,"vehicleId"),"patientId",J.S(booking,"patientId"),"crewIds",J.A(booking,"crewIds"),"protocol118",J.S(booking,"protocol118"),"km",J.N(booking,"estimatedKm"),"hours",J.N(booking,"estimatedHours"),"notes",J.S(booking,"notes"));
  if(existing!=null)Data.Tables["activities"].Remove(existing);Data.Tables["activities"].Add(activity);
 }
 public void SyncTrip(Dictionary<string,object> trip){foreach(string bookingId in TripBookingIds(trip))SyncTripBooking(trip,bookingId);}
 public void SyncTripBooking(Dictionary<string,object> trip,string bookingId){
  var booking=Find("bookings",bookingId);var existing=Data.Tables["activities"].FirstOrDefault(x=>J.S(x,"bookingId")==bookingId&&(J.S(x,"tripId")==J.S(trip,"id")||J.B(x,"bookingGenerated")));
  J.Require(J.S(trip,"status")=="Concluso"||existing==null,"Un viaggio concluso non puo' tornare aperto.");
  if(J.S(trip,"status")!="Concluso")return;
  ValidateTransportCompletion(booking,trip);
  booking["status"]="Completata";booking["vehicleId"]=J.S(trip,"vehicleId");booking["crewIds"]=J.A(trip,"crewIds");booking["version"]=J.N(booking,"version")+1;booking["updatedAt"]=J.Now();
  var a=J.Obj("id",existing==null?J.Id():J.S(existing,"id"),"version",existing==null?1:J.N(existing,"version")+1,"createdAt",existing==null?J.Now():J.S(existing,"createdAt"),"updatedAt",J.Now(),"archived",false,"type",J.S(booking,"type"),"transportPurpose",J.S(booking,"transportPurpose"),"visitAt",J.S(booking,"visitAt"),"performedAt",J.S(trip,"start"),"date",J.S(trip,"start").Substring(0,10),"title",J.S(booking,"title"),"patientId",J.S(booking,"patientId"),"bookingId",J.S(booking,"id"),"tripId",J.S(trip,"id"),"vehicleId",J.S(trip,"vehicleId"),"crewIds",ActualCrew(trip),"km",J.N(trip,"kmEnd")-J.N(trip,"kmStart"),"hours",J.N(trip,"hours"),"protocol118",J.S(booking,"protocol118"),"notes",J.S(trip,"notes"));
  if(existing!=null)Data.Tables["activities"].Remove(existing);Data.Tables["activities"].Add(a);
 }
 public Dictionary<string,object> CreateTrip(string bookingId){
  var b=Find("bookings",bookingId);GuardDocuments(bookingId);var existing=AssociatedTrip(bookingId);if(existing!=null){J.Require(TripBookingIds(existing).Count>1,"Esiste già un foglio viaggio per questa prenotazione.",409);return existing;}J.Require(J.S(b,"status")!="Annullata","Prenotazione annullata.");string vehicle=J.S(b,"vehicleId");J.Require(vehicle!="","Assegna un automezzo alla prenotazione prima di creare il viaggio.");
  var v=Find("vehicles",vehicle);decimal km=FleetKmAt(vehicle,J.S(b,"start"));
  return Save("trips",J.Obj("bookingId",bookingId,"vehicleId",vehicle,"crewIds",J.A(b,"crewIds"),"start",J.S(b,"start"),"end",J.S(b,"end"),"origin",J.S(b,"origin"),"destination",J.S(b,"destination"),"kmStart",km,"kmEnd",km+(J.S(b,"status")=="Completata"?J.N(b,"estimatedKm"):0),"hours",J.S(b,"status")=="Completata"?J.N(b,"estimatedHours"):0,"tolls",0,"status",J.S(b,"status")=="Completata"?"Concluso":"Aperto","notes",""));
 }
 public Dictionary<string,object> BuildDocument(string bookingId,string kind,bool cumulative=false){
  J.Require(kind=="Fattura"||kind=="Ricevuta","Documento non valido.");var b=Find("bookings",bookingId);J.Require(J.S(b,"status")=="Completata","Completa il servizio prima di creare il documento.");
  var patient=J.S(b,"patientId")==""?null:Find("patients",J.S(b,"patientId"));var funding=J.S(b,"payerId")==""?null:Find("payers",J.S(b,"payerId"));
  Dictionary<string,object> payer;string source;
  if(!cumulative&&patient!=null){payer=PatientInvoiceParty(patient);source="patients";}else{J.Require(cumulative||J.S(b,"type")!="Trasporto sanitario","Collega la persona assistita al trasporto prima di creare la fattura singola.");Ref(b,"payerId","payers",true);payer=J.Clone(funding);source="payers";}
  var trip=AssociatedTrip(bookingId);if(trip!=null&&J.S(trip,"status")!="Concluso")trip=null;
  decimal km=trip==null?J.N(b,"estimatedKm"):J.N(trip,"kmEnd")-J.N(trip,"kmStart"),hours=trip==null?J.N(b,"estimatedHours"):J.N(trip,"hours"),tolls=trip==null?0:J.N(trip,"tolls");
  var pricing=PriceBreakdown(b,km,hours,tolls);decimal baseCost=J.N(pricing,"baseCost"),kmCost=J.N(pricing,"kmCost"),hoursCost=J.N(pricing,"hoursCost"),extras=J.N(pricing,"extras"),discount=J.Round(J.N(b,"discount"));
  decimal taxable=J.Round(baseCost+kmCost+hoursCost+extras-discount),rate=J.N(b,"vatRate"),tax=J.Round(taxable*rate/100m),stamp=J.Round(J.N(b,"stamp"));J.Require(taxable>=0,"Lo sconto supera l'importo del servizio.");
  J.Require(J.S(b,"vatRate")!="","Definisci il trattamento IVA nella prenotazione prima di creare il documento.");
  J.Require(rate!=0||J.S(b,"taxReason").Trim()!="","Inserisci il riferimento/motivo per l'IVA a zero, verificato con il consulente.");
  J.Require(J.S(Data.Settings,"association").Trim()!=""&&J.S(Data.Settings,"address").Trim()!=""&&(J.S(Data.Settings,"vat")!=""||J.S(Data.Settings,"taxCode")!=""),"Completa denominazione, indirizzo e codice fiscale/partita IVA dell'associazione nelle impostazioni.");
  J.Require(J.S(payer,"address").Trim()!=""&&(J.S(payer,"taxCode").Trim()!=""||J.S(payer,"vat").Trim()!=""),source=="patients"?"Completa indirizzo e codice fiscale della persona assistita.":"Completa indirizzo e codice fiscale/partita IVA del soggetto intestatario.");
  return J.Obj("bookingId",bookingId,"kind",kind,"status","Bozza","number","","date",DateTime.Now.ToString("yyyy-MM-dd"),"issuer",J.Clone(Data.Settings),"payer",J.Clone(payer),"invoicePartySource",source,"patient",patient==null?null:PatientInvoiceParty(patient),"fundingParty",funding==null?null:J.Clone(funding),"service",J.Clone(b),"trip",trip==null?null:J.Clone(trip),"pricingMode",J.S(pricing,"pricingMode"),"priceLines",pricing["priceLines"],"specificRate",pricing["specificRate"],"km",km,"hours",hours,"baseCost",baseCost,"kmCost",kmCost,"hoursCost",hoursCost,"extras",extras,"discount",discount,"taxable",taxable,"vatRate",rate,"taxReason",J.S(b,"taxReason"),"tax",tax,"stamp",stamp,"total",J.Round(taxable+tax+stamp),"payments",new object[0]);
 }
 public Dictionary<string,object> NewDocument(string bookingId,string kind){
  J.Require(!Data.Tables["documents"].Any(x=>DocumentHasBooking(x,bookingId)),"Esiste gia' un documento per questa prenotazione. Aprilo dall'archivio documenti.",409);
  J.Require(kind!="Fattura"||J.S(Find("bookings",bookingId),"type")!="Emergenza 118","Per emergenza 118 crea una fattura cumulativa.");var d=BuildDocument(bookingId,kind);d["billingMode"]="Singola";d["bookingIds"]=new[]{bookingId};AddActivitySnapshot(d);d["id"]=J.Id();d["version"]=1;d["createdAt"]=J.Now();Data.Tables["documents"].Add(d);return d;
 }
 public Dictionary<string,object> RefreshDraft(string id,decimal version){
  var old=Find("documents",id);if(IsCredit(old))return RefreshCredit(id,version);J.Require(J.S(old,"status")=="Bozza"&&J.N(old,"version")==version,"Bozza non aggiornabile o modificata da un altro operatore.",409);
  var d=RebuildDocument(old);d["id"]=id;d["version"]=version+1;d["createdAt"]=old["createdAt"];Data.Tables["documents"].Remove(old);Data.Tables["documents"].Add(d);return d;
 }
 public Dictionary<string,object> Issue(string id,decimal version,string date){
  var old=Find("documents",id);if(IsCredit(old))return IssueCredit(id,version,date);J.Require(J.S(old,"status")=="Bozza","Documento gia' emesso.",409);J.Require(J.N(old,"version")==version,"Documento modificato da un altro operatore.",409);
  var d=RebuildDocument(old);J.Require(DocumentSource(old)==DocumentSource(d),"Dati delle attivita' o intestazioni modificati: aggiorna la bozza e controllala prima di emettere.",409);d["date"]=date;DateField(d,"date",true);string year=date.Substring(0,4),kind=J.S(d,"kind"),key=kind+"/"+year;int sequence;Data.Counters.TryGetValue(key,out sequence);sequence++;J.Require(!Data.Tables["documents"].Any(x=>J.S(x,"kind")==kind&&J.S(x,"status")!="Bozza"&&J.S(x,"date").StartsWith(year)&&string.CompareOrdinal(J.S(x,"date"),date)>0),"La data non puo' precedere l'ultimo documento della stessa serie annuale.");Data.Counters[key]=sequence;
  string prefix=J.S(Data.Settings,kind=="Fattura"?"invoicePrefix":"receiptPrefix");J.Require(prefix!="","Prefisso numerazione mancante.");d["number"]=prefix+"/"+year+"/"+sequence.ToString("D5");d["status"]="Emesso";d["id"]=id;d["version"]=version+1;d["createdAt"]=old["createdAt"];d["issuedAt"]=J.Now();
  Data.Tables["documents"].Remove(old);Data.Tables["documents"].Add(d);return d;
 }
 public object Payment(Dictionary<string,object> input){
  var d=Find("documents",J.S(input,"id"));J.Require(!IsCredit(d),"Non registrare incassi su una nota di credito.");J.Require(J.S(d,"status")!="Bozza","Emetti il documento prima di registrare incassi.");J.Require(J.N(d,"version")==J.N(input,"version"),"Documento modificato da un altro operatore.",409);
  J.Require(PaymentMethod(J.S(input,"method")),"Modalita' di incasso non valida.");decimal amount=J.Round(J.N(input,"amount"));J.Require(amount>0,"Importo incasso maggiore di zero obbligatorio.");Since(input,"date");var payments=PaymentList(d);decimal received=payments.Sum(x=>J.N(x,"amount"));J.Require(amount<=NetDue(d),"L'incasso supera il saldo residuo.");
  payments.Add(J.Obj("id",J.Id(),"date",J.S(input,"date"),"amount",amount,"method",J.S(input,"method"),"paidBy",J.S(input,"paidBy"),"notes",J.S(input,"notes")));d["payments"]=payments;d["version"]=J.N(d,"version")+1;d["status"]=received+amount==J.N(d,"total")-IssuedCredits(J.S(d,"id"))?"Pagato":"Parzialmente pagato";return d;
 }
 public static List<Dictionary<string,object>> PaymentList(Dictionary<string,object> d){object value;if(!d.TryGetValue("payments",out value)||value==null)return new List<Dictionary<string,object>>();return ((IEnumerable)value).Cast<object>().Select(x=>(Dictionary<string,object>)x).ToList();}
 public object Archive(string table,string id,decimal version){
  J.Require(new[]{"patients","volunteers","vehicles","payers","bookings","activities","tariffs","checklistTemplates","fuel","attendance","vehicleCare","siteCleaning","equipment","stockItems","stockMovements"}.Contains(table),"Questo archivio non consente archiviazione.");var row=Find(table,id);J.Require(J.N(row,"version")==version,"Scheda modificata da un altro operatore.",409);
  if(table=="bookings"){J.Require(!Data.Tables["trips"].Any(x=>TripBookingIds(x).Contains(id))&&!Data.Tables["documents"].Any(x=>DocumentHasBooking(x,id)),"La prenotazione ha viaggi o documenti collegati.");if(J.S(row,"status")!="Completata")row["status"]="Annullata";}
  if(table=="activities")J.Require(J.S(row,"tripId")==""&&!J.B(row,"bookingGenerated"),"Archiviazione non consentita per attivita' generata da viaggio.");
  var refFields=new Dictionary<string,string>{{"patients","patientId"},{"volunteers","crewIds"},{"vehicles","vehicleId"},{"payers","payerId"},{"tariffs","tariffId"}};
  if(refFields.ContainsKey(table))foreach(var booking in Data.Tables["bookings"].Where(x=>!J.B(x,"archived")&&new[]{"Prenotata","Confermata","In corso"}.Contains(J.S(x,"status"))))J.Require(table=="volunteers"?!J.A(booking,"crewIds").Contains(id):J.S(booking,refFields[table])!=id,"Scheda assegnata a un servizio ancora aperto.");
  row["archived"]=true;row["version"]=version+1;return row;
 }
 public object Unarchive(string table,string id,decimal version){
  J.Require(new[]{"patients","volunteers","vehicles","payers","bookings","activities","tariffs","checklistTemplates","fuel","attendance","vehicleCare","siteCleaning","equipment","stockItems","stockMovements"}.Contains(table),"Archivio non ripristinabile.");var row=Find(table,id);J.Require(J.N(row,"version")==version,"Scheda modificata da un altro operatore.",409);J.Require(J.B(row,"archived"),"Scheda gia' attiva.");row["archived"]=false;row["version"]=version+1;row["updatedAt"]=J.Now();return row;
 }
 public object Settings(User user,Dictionary<string,object> settings,long revision){J.Require(user.Role=="admin","Solo l'amministratore puo' modificare le impostazioni.",403);J.Require(Data.Revision==revision,"Impostazioni non aggiornate: ricarica.",409);J.Require(J.S(settings,"association").Trim()!="","Denominazione obbligatoria.");Nonnegative(settings,"baseRate","kmRate","hourRate","vatRate");if(J.S(settings,"vehicleAlertDays")!="")J.Require(J.N(settings,"vehicleAlertDays")>=0&&J.N(settings,"vehicleAlertDays")<=365&&J.N(settings,"vehicleAlertDays")==Math.Truncate(J.N(settings,"vehicleAlertDays")),"Anticipo alert automezzi: numero intero tra 0 e 365 giorni.");J.Require(J.N(settings,"vatRate")<=100,"IVA non valida.");string ip=J.S(settings,"invoicePrefix"),rp=J.S(settings,"receiptPrefix");J.Require(System.Text.RegularExpressions.Regex.IsMatch(ip,"^[A-Za-z0-9_-]{1,12}$")&&System.Text.RegularExpressions.Regex.IsMatch(rp,"^[A-Za-z0-9_-]{1,12}$")&&ip!=rp&&ip!="NC"&&rp!="NC","Prefissi di 1-12 caratteri, diversi per fatture e ricevute e diversi da NC (rettifiche), obbligatori.");DateField(settings,"activityStartDate");string since=J.S(settings,"activityStartDate");if(since!="")foreach(string table in new[]{"fuel","vehicleCare","siteCleaning","stockMovements"})J.Require(Data.Tables[table].All(row=>string.CompareOrdinal(J.S(row,table=="activities"||table=="attendance"?"date":table=="fuel"||table=="vehicleCare"||table=="siteCleaning"||table=="stockMovements"?"at":"start").Substring(0,10),since)>=0),"L inizio registrazioni non puo superare la data di registrazioni gia presenti.");if(CashOpening()!=null)J.Require(since==""||string.CompareOrdinal(since,J.S(CashOpening(),"date"))<=0,"L’inizio registrazioni non può superare la data del saldo iniziale cassa.");if(Data.Tables["bankOpenings"].Count>0)J.Require(since==""||string.CompareOrdinal(since,J.S(Data.Tables["bankOpenings"][0],"date"))<=0,"Inizio registrazioni successivo all apertura banca.");Data.Settings=J.Clone(settings);return settings;}
 public object SaveUser(User actor,Dictionary<string,object> input){
  J.Require(actor.Role=="admin","Solo l'amministratore puo' gestire gli utenti.",403);string id=J.S(input,"id"),username=J.S(input,"username").Trim().ToLowerInvariant(),password=J.S(input,"password"),role=J.S(input,"role");
  J.Require(username.Length>=3&&username.Length<=60&&!username.Any(char.IsWhiteSpace),"Nome utente non valido (3-60 caratteri, senza spazi).");J.Require(new[]{"admin","segreteria","lettura","volontario"}.Contains(role),"Ruolo non valido.");J.Require(!Data.Users.Any(x=>x.Username==username&&x.Id!=id),"Nome utente gia' presente.",409);
  User u=id==""?new User{Id=J.Id()}:Data.Users.FirstOrDefault(x=>x.Id==id);J.Require(u!=null,"Utente non trovato.");bool disabled=J.B(input,"disabled");
  if(u.Role=="admin"&&!u.Disabled&&(disabled||role!="admin"))J.Require(Data.Users.Count(x=>x.Role=="admin"&&!x.Disabled)>1,"Non puoi disattivare l'ultimo amministratore.");
  if(password!=""||id==""){J.Require(password.Length>=12,"Password di almeno 12 caratteri obbligatoria.");u.Salt=Convert.ToBase64String(Crypt.Random(16));u.Hash=Crypt.Password(password,u.Salt);}
  if(role=="volontario"){Ref(input,"volunteerId","volunteers",true);}u.VolunteerId=role=="volontario"?J.S(input,"volunteerId"):"";
  u.Username=username;u.Name=J.S(input,"name");u.Role=role;u.Disabled=disabled;if(id=="")Data.Users.Add(u);return SafeUser(u);
 }
 public static object SafeUser(User u){return J.Obj("id",u.Id,"username",u.Username,"name",u.Name,"role",u.Role,"volunteerId",u.VolunteerId,"disabled",u.Disabled);}
 public static void ValidateState(State s){J.Require(s!=null&&s.Schema==1&&s.Settings!=null&&s.Users!=null&&s.Counters!=null&&s.Audit!=null,"Copia incompatibile.");Upgrade(s);foreach(string table in new State().Tables.Keys){J.Require(s.Tables!=null&&s.Tables.ContainsKey(table)&&s.Tables[table]!=null,"Archivio mancante: "+table);J.Require(s.Tables[table].Select(x=>J.S(x,"id")).Distinct().Count()==s.Tables[table].Count&&s.Tables[table].All(x=>J.S(x,"id")!=""),"Identificativi non validi.");}J.Require(s.Users.All(x=>x.Salt!=null&&x.Hash!=null&&new[]{"admin","segreteria","lettura","volontario"}.Contains(x.Role)),"Utenti non validi.");J.Require(s.Users.Select(x=>x.Username).Distinct().Count()==s.Users.Count,"Nomi utente duplicati.");
  foreach(var d in s.Tables["documents"]){J.Require(new[]{"Fattura","Ricevuta","Nota di credito"}.Contains(J.S(d,"kind"))&&new[]{"Bozza","Emesso","Pagato","Parzialmente pagato"}.Contains(J.S(d,"status")),"Documento non valido.");if(J.S(d,"status")!="Bozza"){string date=J.S(d,"date");J.Require(date.Length==10&&J.S(d,"number").Contains("/"),"Numerazione documento non valida.");int sequence;J.Require(int.TryParse(J.S(d,"number").Split('/').Last(),out sequence),"Progressivo non valido.");string key=J.S(d,"kind")+"/"+date.Substring(0,4);J.Require(s.Counters.ContainsKey(key)&&s.Counters[key]>=sequence,"Contatore inferiore ai documenti emessi.");}}
  J.Require(s.Tables["documents"].Where(x=>J.S(x,"status")!="Bozza").Select(x=>J.S(x,"kind")+"|"+J.S(x,"number")).Distinct().Count()==s.Tables["documents"].Count(x=>J.S(x,"status")!="Bozza"),"Documenti emessi duplicati.");ValidateDocumentLinks(s);ValidateCompleteState(s);}
 public object Restore(User user,byte[] payload,string password){
  J.Require(user.Role=="admin","Ripristino consentito solo all'amministratore.",403);var restored=J.Serializer().Deserialize<State>(Encoding.UTF8.GetString(Crypt.Import(payload,password)));ValidateState(restored);J.Require(restored.Users.Any(x=>x.Role=="admin"&&!x.Disabled),"La copia non contiene un amministratore attivo.");
  string before=Path.Combine(Root,"Backups","pre-ripristino-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".dat");Directory.CreateDirectory(Path.GetDirectoryName(before));File.Copy(Path.Combine(Root,"archive.dat"),before,false);Data=restored;PrepareAttachmentVault();CheckVault();ValidateLocations();ValidateSettlementLinks();return J.Obj("restored",true);
 }
}
public static class ConstructionAccess {
 public const string FlagName="costruzione.flag";
 public static bool Enabled(string root){return File.Exists(Path.Combine(root,FlagName));}
 public static string DataRoot(string root,bool enabled){return Path.Combine(root,enabled?"DatiCostruzione":"Dati");}
 public static User PrepareUser(Engine engine,bool enabled){
  J.Require(enabled&&Path.GetFileName(engine.Root.TrimEnd(Path.DirectorySeparatorChar))=="DatiCostruzione","Accesso di costruzione non attivo.",403);
  var existing=engine.Data.Users.FirstOrDefault(u=>u.Role=="admin"&&!u.Disabled);if(existing!=null)return existing;
  string salt=Convert.ToBase64String(Crypt.Random(16));var user=new User{Id=J.Id(),Username="costruzione",Name="Costruzione - account di prova",Role="admin",Salt=salt,Hash=Crypt.Password(Crypt.Token(),salt)};
  engine.Data.Users.Add(user);if(J.S(engine.Data.Settings,"association")=="")engine.Data.Settings["association"]="Associazione - archivio di prova";
  engine.Data.Revision++;engine.Log(user,"Inizializzazione archivio di costruzione","users",user.Id);engine.Persist();return user;
 }
}
public class Session {public string UserId; public string Csrf; public DateTime Expires;}
public class HttpServer : IDisposable {
 private Timer backupTimer;private Engine engine;private HttpListener listener;private string appPath;private bool constructionMode;private UpdateManager updates;private string installationRoot;private Dictionary<string,Session> sessions=new Dictionary<string,Session>();private Dictionary<string,List<DateTime>> attempts=new Dictionary<string,List<DateTime>>();
 public HttpServer(string root){installationRoot=root;updates=new UpdateManager(root);appPath=Path.Combine(root,"App");constructionMode=ConstructionAccess.Enabled(root);engine=new Engine(ConstructionAccess.DataRoot(root,constructionMode));if(constructionMode)ConstructionAccess.PrepareUser(engine,true);listener=new HttpListener();listener.Prefixes.Add("https://+:8765/");listener.TimeoutManager.EntityBody=TimeSpan.FromMinutes(30);listener.TimeoutManager.HeaderWait=TimeSpan.FromSeconds(15);listener.Start();backupTimer=new Timer(_=>{lock(engine){try{engine.RunExternalBackup(false);}catch{}}},null,60000,60000);}
 public void Run(){while(listener.IsListening){HttpListenerContext context;try{context=listener.GetContext();}catch(HttpListenerException){break;}catch(ObjectDisposedException){break;}
  try{lock(engine){Handle(context);}}catch(ApiError ex){SafeReply(context,ex.Status,ex.Message);}catch(HttpListenerException){}catch(IOException){}catch(Exception ex){SafeReply(context,500,"Operazione non riuscita. Ricarica per verificare l'esito; controlla il registro tecnico sul PC centrale.");try{File.AppendAllText(Path.Combine(engine.Root,"server-error.log"),J.Now()+" "+ex.GetType().Name+" durante "+context.Request.Url.AbsolutePath+Environment.NewLine);}catch{}}finally{try{context.Response.Close();}catch{}}
 }}
 private void SafeReply(HttpListenerContext c,int status,string error){try{Reply(c,status,J.Obj("error",error));}catch{}}
 public void Stop(){if(backupTimer!=null)backupTimer.Dispose();listener.Stop();}
 public void Dispose(){if(backupTimer!=null)backupTimer.Dispose();listener.Close();lock(engine){engine.Dispose();}}
 private void Headers(HttpListenerContext c){c.Response.Headers["Cache-Control"]="no-store";c.Response.Headers["X-Content-Type-Options"]="nosniff";c.Response.Headers["Referrer-Policy"]="no-referrer";c.Response.Headers["Content-Security-Policy"]="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";}
 private void Reply(HttpListenerContext c,int status,object data){byte[] bytes=Encoding.UTF8.GetBytes(J.Encode(data));Headers(c);c.Response.StatusCode=status;c.Response.ContentType="application/json; charset=utf-8";c.Response.ContentLength64=bytes.Length;c.Response.OutputStream.Write(bytes,0,bytes.Length);}
 private void Bytes(HttpListenerContext c,byte[] bytes,string contentType){Headers(c);c.Response.ContentType=contentType;c.Response.ContentLength64=bytes.Length;c.Response.OutputStream.Write(bytes,0,bytes.Length);}
 private Dictionary<string,object> Body(HttpListenerRequest req){J.Require(req.ContentLength64>=0&&req.ContentLength64<=192*1024*1024,"Richiesta troppo grande o senza lunghezza.",413);J.Require((req.ContentType??"").StartsWith("application/json"),"Formato richiesta non valido.",415);using(var reader=new StreamReader(req.InputStream,Encoding.UTF8)) {string text=reader.ReadToEnd();try{return J.Parse(text);}catch{throw new ApiError("JSON non valido.");}}}
 private void Origin(HttpListenerRequest req){string origin=req.Headers["Origin"];if(origin!=null)J.Require(origin==req.Url.GetLeftPart(UriPartial.Authority),"Origine della richiesta non consentita.",403);J.Require(req.Headers["Sec-Fetch-Site"]!="cross-site","Richiesta esterna non consentita.",403);}
 private User Authenticate(HttpListenerContext c,bool csrf){Cookie cookie=c.Request.Cookies["VOL_SESSION"];Session session;J.Require(cookie!=null&&sessions.TryGetValue(cookie.Value,out session),"Accesso richiesto.",401);session=sessions[cookie.Value];J.Require(session.Expires>DateTime.UtcNow,"Sessione scaduta.",401);var user=engine.Data.Users.FirstOrDefault(x=>x.Id==session.UserId&&!x.Disabled);J.Require(user!=null,"Utente disabilitato.",401);if(csrf)J.Require(c.Request.Headers["X-CSRF"]==session.Csrf,"Token di sessione non valido.",403);session.Expires=DateTime.UtcNow.AddMinutes(30);return user;}
 private void StartSession(HttpListenerContext c,User user){foreach(var key in sessions.Keys.Where(x=>sessions[x].Expires<DateTime.UtcNow).ToArray())sessions.Remove(key);string token=Crypt.Token(),csrf=Crypt.Token();sessions[token]=new Session{UserId=user.Id,Csrf=csrf,Expires=DateTime.UtcNow.AddMinutes(30)};c.Response.Headers.Add("Set-Cookie","VOL_SESSION="+Uri.EscapeDataString(token)+"; Path=/; Secure; HttpOnly; SameSite=Strict");Reply(c,200,J.Obj("csrf",csrf,"user",Engine.SafeUser(user)));}
 private void Handle(HttpListenerContext c){
  var req=c.Request;string path=req.Url.AbsolutePath;
  if(req.HttpMethod=="GET"&&new[]{"/","/app.js","/operazioni.js","/prezzi.js","/fatture.js","/posta.js","/automezzi.js","/sede.js","/completo.js","/cassa.js","/evoluzione.js","/luoghi-cf.js","/codice-fiscale.js","/aggiornamenti.js","/prenotazioni.js","/prenotazione-guidata.js","/style.css","/manifest.webmanifest","/sw.js","/icon-192.png","/icon-512.png","/icon.svg"}.Contains(path)){string name=path=="/"?"index.html":path.Substring(1);Bytes(c,File.ReadAllBytes(Path.Combine(appPath,name)),name.EndsWith(".js")?"application/javascript; charset=utf-8":name.EndsWith(".css")?"text/css; charset=utf-8":name.EndsWith(".webmanifest")?"application/manifest+json":name.EndsWith(".png")?"image/png":name.EndsWith(".svg")?"image/svg+xml":"text/html; charset=utf-8");return;}
  if(path=="/api/status"&&req.HttpMethod=="GET"){Reply(c,200,J.Obj("setupRequired",!constructionMode&&engine.Data.Users.Count==0,"constructionMode",constructionMode,"version",UpdateManager.Version,"updateStatus",updates.PublicStatus()));return;}
  J.Require(path.StartsWith("/api/"),"Pagina non trovata.",404);Origin(req);
  if(req.HttpMethod=="POST"&&path!="/api/login"&&path!="/api/construction-session")J.Require(!File.Exists(Path.Combine(installationRoot,"Aggiornamenti","manutenzione.flag")),"Aggiornamento in corso. Attendi il riavvio del centrale prima di salvare.",503);
  if(path=="/api/construction-session"&&req.HttpMethod=="POST"){
   J.Require(constructionMode,"Modalita costruzione non attiva.",403);var input=Body(req);J.Require(!J.B(input,"mobile"),"La costruzione senza login si usa dal browser del PC.",403);StartSession(c,ConstructionAccess.PrepareUser(engine,true));return;
  }
  if(path=="/api/login"&&req.HttpMethod=="POST"){
   var b=Body(req);string ip=req.RemoteEndPoint.Address.ToString();List<DateTime> history;if(!attempts.TryGetValue(ip,out history)){history=new List<DateTime>();attempts[ip]=history;}history.RemoveAll(x=>x<DateTime.UtcNow.AddMinutes(-15));J.Require(history.Count<12,"Troppi tentativi. Riprova fra 15 minuti.",429);
   var user=engine.Data.Users.FirstOrDefault(x=>x.Username==J.S(b,"username").Trim().ToLowerInvariant()&&!x.Disabled);history.Add(DateTime.UtcNow);bool valid=false;if(user!=null)valid=Crypt.Equal(Convert.FromBase64String(user.Hash),Convert.FromBase64String(Crypt.Password(J.S(b,"password"),user.Salt)));else Crypt.Password(J.S(b,"password"),Convert.ToBase64String(new byte[16]));J.Require(valid,"Nome utente o password errati.",401);J.Require(!J.B(b,"mobile")||user.Role=="volontario","L app mobile richiede un account volontario collegato all anagrafica.",403);if(user.Role=="volontario")engine.VolunteerIdentity(user);history.Clear();StartSession(c,user);return;
  }
  if(path=="/api/setup"&&req.HttpMethod=="POST"){
   var b=Body(req);J.Require(!J.B(b,"mobile"),"La configurazione iniziale va eseguita dal PC centrale.",403);J.Require(engine.Data.Users.Count==0,"Configurazione iniziale gia' eseguita.",409);string setupFile=Path.Combine(engine.Root,"setup-code.txt");J.Require(File.Exists(setupFile)&&J.S(b,"code")==File.ReadAllText(setupFile).Trim(),"Codice di configurazione errato.",403);
   b["role"]="admin";var actor=new User{Username="installazione",Role="admin"};engine.Change(actor,()=>engine.SaveUser(actor,b),"Configurazione iniziale","users","");File.Delete(setupFile);StartSession(c,engine.Data.Users.First());return;
  }
  User current=Authenticate(c,req.HttpMethod!="GET");
  if(path=="/api/portable-backup-file"&&req.HttpMethod=="GET"){J.Require(current.Role=="admin","Backup riservato all'amministratore.",403);string id=req.QueryString["id"]??"";J.Require(id.Length==32&&id.All(x=>"0123456789abcdef".Contains(x)),"Riferimento copia non valido.");string file=Path.Combine(engine.Root,"DownloadBackup",id+".volbundle");J.Require(File.Exists(file),"Copia non disponibile: generala di nuovo.",404);Headers(c);c.Response.ContentType="application/octet-stream";c.Response.Headers["Content-Disposition"]="attachment; filename=volontariato-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".volbundle";using(var f=File.OpenRead(file)){c.Response.ContentLength64=f.Length;f.CopyTo(c.Response.OutputStream);}return;}
  if(path=="/api/bundle-upload"&&req.HttpMethod=="POST"){J.Require(current.Role=="admin","Ripristino riservato all'amministratore.",403);J.Require(req.ContentLength64>0&&req.ContentLength64<=6L*1024*1024*1024,"Copia troppo grande o lunghezza assente.",413);string dir=Path.Combine(engine.Root,"UploadBackup");Directory.CreateDirectory(dir);foreach(var old in Directory.GetFiles(dir,"*.volbundle").Where(x=>File.GetLastWriteTimeUtc(x)<DateTime.UtcNow.AddDays(-1)))File.Delete(old);string id=J.Id(),file=Path.Combine(dir,id+".volbundle");try{using(var f=new FileStream(file,FileMode.CreateNew,FileAccess.Write,FileShare.None)){byte[] buffer=new byte[65536];long total=0;int read;while((read=req.InputStream.Read(buffer,0,buffer.Length))>0){total+=read;J.Require(total<=req.ContentLength64,"Caricamento troppo grande.");f.Write(buffer,0,read);}J.Require(total==req.ContentLength64,"Caricamento incompleto.");f.Flush(true);}}catch{if(File.Exists(file))File.Delete(file);throw;}Reply(c,200,J.Obj("result",J.Obj("uploadId",id)));return;}

  if(path=="/api/update-status"&&req.HttpMethod=="GET"){Reply(c,200,updates.Status(current,req.IsLocal));return;}
  if(path=="/api/mail-config"&&req.HttpMethod=="GET"){Reply(c,200,engine.MailConfiguration(current));return;}
  if(path=="/api/mail-pdf"&&req.HttpMethod=="POST"){engine.Authorize(current,path);Engine.MailRole(current);var pdfBody=Body(req);var doc=engine.Find("documents",J.S(pdfBody,"id"));J.Require(J.S(doc,"kind")=="Fattura"&&J.S(doc,"status")!="Bozza","Emetti prima la fattura.");J.Require(J.N(doc,"version")==J.N(pdfBody,"version"),"Fattura modificata: ricarica.",409);Bytes(c,Engine.InvoiceMailPdf(doc),"application/pdf");return;}
  if(path=="/api/state"&&req.HttpMethod=="GET"){var view=(Dictionary<string,object>)engine.ViewForUser(current);view["csrf"]=sessions[req.Cookies["VOL_SESSION"].Value].Csrf;view["constructionMode"]=constructionMode;Reply(c,200,view);return;}
  J.Require(req.HttpMethod=="POST","Metodo non consentito.",405);var body=Body(req);engine.Authorize(current,path);object result=null;
  if(path=="/api/logout"){var cookie=req.Cookies["VOL_SESSION"];sessions.Remove(Uri.UnescapeDataString(cookie.Value));c.Response.Headers.Add("Set-Cookie","VOL_SESSION=; Path=/; Max-Age=0; Secure; HttpOnly; SameSite=Strict");Reply(c,200,J.Obj("ok",true));return;}
  if(path=="/api/attachment-download"){var file=engine.GetAttachment(current,J.S(body,"id"));c.Response.Headers["Content-Disposition"]="attachment; filename*=UTF-8''"+Uri.EscapeDataString(J.S(file,"fileName"));Bytes(c,engine.AttachmentBytes(file),J.S(file,"mime"));return;}
  if(path=="/api/update-check")result=updates.Check(current,req.IsLocal);
  else if(path=="/api/update-apply")result=updates.Apply(current,body,req.IsLocal);
  else if(path=="/api/booking-reservation")result=engine.Change(current,()=>engine.SaveBookingReservation(current,body),"Nuova prenotazione guidata","bookings","");
  else if(path=="/api/billing-queue"){Engine.Office(current,false);result=engine.BillingQueue();}
  else if(path=="/api/report")result=engine.Report(current,body);
  else if(path=="/api/ledger"){Engine.Office(current,false);result=engine.CashLedger();}
  else if(path=="/api/import-read")result=engine.ReadExcel(current,body);
  else if(path=="/api/import-preview")result=engine.ImportBatch(current,body,false);
  else if(path=="/api/import-apply")result=engine.Change(current,()=>engine.ImportBatch(current,body,true),"Importazione guidata",J.S(body,"table"),"");
  else if(path=="/api/portable-backup"){result=J.Obj("downloadId",engine.BundleDownload(current,J.S(body,"password")));}
  else if(path=="/api/backup-info")result=engine.BackupInfo(current);
  else if(path=="/api/backup-config")result=engine.Change(current,()=>engine.ConfigureExternalBackup(current,body),"Configurazione backup esterno","backup","");
  else if(path=="/api/backup-now"){J.Require(current.Role=="admin","Backup riservato all amministratore.",403);engine.RunExternalBackup(true);result=engine.BackupInfo(current);}
  else if(path=="/api/verify-bundle"||path=="/api/restore-bundle"){J.Require(current.Role=="admin","Copia riservata all amministratore.",403);string id=J.S(body,"uploadId");J.Require(id.Length==32&&id.All(x=>"0123456789abcdef".Contains(x)),"Riferimento copia non valido.");string file=Path.Combine(engine.Root,"UploadBackup",id+".volbundle");if(path=="/api/verify-bundle"){var copy=engine.ReadBundle(file,J.S(body,"password"),false);result=J.Obj("verified",true,"revision",copy.Revision,"attachments",copy.Tables["attachments"].Count);}else {J.Require(J.B(body,"confirmed")&&J.N(body,"revision")==engine.Data.Revision,"Conferma o revisione ripristino non valida.",409);result=engine.Change(current,()=>engine.RestoreBundle(current,file,J.S(body,"password")),"Ripristino completo","archive","");sessions.Clear();}}
  else if(path=="/api/stock-transfer")result=engine.Change(current,()=>engine.MoveStock(current,body),"Trasferimento materiale","stockTransfers","");
  else if(path=="/api/shift-calendar")result=engine.ShiftCalendar(current,body);
  else if(path=="/api/bank-account")result=engine.BankAccount(current,body);
  else if(path=="/api/bank-opening")result=engine.Change(current,()=>engine.SetBankOpening(current,body),"Saldo iniziale banca","bankOpenings","");
  else if(path=="/api/transfer")result=engine.Change(current,()=>engine.NewTransfer(current,body),"Giroconto","transfers","");
  else if(path=="/api/pos-settle")result=engine.Change(current,()=>engine.SettlePOS(current,body),"Accredito POS","posSettlements","");
  else if(path=="/api/budget-comparison")result=engine.BudgetComparison(current,body);
  else if(path=="/api/expense-report")result=engine.ExpenseReport(current,body);
  else if(path=="/api/cash-account")result=engine.CashAccount(current,body);
  else if(path=="/api/cash-opening")result=engine.Change(current,()=>engine.SetCashOpening(current,body),"Saldo iniziale cassa","cashOpenings","");
  else if(path=="/api/credit-limits"){Engine.Office(current,false);result=engine.CreditLimits(engine.Find("documents",J.S(body,"id")),"");}
  else if(path=="/api/recurring-preview")result=engine.Recurring(current,body,false);
  else if(path=="/api/recurring")result=engine.Change(current,()=>engine.Recurring(current,body,true),"Prenotazioni ricorrenti","recurrenceBatches",J.S(body,"bookingId"));
  else if(path=="/api/promote-activity")result=engine.Change(current,()=>engine.PromoteActivity(current,body),"Attività collegata a servizio","activities",J.S(body,"id"));
  else if(path=="/api/merge-patients")result=engine.Change(current,()=>engine.MergePatients(current,body),"Fusione anagrafiche","patients",J.S(body,"keepId"));
  else if(path=="/api/attachment")result=engine.Change(current,()=>engine.UploadAttachment(current,body),"Allegato","attachments",J.S(body,"targetId"));
  else if(path=="/api/credit")result=engine.Change(current,()=>engine.NewCredit(current,body),"Bozza nota di credito","documents",J.S(body,"originalDocumentId"));
  else if(path=="/api/reverse-payment")result=engine.Change(current,()=>engine.CorrectPayment(current,body,false),"Storno incasso/rimborso","documents",J.S(body,"id"));
  else if(path=="/api/refund")result=engine.Change(current,()=>engine.CorrectPayment(current,body,true),"Rimborso intestatario","documents",J.S(body,"id"));
  else if(path=="/api/document-due")result=engine.Change(current,()=>engine.SetDocumentDue(current,body),"Scadenza incasso","documents",J.S(body,"id"));
  else if(path=="/api/save")result=engine.Change(current,()=>engine.SaveAsUser(current,J.S(body,"table"),J.D(body,"record")),"Salvataggio",J.S(body,"table"),J.S(J.D(body,"record"),"id"));
  else if(path=="/api/archive")result=engine.Change(current,()=>engine.ArchiveAsUser(current,J.S(body,"table"),J.S(body,"id"),J.N(body,"version"),false),"Archiviazione",J.S(body,"table"),J.S(body,"id"));
  else if(path=="/api/unarchive")result=engine.Change(current,()=>engine.ArchiveAsUser(current,J.S(body,"table"),J.S(body,"id"),J.N(body,"version"),true),"Ripristino scheda",J.S(body,"table"),J.S(body,"id"));
  else if(path=="/api/trip")result=engine.Change(current,()=>engine.TripAsUser(current,J.S(body,"bookingId")),"Creazione viaggio","trips",J.S(body,"bookingId"));
  else if(path=="/api/rollcall")result=engine.Change(current,()=>engine.Rollcall(current,body),"Appello equipaggio","attendance",J.S(body,"bookingId"));
  else if(path=="/api/checklist")result=engine.Change(current,()=>engine.NewChecklist(current,J.S(body,"bookingId"),J.S(body,"templateId")),"Creazione checklist","checklists",J.S(body,"bookingId"));
  else if(path=="/api/save-checklist")result=engine.Change(current,()=>engine.SaveChecklist(current,body),"Compilazione checklist","checklists",J.S(body,"id"));
  else if(path=="/api/document")result=engine.Change(current,()=>engine.NewSingleDocument(J.S(body,"bookingId"),J.S(body,"kind"),J.S(body,"paymentMethod")),"Creazione bozza","documents",J.S(body,"bookingId"));
  else if(path=="/api/cumulative")result=engine.Change(current,()=>engine.NewCumulative(body),"Creazione cumulativa","documents",J.S(body,"payerId"));
  else if(path=="/api/refresh-draft")result=engine.Change(current,()=>engine.RefreshDraft(J.S(body,"id"),J.N(body,"version")),"Aggiornamento bozza","documents",J.S(body,"id"));
  else if(path=="/api/issue")result=engine.Change(current,()=>engine.Issue(J.S(body,"id"),J.N(body,"version"),J.S(body,"date")),"Emissione documento","documents",J.S(body,"id"));
  else if(path=="/api/payment")result=engine.Change(current,()=>engine.Payment(body),"Registrazione incasso","documents",J.S(body,"id"));
  else if(path=="/api/delete-draft")result=engine.Change(current,()=>{var d=engine.Find("documents",J.S(body,"id"));J.Require(J.S(d,"status")=="Bozza","Solo le bozze possono essere eliminate.");J.Require(J.N(d,"version")==J.N(body,"version"),"Bozza modificata.",409);engine.Data.Tables["documents"].Remove(d);return J.Obj("ok",true);},"Eliminazione bozza","documents",J.S(body,"id"));
  else if(path=="/api/settings")result=engine.Change(current,()=>engine.Settings(current,J.D(body,"settings"),(long)J.N(body,"revision")),"Impostazioni","settings","");
  else if(path=="/api/mail-config")result=engine.Change(current,()=>engine.ConfigureMail(current,body),"Configurazione posta","mail","");
  else if(path=="/api/prepare-mail")result=engine.PrepareDocumentMail(current,body);
  else if(path=="/api/send-mail")result=engine.SendDocumentMail(current,body);
  else if(path=="/api/user"){result=engine.Change(current,()=>engine.SaveUser(current,body),"Gestione utente","users",J.S(body,"id"));foreach(var key in sessions.Keys.Where(x=>sessions[x].UserId==J.S(body,"id")).ToArray())sessions.Remove(key);}
  else if(path=="/api/backup"){
   J.Require(current.Role=="admin","Backup riservato all'amministratore.",403);byte[] copy=Crypt.Export(Encoding.UTF8.GetBytes(J.S(engine.LegacyBackupState(),"json")),J.S(body,"password"));c.Response.Headers["Content-Disposition"]="attachment; filename=volontariato-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".volbackup";Bytes(c,copy,"application/octet-stream");return;
  }
  else if(path=="/api/restore"){result=engine.Change(current,()=>engine.Restore(current,Convert.FromBase64String(J.S(body,"payload")),J.S(body,"password")),"Ripristino","archive","");sessions.Clear();}
  else throw new ApiError("Operazione non trovata.",404);
  Reply(c,200,J.Obj("result",result,"revision",engine.Data.Revision));
 }
}
public class VolunteerService : ServiceBase {
 private Thread worker;private HttpServer server;
 public VolunteerService(){ServiceName="VolontariatoLAN";CanStop=true;AutoLog=true;}
 protected override void OnStart(string[] args){string root=AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);server=new HttpServer(root);worker=new Thread(server.Run);worker.IsBackground=true;worker.Start();}
 protected override void OnStop(){if(server!=null)server.Stop();if(worker!=null){RequestAdditionalTime(30000);worker.Join(25000);}if(server!=null)server.Dispose();}
}
public static partial class Program {
 private static void Expect(bool ok,string label){if(!ok)throw new Exception("TEST FALLITO: "+label);Console.WriteLine("OK "+label);}
 private static void Reject(Action action,string label){bool rejected=false;try{action();}catch(ApiError){rejected=true;}Expect(rejected,label);}
 private static void CoreSelfTest(){
  string dir=Path.Combine(Path.GetTempPath(),"VolLAN-test-"+J.Id());try {using(var e=new Engine(dir)){
   var admin=new User{Username="test",Role="admin"};e.Data.Settings=J.Obj("association","Associazione TEST","address","Via Test 1","taxCode","00000000000","invoicePrefix","F","receiptPrefix","R");
   var v=e.Save("vehicles",J.Obj("plate","TEST01","initialKm",1000));var patient=e.Save("patients",J.Obj("name","Nome","surname","Test","address","Via Persona 1","taxCode","PERSONATEST"));var payer=e.Save("payers",J.Obj("name","Ente TEST","address","Via Test 2","taxCode","00000000001"));var volunteer=e.Save("volunteers",J.Obj("name","Volontario","surname","Test"));
   var b=e.Save("bookings",J.Obj("type","Trasporto sanitario","title","Servizio TEST","status","Confermata","start","2026-10-06T08:00","end","2026-10-06T10:00","vehicleId",v["id"],"patientId",patient["id"],"payerId",payer["id"],"crewIds",new[]{volunteer["id"]},"baseRate",20,"kmRate",1.25m,"hourRate",5,"extras",3,"discount",2,"vatRate",22,"stamp",0));
   var clash=J.Clone(b);clash.Remove("id");Reject(()=>e.Save("bookings",clash),"Conflitto equipaggio/automezzo");
   var t=e.CreateTrip(J.S(b,"id"));t["kmEnd"]=1020;t["hours"]=2;t["tolls"]=4;t["status"]="Concluso";e.Save("trips",t);Expect(e.Data.Tables["activities"].Count==1,"Attivita' automatica da viaggio");
   var d=e.NewDocument(J.S(b,"id"),"Fattura");Expect(J.N(d,"taxable")==60&&J.N(d,"tax")==13.2m&&J.N(d,"total")==73.2m,"Importi e IVA con arrotondamento");
   d=e.Issue(J.S(d,"id"),J.N(d,"version"),"2026-10-06");Expect(J.S(d,"number")=="F/2026/00001","Numerazione per anno");Reject(()=>e.Issue(J.S(d,"id"),1,"2026-10-06"),"Emissione duplicata bloccata");Reject(()=>e.Save("bookings",b),"Servizio fatturato bloccato");Reject(()=>e.NewDocument(J.S(b,"id"),"Ricevuta"),"Documento doppio bloccato");
   e.Payment(J.Obj("id",d["id"],"version",d["version"],"amount",20,"date","2026-10-06","method","Bonifico"));Expect(J.S(d,"status")=="Parzialmente pagato","Incasso parziale");Reject(()=>e.Payment(J.Obj("id",d["id"],"version",d["version"],"amount",100,"date","2026-10-06")),"Incasso eccedente bloccato");
   var stale=J.Clone(patient);patient["notes"]="Aggiornato";e.Save("patients",patient);Reject(()=>e.Save("patients",stale),"Concorrenza con versione scheda");
   Reject(()=>e.Change(new User{Username="lettura",Role="lettura"},()=>e.Save("patients",J.Obj("name","Test","surname","Negato")),"test","patients",""),"Sola lettura bloccata dal server");
   Reject(()=>e.Settings(new User{Username="operatore",Role="segreteria"},e.Data.Settings,e.Data.Revision),"Impostazioni vietate alla segreteria");
   long revision=e.Data.Revision;Reject(()=>e.Change(admin,()=>{e.Data.Settings["association"]="Sovrascritto";throw new ApiError("test");},"test","", ""),"Rollback modifica fallita");Expect(e.Data.Revision==revision&&J.S(e.Data.Settings,"association")=="Associazione TEST","Stato ripristinato dopo errore");
   byte[] payload=Crypt.Export(Encoding.UTF8.GetBytes(J.Encode(e.Data)),"Password-test-2026");State copy=J.Serializer().Deserialize<State>(Encoding.UTF8.GetString(Crypt.Import(payload,"Password-test-2026")));Engine.ValidateState(copy);Expect(copy.Tables["documents"].Count==1,"Backup cifrato portabile");Reject(()=>Crypt.Import(payload,"password-errata"),"Password backup errata");payload[50]^=1;Reject(()=>Crypt.Import(payload,"Password-test-2026"),"Integrita' backup");e.Persist();PriceSelfTest(e);CumulativeSelfTest(e);MailSelfTest(e);
  }using(var reopened=new Engine(dir)){Expect(reopened.Data.Tables["documents"].Count==1,"Archivio persistente riaperto");}}
  finally {if(Directory.Exists(dir))Directory.Delete(dir,true);}
 }
 private static void ConstructionAccessSelfTest(){
  string root=Path.Combine(Path.GetTempPath(),"VolLAN-costruzione-"+J.Id());Directory.CreateDirectory(root);try{
   Expect(!ConstructionAccess.Enabled(root),"Costruzione disattivata senza attivazione esplicita");
   Expect(ConstructionAccess.DataRoot(root,false)!=ConstructionAccess.DataRoot(root,true),"Archivio costruzione separato da quello ordinario");
   using(var ordinary=new Engine(ConstructionAccess.DataRoot(root,false))){
    ordinary.Save("patients",J.Obj("surname","Archivio","name","Ordinario"));ordinary.Persist();byte[] original=File.ReadAllBytes(Path.Combine(ordinary.Root,"archive.dat"));
    File.WriteAllText(Path.Combine(root,ConstructionAccess.FlagName),"test");Expect(ConstructionAccess.Enabled(root),"Attivazione costruzione tramite configurazione locale");
    string adminId;
    using(var test=new Engine(ConstructionAccess.DataRoot(root,true))){
     Reject(()=>ConstructionAccess.PrepareUser(ordinary,true),"Accesso libero vietato sull archivio ordinario");
     Reject(()=>ConstructionAccess.PrepareUser(test,false),"Accesso libero vietato con modalita disattivata");
     var actor=ConstructionAccess.PrepareUser(test,true);adminId=actor.Id;Expect(actor.Role=="admin"&&!actor.Disabled&&actor.Hash!=""&&actor.Salt!="","Account costruzione pronto senza credenziali nel browser");
     Expect(test.Data.Tables["patients"].Count==0,"Archivio prove non importa persone dall archivio ordinario");
     test.Save("patients",J.Obj("surname","Persona","name","Di prova"));test.Persist();
     Expect(ConstructionAccess.PrepareUser(test,true).Id==adminId&&test.Data.Users.Count==1,"Accesso automatico riusa account senza duplicarlo");
    }
    using(var reopened=new Engine(ConstructionAccess.DataRoot(root,true))){Expect(ConstructionAccess.PrepareUser(reopened,true).Id==adminId&&reopened.Data.Tables["patients"].Count==1,"Dati costruzione conservati dopo riavvio");}
    File.Delete(Path.Combine(root,ConstructionAccess.FlagName));Expect(!ConstructionAccess.Enabled(root)&&ConstructionAccess.DataRoot(root,false)==ordinary.Root,"Riattivazione login ritorna all archivio ordinario");
    Expect(original.SequenceEqual(File.ReadAllBytes(Path.Combine(ordinary.Root,"archive.dat"))),"Archivio ordinario non modificato dalle prove");
   }
  }finally{if(Directory.Exists(root))Directory.Delete(root,true);}
 }
 public static void SelfTest(){
  var suites=new[]{
   new KeyValuePair<string,Action>("CoreSelfTest",CoreSelfTest),
   new KeyValuePair<string,Action>("OperationalSelfTest",OperationalSelfTest),
   new KeyValuePair<string,Action>("RetroactiveSelfTest",RetroactiveSelfTest),
   new KeyValuePair<string,Action>("PatientBillingShiftSelfTest",PatientBillingShiftSelfTest),
   new KeyValuePair<string,Action>("VehicleCareSelfTest",VehicleCareSelfTest),
   new KeyValuePair<string,Action>("VehicleHygieneSelfTest",VehicleHygieneSelfTest),
   new KeyValuePair<string,Action>("SiteSelfTest",SiteSelfTest),
   new KeyValuePair<string,Action>("VolunteerStockSelfTest",VolunteerStockSelfTest),
   new KeyValuePair<string,Action>("CompleteSelfTest",CompleteSelfTest),
   new KeyValuePair<string,Action>("SharedTravelSelfTest",SharedTravelSelfTest),
   new KeyValuePair<string,Action>("CashSelfTest",CashSelfTest),
   new KeyValuePair<string,Action>("BudgetSelfTest",BudgetSelfTest),
   new KeyValuePair<string,Action>("EvolutionSelfTest",EvolutionSelfTest),
   new KeyValuePair<string,Action>("VaultSelfTest",VaultSelfTest),
   new KeyValuePair<string,Action>("PatientBirthSelfTest",PatientBirthSelfTest),
   new KeyValuePair<string,Action>("ConstructionAccessSelfTest",ConstructionAccessSelfTest),
   new KeyValuePair<string,Action>("UpdateManifestSelfTest",UpdateManifestSelfTest),
   new KeyValuePair<string,Action>("TransportBookingSelfTest",TransportBookingSelfTest),
   new KeyValuePair<string,Action>("BookingWizardSelfTest",BookingWizardSelfTest)
  };var failures=new List<string>();
  foreach(var suite in suites){Console.WriteLine("VERIFICA "+suite.Key);try{suite.Value();}catch(Exception ex){failures.Add(suite.Key);Console.WriteLine("ERRORE TEST "+suite.Key+": "+ex.Message);}}
  if(failures.Count>0)throw new Exception("Verifiche interne non superate: "+string.Join(", ",failures)+". Il servizio non viene installato.");
  Console.WriteLine("TUTTI I TEST SUPERATI");
 }
 public static int Main(string[] args){try{if(args.Contains("--self-test")){SelfTest();return 0;}if(args.Length==2&&args[0]=="--check-archive"){Engine.ValidateState(J.Serializer().Deserialize<State>(Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(args[1]),null,DataProtectionScope.LocalMachine))));Console.WriteLine("Archivio verificato.");return 0;}if(args.Contains("--console")){using(var server=new HttpServer(AppDomain.CurrentDomain.BaseDirectory))server.Run();return 0;}ServiceBase.Run(new VolunteerService());return 0;}catch(Exception ex){Console.Error.WriteLine(ex.Message);return 1;}}
}
}
