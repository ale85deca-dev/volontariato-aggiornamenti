﻿$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'AggiornamentiComuni.ps1')
foreach ($script in Get-ChildItem $PSScriptRoot -Filter '*.ps1' -File) {
    $tokens=$null;$syntaxErrors=$null
    $null=[System.Management.Automation.Language.Parser]::ParseFile($script.FullName,[ref]$tokens,[ref]$syntaxErrors)
    if ($syntaxErrors.Count -gt 0) {throw ('Sintassi PowerShell non valida: '+$script.Name+' - '+$syntaxErrors[0].Message)}
}
Add-Type -AssemblyName System.IO.Compression
function Assert-Rejected([ScriptBlock]$Action,[string]$Label) {
    $rejected=$false
    try {$null=& $Action} catch {$rejected=$true}
    if (-not $rejected) {throw ('TEST FALLITO: '+$Label)}
    Write-Output ('OK '+$Label)
}
function Write-FixtureZip([string]$Path,[hashtable]$Files) {
    $stream=[IO.File]::Create($Path);$archive=$null
    try {
        $archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
        foreach ($key in $Files.Keys) {
            $entry=$archive.CreateEntry($key);$output=$entry.Open()
            try {$bytes=[Text.Encoding]::UTF8.GetBytes([string]$Files[$key]);$output.Write($bytes,0,$bytes.Length)} finally {$output.Dispose()}
        }
    } finally {if ($archive) {$archive.Dispose()};$stream.Dispose()}
}
$temporary=Join-Path ([IO.Path]::GetTempPath()) ('VolLAN-update-test-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $temporary | Out-Null
try {
    $uri=Assert-UpdateHttps 'https://updates.example.org/aggiornamento.json'
    if ($uri.Scheme -ne 'https') {throw 'Fonte HTTPS non riconosciuta.'}
    Assert-Rejected {Assert-UpdateHttps 'http://example.org/file.json'} 'Fonte HTTP vietata'
    Assert-Rejected {Assert-UpdateHttps 'https://user:password@example.org/file.json'} 'Credenziali in URL vietate'
    Assert-Rejected {Assert-UpdateHttps 'https://example.org/file.json?token=segreto'} 'Parametri in URL vietati'
    $zip=Join-Path $temporary 'pericoloso.zip'
    Write-FixtureZip $zip @{'VolontariatoLAN/../esterno.txt'='test'}
    Assert-Rejected {Expand-VerifiedUpdate $zip (Join-Path $temporary 'slip')} 'Percorso esterno nello ZIP vietato'
    Write-FixtureZip $zip @{'VolontariatoLAN/Dati/archive.dat'='test'}
    Assert-Rejected {Expand-VerifiedUpdate $zip (Join-Path $temporary 'dati')} 'Archivio dati nel pacchetto vietato'
    $files=@{'App/index.html'='test';'App/app.js'='test';'Sorgenti/Server.cs'='test';'Sorgenti/Aggiornamenti.cs'='test';'versione.json'='{"application":"VolontariatoLAN","version":"1.8.6"}'}
    $hashes=@{};$entries=@{};$sha=[Security.Cryptography.SHA256]::Create()
    try {foreach ($key in $files.Keys) {$hashes[$key]=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($files[$key])))).Replace('-','').ToLowerInvariant();$entries['VolontariatoLAN/'+$key]=$files[$key]}} finally {$sha.Dispose()}
    $entries['VolontariatoLAN/Integrita_SHA256.json']=$hashes | ConvertTo-Json
    Write-FixtureZip $zip $entries
    $valid=Expand-VerifiedUpdate $zip (Join-Path $temporary 'valido')
    if (-not (Test-Path (Join-Path $valid 'App/app.js'))) {throw 'Pacchetto valido non estratto.'}
    Write-Output 'OK Pacchetto verificato senza modificare il gestionale'
    $entries['VolontariatoLAN/App/app.js']='contenuto alterato'
    Write-FixtureZip $zip $entries
    Assert-Rejected {Expand-VerifiedUpdate $zip (Join-Path $temporary 'corrotto')} 'File alterato vietato'
    Write-Output 'VERIFICHE COMPONENTE AGGIORNAMENTI SUPERATE'
} finally {Remove-Item $temporary -Recurse -Force}
