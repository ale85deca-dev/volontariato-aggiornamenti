﻿param([string]$Root=(Join-Path $env:ProgramData 'VolontariatoLAN'))
$ErrorActionPreference='Stop'
$area=Join-Path $Root 'Aggiornamenti'
New-Item -ItemType Directory $area -Force | Out-Null
foreach ($name in @('AggiornamentiComuni.ps1','AggiornaAutomatico.ps1','ConfiguraAggiornamenti.ps1','ConfiguraAggiornamenti.cmd')) {
    $source=Join-Path $PSScriptRoot $name;$target=Join-Path $Root $name
    if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($target)) { Copy-Item $source $target -Force }
}
& icacls.exe $area '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' '*S-1-5-19:(OI)(CI)RX' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Permessi componente aggiornamenti non impostati.' }
$serviceArea=Join-Path $area 'Servizio'
New-Item -ItemType Directory $serviceArea -Force | Out-Null
& icacls.exe $serviceArea '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' '*S-1-5-19:(OI)(CI)M' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Permessi stato aggiornamenti non impostati.' }
$action=New-ScheduledTaskAction -Execute (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe') -Argument ('-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $Root 'AggiornaAutomatico.ps1')+'"')
$principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName 'VolontariatoLAN-Aggiornamento' -Action $action -Principal $principal -Settings $settings -Force | Out-Null
$scheduler=New-Object -ComObject 'Schedule.Service';$scheduler.Connect()
$task=$scheduler.GetFolder('\').GetTask('VolontariatoLAN-Aggiornamento')
$task.SetSecurityDescriptor('D:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;GRGX;;;LS)',0)
[IO.File]::WriteAllText((Join-Path $area 'installato.flag'),'1.8.6')
Write-Host 'Componente aggiornamenti dal gestionale attivato.' -ForegroundColor Green
