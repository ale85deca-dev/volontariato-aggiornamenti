﻿function Assert-UpdateHttps([string]$Value) {
    $uri=$null
    if (-not [Uri]::TryCreate($Value,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment) { throw 'Usa una fonte HTTPS senza credenziali, parametri o frammenti.' }
    return $uri
}
function Get-UpdateFile([Uri]$Uri,[string]$Destination,[long]$Limit,[int]$TimeoutMilliseconds=30000) {
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    $request=[Net.HttpWebRequest]::Create($Uri)
    $request.AllowAutoRedirect=$false
    $request.Timeout=$TimeoutMilliseconds
    $request.ReadWriteTimeout=$TimeoutMilliseconds
    $response=$null;$inputStream=$null;$outputStream=$null
    try {
        $response=$request.GetResponse()
        if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -gt $Limit) { throw 'Risposta della fonte non valida.' }
        $inputStream=$response.GetResponseStream();$outputStream=[IO.File]::Create($Destination)
        $buffer=New-Object byte[] 65536
        [long]$total=0
        while (($read=$inputStream.Read($buffer,0,$buffer.Length)) -gt 0) {
            $total+=$read
            if ($total -gt $Limit) { throw 'Download oltre il limite previsto.' }
            $outputStream.Write($buffer,0,$read)
        }
        $outputStream.Flush($true)
        if ($response.ContentLength -ge 0 -and $total -ne $response.ContentLength) { throw 'Download incompleto.' }
    } finally {
        if ($outputStream) { $outputStream.Dispose() };if ($inputStream) { $inputStream.Dispose() };if ($response) { $response.Close() }
    }
}
function Read-UpdateManifest([string]$Source,[string]$TemporaryFile,[string]$CurrentVersion) {
    $uri=Assert-UpdateHttps $Source
    Get-UpdateFile $uri $TemporaryFile 65536
    $manifest=[IO.File]::ReadAllText($TemporaryFile,[Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($manifest.application -ne 'VolontariatoLAN' -or $manifest.schema -ne 1 -or $manifest.version -notmatch '^\d+\.\d+\.\d+$') { throw 'Fonte o versione aggiornamento non valida.' }
    if ($manifest.minimumVersion -and [Version]$manifest.minimumVersion -gt [Version]$CurrentVersion) { throw 'Occorre prima una versione intermedia.' }
    $packageUri=Assert-UpdateHttps ([string]$manifest.packageUrl)
    if ($packageUri.Authority -ne $uri.Authority) { throw 'Pacchetto fuori dalla fonte configurata.' }
    if ($manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or [long]$manifest.size -le 0 -or [long]$manifest.size -gt 33554432) { throw 'Impronta o dimensione pacchetto non valida.' }
    return $manifest
}
function Expand-VerifiedUpdate([string]$Zip,[string]$Destination) {
    Add-Type -AssemblyName System.IO.Compression
    $archive=$null;$stream=[IO.File]::OpenRead($Zip)
    $safeRoot=[IO.Path]::GetFullPath($Destination).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
    New-Item -ItemType Directory $Destination -Force | Out-Null
    $seen=@{};[long]$total=0
    try {
        $archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Read,$false)
        if ($archive.Entries.Count -gt 2000) { throw 'Troppi file nel pacchetto.' }
        foreach ($entry in $archive.Entries) {
            $name=$entry.FullName.Replace('\','/')
            if (-not $name.StartsWith('VolontariatoLAN/',[StringComparison]::Ordinal) -or $name -match '(^|/)\.\.?(/|$)|:|^/' -or $seen.ContainsKey($name)) { throw 'Percorso nel pacchetto non valido o duplicato.' }
            $seen[$name]=$true
            if ((($entry.ExternalAttributes -shr 16) -band 61440) -eq 40960 -or ($entry.ExternalAttributes -band 1024) -ne 0) { throw 'Collegamenti nel pacchetto non ammessi.' }
            $total+=$entry.Length
            if ($total -gt 134217728) { throw 'Pacchetto decompresso oltre 128 MiB.' }
            $relative=$name.Substring(('VolontariatoLAN/').Length)
            if (-not $relative) { continue }
            if ($name.EndsWith('/')) { continue }
            if ($relative -notmatch '^(App/[^:]+\.(js|html|css|png|svg|webmanifest)|Sorgenti/[^/]+\.cs|[^/]+\.(ps1|cmd|txt|md|pdf|json))$') { throw 'File non previsto nel pacchetto.' }
            $target=[IO.Path]::GetFullPath((Join-Path $Destination $name))
            if (-not $target.StartsWith($safeRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Percorso esterno al pacchetto.' }
            New-Item -ItemType Directory ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
            $sourceStream=$entry.Open();$targetStream=$null
            try {
                $targetStream=[IO.File]::Create($target);$buffer=New-Object byte[] 65536;[long]$written=0
                while (($read=$sourceStream.Read($buffer,0,$buffer.Length)) -gt 0) {
                    $written+=$read
                    if ($written -gt $entry.Length) {throw 'Dimensione file decompresso non valida.'}
                    $targetStream.Write($buffer,0,$read)
                }
                if ($written -ne $entry.Length) {throw 'File decompresso incompleto.'}
                $targetStream.Flush($true)
            } finally { if ($targetStream) {$targetStream.Dispose()};$sourceStream.Dispose() }
        }
    } finally {if ($archive) {$archive.Dispose()};$stream.Dispose()}
    $package=Join-Path $Destination 'VolontariatoLAN'
    $integrityFile=Join-Path $package 'Integrita_SHA256.json'
    if (-not (Test-Path $integrityFile)) { throw 'Controllo integrita assente.' }
    $hashes=Get-Content $integrityFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $verified=@{}
    foreach ($property in $hashes.PSObject.Properties) {
        $relative=$property.Name
        if ($relative -match '(^|[\\/])\.\.?([\\/]|$)|:|^[\\/]' -or $property.Value -notmatch '^[a-fA-F0-9]{64}$') { throw 'Indice integrita non valido.' }
        $file=[IO.Path]::GetFullPath((Join-Path $package $relative))
        if (-not $file.StartsWith(([IO.Path]::GetFullPath($package)+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $file -PathType Leaf)) { throw 'File dell aggiornamento mancante.' }
        if ((Get-FileHash $file -Algorithm SHA256).Hash -ne $property.Value) { throw 'File dell aggiornamento danneggiato.' }
        $verified[$relative.Replace('\','/')]=$true
    }
    foreach ($file in Get-ChildItem $package -Recurse -File) {
        $relative=$file.FullName.Substring($package.Length+1).Replace('\','/')
        if ($relative -ne 'Integrita_SHA256.json' -and -not $verified.ContainsKey($relative)) { throw 'File non verificato nel pacchetto.' }
    }
    foreach ($mandatory in @('App/index.html','App/app.js','Sorgenti/Server.cs','Sorgenti/Aggiornamenti.cs','versione.json')) {
        if (-not $verified.ContainsKey($mandatory)) { throw 'Pacchetto applicazione incompleto.' }
    }
    return $package
}
