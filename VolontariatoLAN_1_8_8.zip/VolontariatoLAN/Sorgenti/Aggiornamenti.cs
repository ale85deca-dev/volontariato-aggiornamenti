﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using System.Globalization;

namespace VolontariatoLAN {
public class UpdateManager {
 public const string Version="1.8.8";
 public const string TaskName="VolontariatoLAN-Aggiornamento";
 private string root,area,serviceArea;private Dictionary<string,object> candidate;
 public UpdateManager(string installationRoot){root=installationRoot;area=Path.Combine(root,"Aggiornamenti");serviceArea=Path.Combine(area,"Servizio");}
 public static void Admin(User user){J.Require(user!=null&&user.Role=="admin","Aggiornamenti riservati all amministratore.",403);}
 public static Uri Https(string value){Uri uri;J.Require(Uri.TryCreate(value,UriKind.Absolute,out uri)&&uri.Scheme=="https"&&uri.UserInfo==""&&uri.Fragment==""&&uri.Query=="","La fonte deve essere un indirizzo HTTPS senza credenziali, parametri o frammenti.");return uri;}
 public static Dictionary<string,object> ValidateManifest(Dictionary<string,object> manifest,Uri source){
  J.Require(J.S(manifest,"application")=="VolontariatoLAN"&&J.N(manifest,"schema")==1,"Fonte aggiornamenti non riconosciuta.");
  System.Version version,minimum;J.Require(System.Version.TryParse(J.S(manifest,"version"),out version)&&version.Build>=0&&version.Revision<0,"Versione aggiornamento non valida.");
  if(J.S(manifest,"minimumVersion")!="")J.Require(System.Version.TryParse(J.S(manifest,"minimumVersion"),out minimum)&&minimum<=System.Version.Parse(Version),"Questo aggiornamento richiede prima una versione intermedia.");
  var package=Https(J.S(manifest,"packageUrl"));J.Require(package.Authority.Equals(source.Authority,StringComparison.OrdinalIgnoreCase),"Il pacchetto deve appartenere alla fonte HTTPS configurata.");
  J.Require(System.Text.RegularExpressions.Regex.IsMatch(J.S(manifest,"sha256"),"^[a-fA-F0-9]{64}$"),"Impronta del pacchetto non valida.");
  decimal size=J.N(manifest,"size");J.Require(size>0&&size<=32*1024*1024&&size==Math.Truncate(size),"Dimensione pacchetto non valida (massimo 32 MiB).");
  J.Require(J.S(manifest,"notes").Length<=4000,"Descrizione aggiornamento troppo lunga.");return manifest;
 }
 public static byte[] Download(Uri uri,int limit){
  ServicePointManager.SecurityProtocol=(SecurityProtocolType)3072;
  var request=(HttpWebRequest)WebRequest.Create(uri);request.AllowAutoRedirect=false;request.Timeout=15000;request.ReadWriteTimeout=15000;
  try{using(var response=(HttpWebResponse)request.GetResponse()){
   J.Require(response.StatusCode==HttpStatusCode.OK,"La fonte non restituisce un aggiornamento valido.");J.Require(response.ContentLength<=limit,"Risposta della fonte troppo grande.");
   using(var stream=response.GetResponseStream())using(var output=new MemoryStream()){byte[] buffer=new byte[8192];int read;while((read=stream.Read(buffer,0,buffer.Length))>0){J.Require(output.Length+read<=limit,"Risposta della fonte troppo grande.");output.Write(buffer,0,read);}return output.ToArray();}
  }}catch(WebException){throw new ApiError("Fonte aggiornamenti non raggiungibile. Verifica Internet e la configurazione; il gestionale resta utilizzabile.");}
 }
 private Dictionary<string,object> Config(){string file=Path.Combine(area,"fonte.json");return File.Exists(file)?J.Parse(File.ReadAllText(file,Encoding.UTF8)):J.Obj();}
 public object PublicStatus(){string file=Path.Combine(serviceArea,"stato.json");if(!File.Exists(file))return J.Obj("stage","idle","message","");try{var r=J.Parse(File.ReadAllText(file,Encoding.UTF8));return J.Obj("stage",J.S(r,"stage"),"message",J.S(r,"message"),"targetVersion",J.S(r,"targetVersion"),"updatedAt",J.S(r,"updatedAt"));}catch{return J.Obj("stage","working","message","Aggiornamento dello stato in corso.");}}
 public object Status(User user,bool local){Admin(user);var cfg=Config();return J.Obj("installedVersion",Version,"configured",J.S(cfg,"manifestUrl")!="","sourceUrl",J.S(cfg,"manifestUrl"),"ready",File.Exists(Path.Combine(area,"installato.flag")),"canApply",local,"progress",PublicStatus());}
 public object Check(User user,bool local){Admin(user);var cfg=Config();J.Require(J.S(cfg,"manifestUrl")!="","Configura prima la fonte sul PC centrale con ConfiguraAggiornamenti.cmd.");candidate=null;
  var source=Https(J.S(cfg,"manifestUrl"));var manifest=ValidateManifest(J.Parse(Encoding.UTF8.GetString(Download(source,64*1024)).TrimStart('\ufeff')),source);candidate=J.Clone(manifest);
  return J.Obj("installedVersion",Version,"available",System.Version.Parse(J.S(manifest,"version"))>System.Version.Parse(Version),"version",J.S(manifest,"version"),"notes",J.S(manifest,"notes"),"size",J.N(manifest,"size"),"sha256",J.S(manifest,"sha256"),"canApply",local);
 }
 public object Apply(User user,Dictionary<string,object> input,bool local){
  Admin(user);J.Require(local,"Avvia l installazione dal browser del PC centrale.",403);J.Require(File.Exists(Path.Combine(area,"installato.flag")),"Completa prima l attivazione del componente aggiornamenti sul PC centrale.");
  J.Require(candidate!=null&&J.S(input,"version")==J.S(candidate,"version")&&J.S(input,"sha256").Equals(J.S(candidate,"sha256"),StringComparison.OrdinalIgnoreCase),"Controlla nuovamente la versione disponibile prima di aggiornare.",409);
  J.Require(System.Version.Parse(J.S(candidate,"version"))>System.Version.Parse(Version),"Il gestionale e gia aggiornato.");
  string pending=Path.Combine(serviceArea,"richiesta.json");J.Require(!File.Exists(pending),"Un aggiornamento e gia in coda.",409);string id=J.Id();
  var job=J.Obj("id",id,"version",J.S(candidate,"version"),"sha256",J.S(candidate,"sha256"),"requestedAt",J.Now());
  string temporary=pending+".tmp";File.WriteAllText(temporary,J.Encode(job),Encoding.UTF8);File.Move(temporary,pending);
  bool startConfirmed=false;bool startUncertain=false;
  try{File.WriteAllText(Path.Combine(serviceArea,"stato.json"),J.Encode(J.Obj("stage","queued","message","Aggiornamento in coda sul PC centrale.","targetVersion",J.S(candidate,"version"),"updatedAt",J.Now())),Encoding.UTF8);
   var info=new ProcessStartInfo{FileName=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"schtasks.exe"),Arguments="/Run /TN "+TaskName,UseShellExecute=false,CreateNoWindow=true};using(var p=Process.Start(info)){if(!p.WaitForExit(5000)){startUncertain=true;try{p.Kill();}catch{}throw new ApiError("Avvio aggiornamento non confermato. Controlla lo stato sul PC centrale prima di riprovare.");}J.Require(p.ExitCode==0,"Windows non ha avviato il componente aggiornamenti. Controlla la configurazione sul PC centrale.");startConfirmed=true;}}
  catch{if(!startConfirmed&&!startUncertain){if(File.Exists(pending))File.Delete(pending);File.WriteAllText(Path.Combine(serviceArea,"stato.json"),J.Encode(J.Obj("stage","failed","message","Componente Windows non avviato. Controlla il PC centrale.","targetVersion",J.S(candidate,"version"),"updatedAt",J.Now())),Encoding.UTF8);}throw;}
  candidate=null;return J.Obj("queued",true,"id",id,"message","Aggiornamento avviato. Il servizio gestionale verra riavviato automaticamente.");
 }
}
public static partial class Program {
 private static void UpdateManifestSelfTest(){
  var source=UpdateManager.Https("https://updates.example.org/latest.json");var manifest=J.Obj("schema",1,"application","VolontariatoLAN","version","1.8.7","minimumVersion","1.8.5","packageUrl","https://updates.example.org/1.8.7.zip","sha256",new string('a',64),"size",1234);
  Expect(UpdateManager.ValidateManifest(manifest,source)==manifest,"Aggiornamenti: versione, HTTPS, host, dimensione e impronta verificati");
  Reject(()=>UpdateManager.Admin(new User{Role="segreteria"}),"Aggiornamenti vietati alla segreteria");Reject(()=>UpdateManager.Admin(new User{Role="volontario"}),"Aggiornamenti vietati al volontario");
  Reject(()=>UpdateManager.Https("http://updates.example.org/latest.json"),"Fonte HTTP non protetta vietata");Reject(()=>UpdateManager.Https("https://user:pass@updates.example.org/latest.json"),"Credenziali nella fonte vietate");
  var wrong=J.Clone(manifest);wrong["packageUrl"]="https://other.example.org/file.zip";Reject(()=>UpdateManager.ValidateManifest(wrong,source),"Pacchetto fuori dalla fonte vietato");
  wrong=J.Clone(manifest);wrong["size"]=33*1024*1024;Reject(()=>UpdateManager.ValidateManifest(wrong,source),"Pacchetto oltre limite vietato");
  wrong=J.Clone(manifest);wrong["sha256"]="errato";Reject(()=>UpdateManager.ValidateManifest(wrong,source),"Impronta non valida vietata");
  wrong=J.Clone(manifest);wrong["minimumVersion"]="99.0.0";Reject(()=>UpdateManager.ValidateManifest(wrong,source),"Aggiornamento incompatibile vietato");
  string folder=Path.Combine(Path.GetTempPath(),"VolLAN-update-test-"+J.Id());Directory.CreateDirectory(folder);
  try{var manager=new UpdateManager(folder);var admin=new User{Role="admin"};
   Reject(()=>manager.Check(admin,true),"Fonte assente: controllo fermato senza download");
   Reject(()=>manager.Status(new User{Role="lettura"},true),"Stato aggiornamenti riservato all amministratore");
   Reject(()=>manager.Apply(admin,J.Obj(),false),"Installazione da altro PC vietata dal server");
   Reject(()=>manager.Apply(admin,J.Obj(),true),"Componente Windows mancante blocca installazione");
   Directory.CreateDirectory(Path.Combine(folder,"Aggiornamenti"));File.WriteAllText(Path.Combine(folder,"Aggiornamenti","installato.flag"),UpdateManager.Version);
   Reject(()=>manager.Apply(admin,J.Obj("version","1.8.7","sha256",new string('a',64)),true),"Installazione senza controllo versione vietata");
   Expect(!File.Exists(Path.Combine(folder,"Aggiornamenti","Servizio","richiesta.json")),"Richiesta non valida non crea lavoro Windows");
  }finally{Directory.Delete(folder,true);}
 }
}
}
