﻿// Controlli di installazione in sola lettura, indipendenti dall'output di netsh.
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;

namespace VolontariatoLAN.Installazione {
 public static class HttpConfigurazione {
  private const uint Config = 2;
  [StructLayout(LayoutKind.Sequential)]
  private struct Version { public ushort Major; public ushort Minor; }
  // URLACL_QUERY e SSL_QUERY hanno lo stesso layout: enum, puntatore alla chiave, DWORD.
  [StructLayout(LayoutKind.Sequential)]
  private struct Query { public int Kind; public IntPtr Key; public uint Token; }
  [DllImport("httpapi.dll", ExactSpelling = true)]
  private static extern uint HttpInitialize(Version version, uint flags, IntPtr reserved);
  [DllImport("httpapi.dll", ExactSpelling = true)]
  private static extern uint HttpTerminate(uint flags, IntPtr reserved);
  [DllImport("httpapi.dll", ExactSpelling = true)]
  private static extern uint HttpQueryServiceConfiguration(IntPtr handle, int id, ref Query query,
   uint inputLength, IntPtr output, uint outputLength, out uint needed, IntPtr overlapped);

  private static bool Missing(uint code) { return code == 2 || code == 259 || code == 1168; }
  private static void Check(uint code) { if(code != 0) throw new Win32Exception((int)code); }
  private static void Initialize() { Check(HttpInitialize(new Version { Major = 1, Minor = 0 }, Config, IntPtr.Zero)); }
  private static uint Probe(int id, ref Query query, out uint needed) {
   uint code = HttpQueryServiceConfiguration(IntPtr.Zero, id, ref query,
    (uint)Marshal.SizeOf(typeof(Query)), IntPtr.Zero, 0, out needed, IntPtr.Zero);
   if(Missing(code)) return code;
   if(code != 0 && code != 122 && code != 234) Check(code);
   return code;
  }
  public static void CheckInterop() {
   int expectedSize = IntPtr.Size == 8 ? 24 : 12;
   int expectedKeyOffset = IntPtr.Size == 8 ? 8 : 4;
   if(Marshal.SizeOf(typeof(Query)) != expectedSize || Marshal.OffsetOf(typeof(Query), "Key").ToInt32() != expectedKeyOffset || Marshal.SizeOf(typeof(Version)) != 4)
    throw new InvalidOperationException("Layout HTTPAPI non compatibile.");
   if(!CompatiblePermissions("D:(A;;GX;;;LS)") || !CompatiblePermissions("D:(A;;GX;;;S-1-5-19)") || CompatiblePermissions(null) || CompatiblePermissions("D:(A;;GX;;;WD)") || CompatiblePermissions("D:(A;;GA;;;LS)") || CompatiblePermissions("D:(D;;GX;;;LS)") || CompatiblePermissions("D:(A;;GX;;;LS)(A;;GX;;;WD)"))
    throw new InvalidOperationException("Verifica permessi HTTPAPI non superata.");
  }
  public static string UrlPermissions(string url) {
   Initialize(); IntPtr key = IntPtr.Zero, output = IntPtr.Zero;
   try {
    key = Marshal.StringToHGlobalUni(url);
    var query = new Query { Kind = 0, Key = key }; uint needed;
    uint code = Probe(2, ref query, out needed);
    if(Missing(code)) return null;
    if(needed < 2 * IntPtr.Size || needed > 1024 * 1024) throw new InvalidOperationException("Risposta URLACL non valida.");
    output = Marshal.AllocHGlobal((int)needed);
    Check(HttpQueryServiceConfiguration(IntPtr.Zero, 2, ref query, (uint)Marshal.SizeOf(typeof(Query)), output, needed, out needed, IntPtr.Zero));
    // URLACL_SET contiene due puntatori: prefisso URL e descrittore SDDL.
    IntPtr sddl = Marshal.ReadIntPtr(output, IntPtr.Size);
    if(sddl == IntPtr.Zero) throw new InvalidOperationException("Permessi URLACL mancanti.");
    return Marshal.PtrToStringUni(sddl);
   } finally {
    if(output != IntPtr.Zero) Marshal.FreeHGlobal(output);
    if(key != IntPtr.Zero) Marshal.FreeHGlobal(key);
    HttpTerminate(Config, IntPtr.Zero);
   }
  }
  public static bool CompatiblePermissions(string sddl) {
   if(string.IsNullOrEmpty(sddl)) return false;
   try {
    var actual = new RawSecurityDescriptor(sddl);
    var expected = new RawSecurityDescriptor("D:(A;;GX;;;LS)");
    return actual.GetSddlForm(AccessControlSections.Access) == expected.GetSddlForm(AccessControlSections.Access);
   } catch(ArgumentException) { return false; }
  }
  public static bool HasSslBinding(bool ipv6, ushort port) {
   Initialize(); IntPtr key = IntPtr.Zero;
   try {
    // sockaddr_in / sockaddr_in6: famiglia little endian, porta network order, IP nullo.
    byte[] address = new byte[ipv6 ? 28 : 16];
    address[0] = (byte)(ipv6 ? 23 : 2); address[2] = (byte)(port >> 8); address[3] = (byte)port;
    key = Marshal.AllocHGlobal(address.Length); Marshal.Copy(address, 0, key, address.Length);
    var query = new Query { Kind = 0, Key = key }; uint needed;
    return !Missing(Probe(1, ref query, out needed));
   } finally {
    if(key != IntPtr.Zero) Marshal.FreeHGlobal(key);
    HttpTerminate(Config, IntPtr.Zero);
   }
  }
 }
}
