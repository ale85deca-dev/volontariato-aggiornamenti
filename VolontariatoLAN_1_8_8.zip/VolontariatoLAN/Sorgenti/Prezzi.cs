﻿// Composizione del prezzo viaggio: tutti gli importi sono IVA esclusa.
using System;
using System.Linq;
using System.Collections.Generic;
namespace VolontariatoLAN {
public partial class Engine {
 public static readonly string[] ProtectedPriceFields={"pricingMode","specificRate","priceLines","tariffId","tariffName","contractRef","baseRate","kmRate","hourRate","extras","discount","vatRate","taxReason","stamp"};
 public static readonly string[] NumericPriceFields={"specificRate","baseRate","kmRate","hourRate","extras","discount","vatRate","stamp"};
 public Dictionary<string,object> DefaultBookingPrice(){return J.Obj("pricingMode","Standard","specificRate","","priceLines",new object[0],"tariffId","","tariffName","","contractRef","","baseRate",J.N(Data.Settings,"baseRate"),"kmRate",J.N(Data.Settings,"kmRate"),"hourRate",J.N(Data.Settings,"hourRate"),"extras",0,"discount",0,"vatRate",J.S(Data.Settings,"vatRate"),"taxReason",J.S(Data.Settings,"taxReason"),"stamp",0);}
 public void GuardPriceEdit(User user,string table,Dictionary<string,object> row){
  if(user.Role=="admin")return;
  if(table=="bookings"){
   var previous=J.S(row,"id")==""?null:Find("bookings",J.S(row,"id"));if(previous!=null)J.Require(J.N(previous,"version")==J.N(row,"version"),"Prenotazione modificata: ricarica prima di salvare.",409);var expected=previous??DefaultBookingPrice();
   foreach(string field in ProtectedPriceFields){bool equal=true;if(row.ContainsKey(field)){
    if(field=="priceLines")equal=J.Encode(PriceLines(row))==J.Encode(PriceLines(expected));
    else if(field=="pricingMode")equal=PriceMode(row)==PriceMode(expected);
    else if(NumericPriceFields.Contains(field))equal=(J.S(row,field)=="")==(J.S(expected,field)=="")&&J.N(row,field)==J.N(expected,field);
    else equal=J.S(row,field)==J.S(expected,field);
   }J.Require(equal,"Solo l'amministratore puo' modificare prezzi, tariffe, sconti e trattamento fiscale.",403);if(expected.ContainsKey(field))row[field]=J.Clone(expected[field]);else row.Remove(field);}
  }
  if(table=="trips"){
   var previous=J.S(row,"id")==""?null:Find("trips",J.S(row,"id"));decimal tolls=previous==null?0:J.N(previous,"tolls");J.Require(!row.ContainsKey("tolls")||J.N(row,"tolls")==tolls,"Solo l'amministratore puo' modificare gli importi addebitabili del viaggio.",403);row["tolls"]=tolls;
  }
 }
 public string PriceMode(Dictionary<string,object> row){return J.S(row,"pricingMode")==""?"Standard":J.S(row,"pricingMode");}
 public List<Dictionary<string,object>> PriceLines(Dictionary<string,object> row){
  var rows=row.ContainsKey("priceLines")?ObjectRows(row,"priceLines"):new List<Dictionary<string,object>>();J.Require(rows.Count<=80,"Massimo 80 voci prezzo.");var result=new List<Dictionary<string,object>>();
  foreach(var r in rows){string description=J.S(r,"description").Trim(),unit=J.S(r,"unit").Trim();decimal quantity=J.N(r,"quantity"),unitPrice=J.N(r,"unitPrice");J.Require(description.Length>0&&description.Length<=300,"Ogni voce richiede una descrizione di massimo 300 caratteri.");J.Require(quantity>0&&unitPrice>=0,"Quantita' positiva e prezzo unitario non negativo richiesti.");J.Require(unit.Length<=30,"Unita' di misura troppo lunga.");result.Add(J.Obj("description",description,"quantity",quantity,"unit",unit,"unitPrice",unitPrice,"amount",J.Round(quantity*unitPrice)));}return result;
 }
 public void ValidatePrice(Dictionary<string,object> row){string mode=PriceMode(row);J.Require(new[]{"Standard","Tariffa libera","Prezzo composto"}.Contains(mode),"Modalita' prezzo non valida.");Nonnegative(row,"specificRate");var lines=PriceLines(row);J.Require(mode!="Prezzo composto"||lines.Count>0,"Aggiungi almeno una voce per comporre il prezzo.");J.Require(mode!="Tariffa libera"||J.S(row,"specificRate")!="","Inserisci la tariffa libera, anche zero per un servizio gratuito.");row["pricingMode"]=mode;row["priceLines"]=lines;decimal total=mode=="Tariffa libera"?J.Round(J.N(row,"specificRate")):lines.Sum(x=>J.N(x,"amount"));if(mode!="Standard")J.Require(total>=J.Round(J.N(row,"discount")),"Lo sconto supera il prezzo del viaggio.");
 }
 public Dictionary<string,object> PriceBreakdown(Dictionary<string,object> booking,decimal km,decimal hours,decimal tolls){
  string mode=PriceMode(booking);ValidatePrice(J.Clone(booking));var lines=PriceLines(booking);decimal baseCost=J.Round(J.N(booking,"baseRate")),kmCost=J.Round(km*J.N(booking,"kmRate")),hoursCost=J.Round(hours*J.N(booking,"hourRate")),extras=J.Round(J.N(booking,"extras")+tolls);
  if(mode!="Standard"){baseCost=mode=="Tariffa libera"?J.Round(J.N(booking,"specificRate")):lines.Sum(x=>J.N(x,"amount"));kmCost=0;hoursCost=0;extras=0;}
  return J.Obj("pricingMode",mode,"priceLines",mode=="Prezzo composto"?lines:new List<Dictionary<string,object>>(),"specificRate",J.N(booking,"specificRate"),"baseCost",baseCost,"kmCost",kmCost,"hoursCost",hoursCost,"extras",extras,"netTotal",J.Round(baseCost+kmCost+hoursCost+extras-J.Round(J.N(booking,"discount"))));
 }
}
public static partial class Program {
 public static void PriceSelfTest(Engine e){

  var b=J.Obj("pricingMode","Prezzo composto","baseRate",999,"extras",999,"kmRate",999,"discount",5,"priceLines",new[]{J.Obj("description","Trasporto","quantity",20,"unit","km","unitPrice",1.25m,"amount",9999),J.Obj("description","Attesa","quantity",2,"unit","ore","unitPrice",10),J.Obj("description","Quota","quantity",1,"unit","servizio","unitPrice",15)});
  e.ValidatePrice(b);var price=e.PriceBreakdown(b,20,2,8);Expect(J.N(price,"netTotal")==55&&J.N(price,"extras")==0,"Prezzo composto senza IVA, senza duplicare tariffe e pedaggi");Expect(J.N(Engine.ObjectRows(price,"priceLines")[0],"amount")==25,"Importi voci ricalcolati dal server");
  var flat=J.Obj("pricingMode","Tariffa libera","specificRate",100,"discount",5,"baseRate",999,"extras",999);Expect(J.N(e.PriceBreakdown(flat,20,2,8),"netTotal")==95,"Tariffa libera senza IVA");
  Reject(()=>e.ValidatePrice(J.Obj("pricingMode","Tariffa libera")),"Tariffa libera mancante vietata");Reject(()=>e.ValidatePrice(J.Obj("pricingMode","Prezzo composto","priceLines",new object[0])),"Prezzo composto senza voci vietato");
  var invalid=J.Clone(b);Engine.ObjectRows(invalid,"priceLines")[0]["quantity"]=-1;Reject(()=>e.ValidatePrice(invalid),"Quantita' negativa vietata");
  var discount=J.Clone(flat);discount["discount"]=101;Reject(()=>e.ValidatePrice(discount),"Sconto maggiore del prezzo vietato");
  var rounded=J.Obj("pricingMode","Prezzo composto","priceLines",new[]{J.Obj("description","Frazione","quantity",3,"unitPrice",0.335m)});Expect(J.N(e.PriceBreakdown(rounded,0,0,0),"netTotal")==1.01m,"Voci arrotondate ai centesimi");
  var admin=new User{Id="price-admin",Username="price-admin",Role="admin"};var office=new User{Id="price-office",Username="price-office",Role="segreteria"};
  var record=e.SaveAsUser(admin,"bookings",J.Obj("type","Assistenza evento","title","Permessi prezzo TEST","status","Confermata","start","2026-10-10T08:00","end","2026-10-10T10:00","vehicleId",e.Data.Tables["vehicles"][0]["id"],"crewIds",new object[0],"pricingMode","Tariffa libera","specificRate",100,"discount",5));
  var operational=J.Clone(record);operational["notes"]="Aggiornamento segreteria";record=e.SaveAsUser(office,"bookings",operational);Expect(J.N(record,"specificRate")==100&&J.S(record,"notes")=="Aggiornamento segreteria","Segreteria aggiorna dati operativi conservando il prezzo");
  var forbidden=J.Clone(record);forbidden["specificRate"]=101;RejectPricePermission(()=>e.SaveAsUser(office,"bookings",forbidden),"Tariffa libera riservata admin, controllo server");
  forbidden=J.Clone(record);forbidden["discount"]=0;RejectPricePermission(()=>e.SaveAsUser(office,"bookings",forbidden),"Sconto riservato admin");
  forbidden=J.Clone(record);forbidden["priceLines"]=new[]{J.Obj("description","Voce aggiunta","quantity",1,"unitPrice",5)};RejectPricePermission(()=>e.SaveAsUser(office,"bookings",forbidden),"Voci prezzo riservate admin");
  RejectPricePermission(()=>e.SaveAsUser(office,"tariffs",J.Obj("name","Tariffa negata")),"Tariffario riservato admin");
  var initial=e.SaveAsUser(office,"bookings",J.Obj("type","Assistenza evento","title","Nuovo servizio segreteria","status","Prenotata","start","2026-10-11T08:00","end","2026-10-11T10:00","crewIds",new object[0]));Expect(e.PriceMode(initial)=="Standard"&&J.N(initial,"baseRate")==J.N(e.Data.Settings,"baseRate"),"Nuova prenotazione segreteria usa prezzi predefiniti dall admin");
  var trip=e.CreateTrip(J.S(record,"id"));var changedTrip=J.Clone(trip);changedTrip["tolls"]=10;RejectPricePermission(()=>e.SaveAsUser(office,"trips",changedTrip),"Importi addebitabili viaggio riservati admin");
  forbidden=J.Clone(record);forbidden["specificRate"]=110;record=e.SaveAsUser(admin,"bookings",forbidden);Expect(J.N(record,"specificRate")==110,"Amministratore modifica il prezzo");
 }
 private static void RejectPricePermission(Action action,string label){bool rejected=false;try{action();}catch(ApiError error){rejected=error.Status==403;}Expect(rejected,label);}
}
}
