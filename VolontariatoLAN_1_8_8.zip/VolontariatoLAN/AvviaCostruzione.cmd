@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AggiornaServer.ps1" -Costruzione
