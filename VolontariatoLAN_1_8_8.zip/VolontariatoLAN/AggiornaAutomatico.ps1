﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$area=Join-Path $root 'Aggiornamenti'
$serviceArea=Join-Path $area 'Servizio'
$requestFile=Join-Path $serviceArea 'richiesta.json'
$statusFile=Join-Path $serviceArea 'stato.json'
$maintenance=Join-Path $area 'manutenzione.flag'
$job=$null;$work=$null;$snapshot=$null;$changed=$false;$stopped=$false;$mutex=$null;$locked=$false
. (Join-Path $root 'AggiornamentiComuni.ps1')
function Set-UpdateStatus([string]$Stage,[string]$Message) {
    $value=@{stage=$Stage;message=$Message;targetVersion=([string]$job.version);updatedAt=(Get-Date).ToUniversalTime().ToString('o')}
    $temporary=$statusFile+'.tmp'
    $value | ConvertTo-Json | Set-Content $temporary -Encoding UTF8
    Move-Item $temporary $statusFile -Force
}
function Test-ServerVersion([string]$Version) {
    $temp=Join-Path $work 'stato-server.json'
    for ($attempt=0;$attempt -lt 30;$attempt++) {
        try {
            Get-UpdateFile ([Uri]'https://127.0.0.1:8765/api/status') $temp 65536 2000
            $status=Get-Content $temp -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($status.version -eq $Version) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 1000
    }
    return $false
}
try {
    $mutex=New-Object Threading.Mutex($false,'Global\VolontariatoLAN-Aggiornamento')
    try {$locked=$mutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$locked=$true}
    if (-not $locked -or -not (Test-Path $requestFile)) { return }
    $job=Get-Content $requestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($job.id -notmatch '^[a-f0-9]{32}$' -or $job.version -notmatch '^\d+\.\d+\.\d+$' -or $job.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Richiesta aggiornamento non valida.' }
    $work=Join-Path $area ('Lavoro\'+$job.id)
    if (Test-Path $work) { throw 'Lavoro di aggiornamento gia esistente.' }
    New-Item -ItemType Directory $work -Force | Out-Null
    & icacls.exe $work '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' | Out-Null
    if ($LASTEXITCODE -ne 0) {throw 'Permessi cartella di lavoro non impostati.'}
    $config=Get-Content (Join-Path $area 'fonte.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $versionFile=Join-Path $root 'versione.json'
    if (-not (Test-Path $versionFile)) { throw 'Versione installata non riconosciuta.' }
    $current=Get-Content $versionFile -Raw -Encoding UTF8 | ConvertFrom-Json
    Set-UpdateStatus 'checking' 'Verifica della versione e della fonte configurata.'
    $manifest=Read-UpdateManifest $config.manifestUrl (Join-Path $work 'manifest.json') $current.version
    if ($manifest.version -ne $job.version -or $manifest.sha256 -ne $job.sha256 -or [Version]$manifest.version -le [Version]$current.version) { throw 'Fonte cambiata o versione non piu applicabile. Ripetere il controllo.' }
    Set-UpdateStatus 'downloading' 'Download automatico del pacchetto in corso.'
    $zip=Join-Path $work 'pacchetto.zip'
    Get-UpdateFile (Assert-UpdateHttps $manifest.packageUrl) $zip ([long]$manifest.size)
    if ((Get-Item $zip).Length -ne [long]$manifest.size -or (Get-FileHash $zip -Algorithm SHA256).Hash -ne $manifest.sha256) { throw 'Pacchetto incompleto o impronta errata.' }
    Set-UpdateStatus 'verifying' 'Controllo dei file, compilazione e verifiche interne.'
    $package=Expand-VerifiedUpdate $zip (Join-Path $work 'Estratto')
    $release=Get-Content (Join-Path $package 'versione.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($release.application -ne 'VolontariatoLAN' -or $release.version -ne $manifest.version) { throw 'La versione nel pacchetto non corrisponde alla fonte.' }
    $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (-not (Test-Path $compiler)) {$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'}
    $compiled=Join-Path $work 'Volontariato.Server.exe'
    $arguments=@('/nologo','/target:exe','/optimize+','/r:System.Web.Extensions.dll','/r:System.Security.dll','/r:System.ServiceProcess.dll','/r:System.Core.dll','/r:System.IO.Compression.dll','/r:System.Xml.dll','/r:System.Xml.Linq.dll',('/out:'+$compiled))
    $sources=@(Get-ChildItem (Join-Path $package 'Sorgenti') -Filter '*.cs' -File | ForEach-Object {$_.FullName})
    & $compiler @arguments @sources *> (Join-Path $work 'compilazione.txt')
    if ($LASTEXITCODE -ne 0) {throw 'Compilazione dell aggiornamento non riuscita.'}
    & $compiled --self-test *> (Join-Path $work 'collaudo.txt')
    if ($LASTEXITCODE -ne 0) {throw 'Verifiche interne dell aggiornamento non superate.'}
    & (Join-Path $package 'VerificaAggiornamenti.ps1') *> (Join-Path $work 'collaudo-componente.txt')
    if (-not $?) { throw 'Verifica del componente aggiornamenti non superata.' }
    Set-UpdateStatus 'installing' 'Verifiche superate. Riavvio del servizio gestionale in corso.'
    [IO.File]::WriteAllText($maintenance,'Aggiornamento in corso')
    Stop-Service VolontariatoLAN
    $stopped=$true
    $snapshot=Join-Path $area ('Ripristini\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+$job.id)
    New-Item -ItemType Directory $snapshot -Force | Out-Null
    & icacls.exe $snapshot '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' | Out-Null
    if ($LASTEXITCODE -ne 0) {throw 'Permessi copie di ripristino non impostati.'}
    foreach ($directory in @('App','Sorgenti')) {Copy-Item (Join-Path $root $directory) $snapshot -Recurse}
    New-Item -ItemType Directory (Join-Path $snapshot 'Radice') | Out-Null
    Get-ChildItem $root -File | ForEach-Object {Copy-Item $_.FullName (Join-Path $snapshot 'Radice')}
    foreach ($name in @('Dati','DatiCostruzione')) {
        $data=Join-Path $root $name
        if (Test-Path $data) {
            $copy=Join-Path $snapshot $name
            New-Item -ItemType Directory $copy -Force | Out-Null
            foreach ($file in @('archive.dat','archive.previous','backup-config.dat')) {
                if (Test-Path (Join-Path $data $file)) {Copy-Item (Join-Path $data $file) $copy}
            }
        }
    }
    $changed=$true
    Copy-Item $compiled (Join-Path $root 'Volontariato.Server.exe') -Force
    foreach ($directory in @('App','Sorgenti')) {
        Remove-Item (Join-Path $root $directory) -Recurse -Force
        Copy-Item (Join-Path $package $directory) $root -Recurse
    }
    Get-ChildItem $package -File | ForEach-Object {Copy-Item $_.FullName $root -Force}
    Start-Service VolontariatoLAN
    $stopped=$false
    if (-not (Test-ServerVersion $manifest.version)) {throw 'La nuova versione non risponde correttamente.'}
    Remove-Item $maintenance -Force
    Set-UpdateStatus 'completed' ('Aggiornamento completato. Versione '+$manifest.version+'. Ricarica il gestionale.')
} catch {
    $errorText=$_.Exception.Message
    if ($work -and (Test-Path $work)) {[IO.File]::WriteAllText((Join-Path $work 'errore.txt'),$errorText)}
    if ($changed -and $snapshot) {
        try {
            Stop-Service VolontariatoLAN -ErrorAction SilentlyContinue
            foreach ($directory in @('App','Sorgenti')) {
                if (Test-Path (Join-Path $root $directory)) {Remove-Item (Join-Path $root $directory) -Recurse -Force}
                Copy-Item (Join-Path $snapshot $directory) $root -Recurse
            }
            Get-ChildItem (Join-Path $snapshot 'Radice') -File | ForEach-Object {Copy-Item $_.FullName $root -Force}
            foreach ($name in @('Dati','DatiCostruzione')) {
                $copy=Join-Path $snapshot $name
                if (Test-Path $copy) {Get-ChildItem $copy -File | ForEach-Object {Copy-Item $_.FullName (Join-Path $root $name) -Force}}
            }
            Start-Service VolontariatoLAN
            $stopped=$false
            if (-not (Test-ServerVersion $current.version)) {throw 'La versione precedente non risponde.'}
            if (Test-Path $maintenance) {Remove-Item $maintenance -Force}
            Set-UpdateStatus 'rolled-back' 'Aggiornamento non riuscito. Ripristinata la versione precedente; archivi conservati.'
        } catch {Set-UpdateStatus 'repair-required' 'Ripristino automatico non completato. Controlla il PC centrale; copie di ripristino conservate.'}
    } else {
        if ($stopped) {try {Start-Service VolontariatoLAN;$stopped=$false} catch {}}
        if (Test-Path $maintenance) {Remove-Item $maintenance -Force}
        Set-UpdateStatus 'failed' ('Aggiornamento non applicato: '+$errorText)
    }
} finally {
    if ($locked -and $job) {
        if (Test-Path $requestFile) {Remove-Item $requestFile -Force}
    }
    if ($locked) {$mutex.ReleaseMutex()};if ($mutex) {$mutex.Dispose()}
}
