@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RiattivaLogin.ps1"
