﻿$ErrorActionPreference = 'Stop'
try {
    $configFile = Join-Path $PSScriptRoot 'Sede.json'
    $certFile = Join-Path $PSScriptRoot 'CertificatoSede.cer'
    if (-not (Test-Path $configFile) -or -not (Test-Path $certFile)) { throw 'Usa la cartella Postazioni generata sul PC centrale dopo l installazione del server. Copiala interamente su questo PC.' }
    $config = Get-Content $configFile -Raw | ConvertFrom-Json
    $url = [Uri]$config.url
    if ($url.Scheme -ne 'https' -or $url.Port -ne 8765) { throw 'Configurazione della sede non valida.' }
    $cert = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $certFile
    if ($cert.Thumbprint -ne $config.thumbprint) { throw 'Il certificato non corrisponde alla sede configurata.' }
    Write-Host "Sede: $($config.server)"
    Write-Host "Indirizzo: $($config.url)"
    Write-Host "Impronta certificato: $($cert.Thumbprint)"
    Write-Host 'Deve coincidere con l impronta mostrata sul PC centrale.'
    Import-Certificate -FilePath $certFile -CertStoreLocation 'Cert:\CurrentUser\Root' | Out-Null
    $edge = Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
    if (-not (Test-Path $edge)) { $edge = Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe' }
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Volontariato - Gestionale.lnk'))
    if (Test-Path $edge) { $link.TargetPath=$edge; $link.Arguments="--app=`"$($config.url)`""; $link.Save(); Start-Process $edge -ArgumentList $link.Arguments } else { $link.TargetPath='powershell.exe'; $link.Arguments="-NoProfile -Command Start-Process '$($config.url)'"; $link.WindowStyle=7; $link.Save(); Start-Process $config.url }
    Write-Host 'Postazione pronta. Accedi con l utente assegnato dall amministratore.' -ForegroundColor Green
} catch { Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red }
Read-Host 'Premi INVIO per chiudere'
