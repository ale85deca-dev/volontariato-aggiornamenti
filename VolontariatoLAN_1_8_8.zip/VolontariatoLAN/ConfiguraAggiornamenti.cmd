@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ConfiguraAggiornamenti.ps1"
