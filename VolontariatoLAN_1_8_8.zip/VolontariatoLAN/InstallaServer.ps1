﻿$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}
$root = Join-Path $env:ProgramData 'VolontariatoLAN'
$created = $false
$serviceCreated = $false
$bound4 = $false
$bound6 = $false
$aclCreated = $false
$reuseAcl = $false
$firewallCreated = $false
$eventSourceCreated = $false
$installed = $false
$updateSetupAttempted = $false
$cert = $null
$rootCert = $null
function NativeChecked([string]$tool, [string[]]$arguments) {
    & $tool @arguments
    if ($LASTEXITCODE -ne 0) { throw "Operazione non riuscita: $tool (codice $LASTEXITCODE)." }
}
try {
    if (Get-Service -Name VolontariatoLAN -ErrorAction SilentlyContinue) { throw 'Il gestionale e gia installato. Usa AggiornaServer.cmd per aggiornare conservando i dati.' }
    if (Get-NetFirewallRule -Name 'VolontariatoLAN-8765' -ErrorAction SilentlyContinue) { throw 'Una regola di rete del gestionale esiste gia. Verifica una precedente installazione.' }
    if (Test-Path $root) { throw "La cartella $root esiste gia. Non verra sovrascritta. Verifica una precedente installazione." }
    if (Get-ScheduledTask -TaskName 'VolontariatoLAN-Aggiornamento' -ErrorAction SilentlyContinue) {throw 'Il componente aggiornamenti esiste gia. Verifica la precedente installazione.'}
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (-not (Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
    if (-not (Test-Path $compiler)) { throw 'Compilatore .NET Framework di Windows non disponibile. Ripara il componente Windows .NET Framework prima di installare.' }
    if (-not ('VolontariatoLAN.Installazione.HttpConfigurazione' -as [type])) {
        Add-Type -Path (Join-Path $PSScriptRoot 'Sorgenti\HttpConfigurazione.cs')
    }
    [VolontariatoLAN.Installazione.HttpConfigurazione]::CheckInterop()
    if ([VolontariatoLAN.Installazione.HttpConfigurazione]::HasSslBinding($false,8765)) {
        & netsh.exe http show sslcert ipport=0.0.0.0:8765
        throw 'Esiste un binding HTTPS IPv4 sulla porta 8765. Configurazione conservata: verifica quale programma la utilizza.'
    }
    if ([VolontariatoLAN.Installazione.HttpConfigurazione]::HasSslBinding($true,8765)) {
        & netsh.exe http show sslcert 'ipport=[::]:8765'
        throw 'Esiste un binding HTTPS IPv6 sulla porta 8765. Configurazione conservata: verifica quale programma la utilizza.'
    }
    $existingAcl = [VolontariatoLAN.Installazione.HttpConfigurazione]::UrlPermissions('https://+:8765/')
    if ($null -ne $existingAcl) {
        if (-not [VolontariatoLAN.Installazione.HttpConfigurazione]::CompatiblePermissions($existingAcl)) {
            & netsh.exe http show urlacl url=https://+:8765/
            throw 'La riserva HTTPS 8765 ha permessi diversi da quelli del gestionale. Nessuna riserva cancellata: invia il dettaglio visualizzato per verificare il conflitto.'
        }
        $reuseAcl = $true
        Write-Host 'Riserva HTTPS 8765 compatibile con LocalService: viene riutilizzata senza modificarla.'
    }
    New-Item -ItemType Directory -Path $root | Out-Null
    $created = $true
    Copy-Item (Join-Path $PSScriptRoot 'App') $root -Recurse
    Copy-Item (Join-Path $PSScriptRoot 'Sorgenti') $root -Recurse
    Copy-Item (Join-Path $PSScriptRoot 'RecuperaArchivio.ps1') $root
    Copy-Item (Join-Path $PSScriptRoot 'ConfiguraAccessoMobile.ps1') $root
    $exe = Join-Path $root 'Volontariato.Server.exe'
    Write-Host 'Preparazione del programma sul PC, senza download...'
    NativeChecked $compiler @('/nologo','/target:exe','/optimize+','/r:System.Web.Extensions.dll','/r:System.Security.dll','/r:System.ServiceProcess.dll','/r:System.Core.dll','/r:System.IO.Compression.dll','/r:System.Xml.dll','/r:System.Xml.Linq.dll',"/out:$exe",(Join-Path $root 'Sorgenti\Server.cs'),(Join-Path $root 'Sorgenti\Operazioni.cs'),(Join-Path $root 'Sorgenti\Prezzi.cs'),(Join-Path $root 'Sorgenti\Fatture.cs'),(Join-Path $root 'Sorgenti\Posta.cs'), (Join-Path $root 'Sorgenti\Sede.cs'), (Join-Path $root 'Sorgenti\Completo.cs'), (Join-Path $root 'Sorgenti\Cassa.cs'),(Join-Path $root 'Sorgenti\Evoluzione.cs'),(Join-Path $root 'Sorgenti\Archivio.cs'),(Join-Path $root 'Sorgenti\Importazione.cs'),(Join-Path $root 'Sorgenti\VerificheEvoluzione.cs'),(Join-Path $root 'Sorgenti\Aggiornamenti.cs'))
    Write-Host 'Verifica interna di calcoli, archivi e copie...'
    & $exe --self-test 2>&1 | Tee-Object -FilePath (Join-Path $root 'Collaudo-installazione.txt')
    if ($LASTEXITCODE -ne 0) { throw 'La verifica interna non e stata superata. Il servizio non verra installato.' }
    & (Join-Path $PSScriptRoot 'VerificaAggiornamenti.ps1')
    $addresses = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.IPAddress -notlike '169.254.*' -and $_.AddressState -eq 'Preferred' } | Select-Object -ExpandProperty IPAddress -Unique)
    $san = "2.5.29.17={text}DNS=$env:COMPUTERNAME&DNS=localhost&IPAddress=127.0.0.1&IPAddress=::1"
    foreach ($ip in $addresses) { $san += "&IPAddress=$ip" }
    $rootCert = New-SelfSignedCertificate -Type Custom -Subject "CN=Volontariato LAN - $env:COMPUTERNAME" -FriendlyName 'Volontariato LAN - autorita della sede' -CertStoreLocation 'Cert:\LocalMachine\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeySpec Signature -KeyUsage CertSign,CRLSign -KeyUsageProperty Sign -KeyExportPolicy NonExportable -NotAfter (Get-Date).AddYears(10) -TextExtension @('2.5.29.19={critical}{text}CA=1&pathlength=0')
    $cert = New-SelfSignedCertificate -Type Custom -KeyUsage DigitalSignature,KeyEncipherment -Signer $rootCert -Subject "CN=$env:COMPUTERNAME" -FriendlyName 'Volontariato LAN - collegamento locale' -CertStoreLocation 'Cert:\LocalMachine\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -NotAfter (Get-Date).AddYears(5) -TextExtension @($san,'2.5.29.37={text}1.3.6.1.5.5.7.3.1','2.5.29.19={critical}{text}CA=0')
    $postazioni = Join-Path $root 'Postazioni'
    New-Item -ItemType Directory -Path $postazioni | Out-Null
    $publicCert = Join-Path $postazioni 'CertificatoSede.cer'
    Export-Certificate -Cert $rootCert -FilePath $publicCert | Out-Null
    Import-Certificate -FilePath $publicCert -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
    $url = "https://$($env:COMPUTERNAME.ToLower()):8765/"
    @{url=$url;server=$env:COMPUTERNAME;addresses=$addresses;thumbprint=$rootCert.Thumbprint;serverThumbprint=$cert.Thumbprint;expires=$cert.NotAfter.ToString('yyyy-MM-dd')} | ConvertTo-Json | Set-Content (Join-Path $postazioni 'Sede.json') -Encoding UTF8
    Copy-Item (Join-Path $PSScriptRoot 'InstallaPostazione.ps1') $postazioni
    Copy-Item (Join-Path $PSScriptRoot 'InstallaPostazione.cmd') $postazioni
    NativeChecked netsh.exe @('http','add','sslcert','ipport=0.0.0.0:8765',"certhash=$($cert.Thumbprint)",'appid={F88C6771-38C5-4F80-A268-6B754DA1EF39}','certstorename=MY','disablelegacytls=enable')
    $bound4 = $true
    NativeChecked netsh.exe @('http','add','sslcert','ipport=[::]:8765',"certhash=$($cert.Thumbprint)",'appid={F88C6771-38C5-4F80-A268-6B754DA1EF39}','certstorename=MY','disablelegacytls=enable')
    $bound6 = $true
    if ($reuseAcl) {
        $currentAcl = [VolontariatoLAN.Installazione.HttpConfigurazione]::UrlPermissions('https://+:8765/')
        if (-not [VolontariatoLAN.Installazione.HttpConfigurazione]::CompatiblePermissions($currentAcl)) { throw 'La riserva HTTPS e cambiata durante l installazione. Riprova dopo aver verificato la configurazione.' }
    } else {
        NativeChecked netsh.exe @('http','add','urlacl','url=https://+:8765/','sddl=D:(A;;GX;;;LS)')
        $aclCreated = $true
    }
    if (-not [Diagnostics.EventLog]::SourceExists('VolontariatoLAN')) { New-EventLog -LogName Application -Source VolontariatoLAN; $eventSourceCreated=$true }
    New-NetFirewallRule -Name 'VolontariatoLAN-8765' -DisplayName 'Volontariato LAN - rete della sede' -Direction Inbound -Protocol TCP -LocalPort 8765 -Action Allow -Profile Private -RemoteAddress LocalSubnet | Out-Null
    $firewallCreated = $true
    NativeChecked sc.exe @('create','VolontariatoLAN','binPath=',"`"$exe`"",'start=','auto','obj=','NT AUTHORITY\LocalService','DisplayName=','Volontariato LAN - Archivio centrale')
    $serviceCreated = $true
    NativeChecked sc.exe @('description','VolontariatoLAN','Archivio locale condiviso dell associazione. Nessuna connessione Internet richiesta.')
    NativeChecked sc.exe @('failure','VolontariatoLAN','reset=','86400','actions=','restart/5000/restart/15000/restart/60000')
    $data = Join-Path $root 'Dati'
    New-Item -ItemType Directory -Path $data | Out-Null
    $code = ([Guid]::NewGuid().ToString('N') + [Guid]::NewGuid().ToString('N'))
    [IO.File]::WriteAllText((Join-Path $data 'setup-code.txt'),$code,[Text.Encoding]::UTF8)
    NativeChecked icacls.exe @($root,'/inheritance:r','/grant:r','*S-1-5-32-544:(OI)(CI)F','*S-1-5-18:(OI)(CI)F','*S-1-5-19:(OI)(CI)RX','*S-1-5-32-545:(OI)(CI)RX')
    NativeChecked icacls.exe @($data,'/inheritance:r','/grant:r','*S-1-5-32-544:(OI)(CI)F','*S-1-5-18:(OI)(CI)F','*S-1-5-19:(OI)(CI)M')
    $updateSetupAttempted = $true
    & (Join-Path $PSScriptRoot 'InstallaAggiornamenti.ps1') -Root $root
    Copy-Item (Join-Path $PSScriptRoot 'versione.json') $root -Force
    Start-Service VolontariatoLAN
    $response = $null
    for ($i=0; $i -lt 15; $i++) {
        try { $response = Invoke-WebRequest -UseBasicParsing -Uri 'https://127.0.0.1:8765/api/status' -TimeoutSec 2; break } catch { Start-Sleep -Milliseconds 500 }
    }
    if (-not $response -or $response.StatusCode -ne 200) { throw 'Il servizio HTTPS non risponde. Verifica il registro eventi di Windows.' }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Volontariato - Gestionale.lnk'))
    $edge = Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
    if (Test-Path $edge) { $shortcut.TargetPath=$edge; $shortcut.Arguments="--app=`"$url`"" } else { $shortcut.TargetPath='powershell.exe'; $shortcut.Arguments="-NoProfile -Command Start-Process '$url'"; $shortcut.WindowStyle=7 }
    $shortcut.Save()
    $installed = $true
    Write-Host "`nINSTALLAZIONE COMPLETATA" -ForegroundColor Green
    Write-Host "Indirizzo: $url"
    Write-Host "Codice per il PRIMO amministratore: $code" -ForegroundColor Yellow
    Write-Host "Impronta certificato della sede: $($rootCert.Thumbprint)"
    Write-Host "Copia questa cartella sugli altri PC: $postazioni"
    Write-Host 'La rete Windows deve essere impostata come Privata. Il servizio si avvia con Windows.'
    Write-Host 'Conserva il codice solo fino alla configurazione iniziale. Non inviarlo ad altri operatori.'
    Start-Process $url
} catch {
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    $testLog = Join-Path $root 'Collaudo-installazione.txt'
    if ($created -and (Test-Path $testLog)) {
        try {
            $savedLog = Join-Path $PSScriptRoot 'Collaudo-installazione.txt'
            Copy-Item $testLog $savedLog -Force
            Write-Host "Resoconto delle verifiche conservato in: $savedLog"
        } catch { Write-Host 'Impossibile copiare il resoconto: conserva il testo visualizzato nella finestra.' }
    }
    if (-not $installed) {
        if ($updateSetupAttempted) {Unregister-ScheduledTask -TaskName 'VolontariatoLAN-Aggiornamento' -Confirm:$false -ErrorAction SilentlyContinue}
        if ($serviceCreated) { Stop-Service VolontariatoLAN -ErrorAction SilentlyContinue; & sc.exe delete VolontariatoLAN | Out-Null }
        if ($bound4) { & netsh.exe http delete sslcert ipport=0.0.0.0:8765 | Out-Null }
        if ($bound6) { & netsh.exe http delete sslcert 'ipport=[::]:8765' | Out-Null }
        if ($aclCreated) { & netsh.exe http delete urlacl url=https://+:8765/ | Out-Null }
        if ($firewallCreated) { Remove-NetFirewallRule -Name 'VolontariatoLAN-8765' -ErrorAction SilentlyContinue }
        if ($cert) { Remove-Item "Cert:\LocalMachine\My\$($cert.Thumbprint)" -ErrorAction SilentlyContinue;  }
        if ($eventSourceCreated) { Remove-EventLog -Source VolontariatoLAN -ErrorAction SilentlyContinue }
        if ($rootCert) { Remove-Item "Cert:\LocalMachine\My\$($rootCert.Thumbprint)" -ErrorAction SilentlyContinue; Remove-Item "Cert:\LocalMachine\Root\$($rootCert.Thumbprint)" -ErrorAction SilentlyContinue }
        if ($created) { Remove-Item $root -Recurse -Force -ErrorAction SilentlyContinue }
    }
}
Read-Host 'Premi INVIO per chiudere'
