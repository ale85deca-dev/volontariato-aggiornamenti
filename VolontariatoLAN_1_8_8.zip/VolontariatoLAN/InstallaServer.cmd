@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0InstallaServer.ps1"
