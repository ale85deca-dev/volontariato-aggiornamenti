﻿$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""; exit }
$root=Join-Path $env:ProgramData 'VolontariatoLAN'
try {
    $data=Join-Path $root 'Dati'
    $choices=@()
    if (Test-Path (Join-Path $data 'archive.previous')) { $choices+=Get-Item (Join-Path $data 'archive.previous') }
    $choices+=@(Get-ChildItem (Join-Path $data 'Backups') -Filter '*.dat' | Sort-Object LastWriteTime -Descending)
    if ($choices.Count -eq 0) { throw 'Nessuna copia locale disponibile. Usa una copia portabile .volbackup tramite il gestionale su un nuovo server.' }
    for($i=0;$i -lt $choices.Count;$i++){Write-Host "$($i+1): $($choices[$i].Name) - $($choices[$i].LastWriteTime)"}
    $n=0
    if (-not [int]::TryParse((Read-Host 'Numero della copia da verificare'),[ref]$n) -or $n -lt 1 -or $n -gt $choices.Count) { throw 'Selezione non valida.' }
    $selected=$choices[$n-1].FullName
    & (Join-Path $root 'Volontariato.Server.exe') --check-archive $selected
    if ($LASTEXITCODE -ne 0) { throw 'La copia non e leggibile su questo PC. Nessun archivio e stato sostituito.' }
    if ((Read-Host 'Scrivi RIPRISTINA per sostituire l archivio condiviso con la copia selezionata') -ne 'RIPRISTINA') { exit }
    Stop-Service VolontariatoLAN
    try {
        $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
        Copy-Item (Join-Path $data 'archive.dat') (Join-Path $data "Backups\pre-recupero-$stamp.dat")
        Copy-Item $selected (Join-Path $data 'archive.dat') -Force
    } finally { Start-Service VolontariatoLAN }
    Write-Host 'Archivio recuperato. Tutti gli operatori devono accedere di nuovo.' -ForegroundColor Green
} catch { Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red }
Read-Host 'Premi INVIO per chiudere'
