﻿$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}
$root=Join-Path $env:ProgramData 'VolontariatoLAN'
$flag=Join-Path $root 'costruzione.flag'
$hadFlag=Test-Path $flag
$stopped=$false
$flagContent=$null
try {
    if (-not (Get-Service VolontariatoLAN -ErrorAction SilentlyContinue)) { throw 'Il server non e installato.' }
    if (-not $hadFlag) {
        Write-Host 'Il login e gia attivo.' -ForegroundColor Green
    } else {
        $flagContent=[IO.File]::ReadAllText($flag)
        Stop-Service VolontariatoLAN
        $stopped=$true
        Remove-Item $flag -Force
        Start-Service VolontariatoLAN
        $stopped=$false
        Write-Host 'Login riattivato. Archivio ordinario nuovamente disponibile.' -ForegroundColor Green
        Write-Host 'I dati di prova restano conservati in DatiCostruzione, senza essere mescolati a quelli ordinari.'
    }
    Start-Process ('https://'+$env:COMPUTERNAME.ToLowerInvariant()+':8765/')
    Write-Host 'Se la pagina era aperta, premi Ctrl+F5.'
} catch {
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    if ($stopped -and $hadFlag) {
        [IO.File]::WriteAllText($flag,$flagContent)
        Start-Service VolontariatoLAN -ErrorAction SilentlyContinue
        Write-Host 'Ripristinata la modalita precedente. Archivi conservati.'
    }
}
Read-Host 'Premi INVIO per chiudere'
