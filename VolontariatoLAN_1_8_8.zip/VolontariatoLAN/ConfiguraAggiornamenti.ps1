﻿$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}
try {
    $root=Join-Path $env:ProgramData 'VolontariatoLAN'
    . (Join-Path $root 'AggiornamentiComuni.ps1')
    $area=Join-Path $root 'Aggiornamenti'
    if (-not (Test-Path (Join-Path $area 'installato.flag'))) { throw 'Prima installa il pacchetto 1.8.6 o successivo.' }
    Write-Host 'Configura la fonte HTTPS stabile da cui ricevere le versioni del gestionale.'
    Write-Host 'La fonte deve essere quella scelta per distribuire gli aggiornamenti dell associazione.'
    $url=Read-Host 'Indirizzo completo del file aggiornamento.json (vuoto: annulla)'
    if (-not $url.Trim()) { exit }
    $uri=Assert-UpdateHttps $url.Trim()
    $temporary=Join-Path $area ('fonte-prova-'+[Guid]::NewGuid().ToString('N')+'.json')
    try { $null=Read-UpdateManifest $uri.AbsoluteUri $temporary '1.8.6' } finally { if (Test-Path $temporary) {Remove-Item $temporary -Force} }
    @{manifestUrl=$uri.AbsoluteUri;configuredAt=(Get-Date -Format o)} | ConvertTo-Json | Set-Content (Join-Path $area 'fonte.json') -Encoding UTF8
    Write-Host 'Fonte verificata e salvata. Ora usa Aggiorna gestionale nel programma.' -ForegroundColor Green
} catch { Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red }
Read-Host 'Premi INVIO per chiudere'
