﻿param([Parameter(Mandatory=$true)][string]$Pacchetto,[Parameter(Mandatory=$true)][string]$UrlPacchetto,[Parameter(Mandatory=$true)][string]$Destinazione,[string]$Note='Aggiornamento gestionale',[string]$VersioneMinima='1.8.6')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'AggiornamentiComuni.ps1')
$uri=Assert-UpdateHttps $UrlPacchetto
Add-Type -AssemblyName System.IO.Compression
$stream=[IO.File]::OpenRead((Resolve-Path $Pacchetto).Path)
$archive=$null
try {
    $archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Read,$false)
    $entry=$archive.GetEntry('VolontariatoLAN/versione.json')
    if (-not $entry) {throw 'Il pacchetto non contiene versione.json.'}
    $reader=New-Object IO.StreamReader($entry.Open())
    try {$version=$reader.ReadToEnd() | ConvertFrom-Json} finally {$reader.Dispose()}
} finally {if($archive){$archive.Dispose()};$stream.Dispose()}
$manifest=@{schema=1;application='VolontariatoLAN';version=$version.version;minimumVersion=$VersioneMinima;releasedAt=(Get-Date).ToUniversalTime().ToString('o');packageUrl=$uri.AbsoluteUri;size=(Get-Item $Pacchetto).Length;sha256=(Get-FileHash $Pacchetto -Algorithm SHA256).Hash.ToLowerInvariant();notes=$Note}
$manifest | ConvertTo-Json | Set-Content $Destinazione -Encoding UTF8
Write-Host 'Manifest creato. Pubblica il manifest e lo ZIP sullo stesso host HTTPS.'
