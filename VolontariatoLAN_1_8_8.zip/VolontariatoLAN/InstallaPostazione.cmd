@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0InstallaPostazione.ps1"
