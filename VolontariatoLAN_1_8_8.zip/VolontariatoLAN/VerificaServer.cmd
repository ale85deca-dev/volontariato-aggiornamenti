@echo off
if not exist "%ProgramData%\VolontariatoLAN\Volontariato.Server.exe" (
  echo Installa prima il server su questo PC.
  pause
  exit /b 1
)
"%ProgramData%\VolontariatoLAN\Volontariato.Server.exe" --self-test
pause
