﻿param([switch]$Costruzione)
$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" $(if ($Costruzione) { '-Costruzione' })"; exit }
$root=Join-Path $env:ProgramData 'VolontariatoLAN'
$stage=Join-Path $root ('Aggiornamento-'+[Guid]::NewGuid().ToString('N'))
$old=Join-Path $root ('VersionePrecedente-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
$constructionFlag=Join-Path $root 'costruzione.flag'
$constructionWasEnabled=Test-Path $constructionFlag
$stopped=$false
$changed=$false
try {
    if (-not (Get-Service VolontariatoLAN -ErrorAction SilentlyContinue)) { throw 'Il server non e installato.' }
    Write-Host 'Prima di aggiornare, esporta una copia cifrata e fai uscire gli operatori.'
    $ok=Read-Host 'Scrivi AGGIORNA per procedere'
    if ($ok -ne 'AGGIORNA') { exit }
    New-Item -ItemType Directory $stage | Out-Null
    $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (-not (Test-Path $compiler)) { $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
    & $compiler /nologo /target:exe /optimize+ /r:System.Web.Extensions.dll /r:System.Security.dll /r:System.ServiceProcess.dll /r:System.Core.dll /r:System.IO.Compression.dll /r:System.Xml.dll /r:System.Xml.Linq.dll "/out:$stage\Volontariato.Server.exe" (Join-Path $PSScriptRoot 'Sorgenti\Server.cs') (Join-Path $PSScriptRoot 'Sorgenti\Operazioni.cs') (Join-Path $PSScriptRoot 'Sorgenti\Prezzi.cs') (Join-Path $PSScriptRoot 'Sorgenti\Fatture.cs') (Join-Path $PSScriptRoot 'Sorgenti\Posta.cs') (Join-Path $PSScriptRoot 'Sorgenti\Sede.cs') (Join-Path $PSScriptRoot 'Sorgenti\Completo.cs') (Join-Path $PSScriptRoot 'Sorgenti\Cassa.cs') (Join-Path $PSScriptRoot 'Sorgenti\Evoluzione.cs') (Join-Path $PSScriptRoot 'Sorgenti\Archivio.cs') (Join-Path $PSScriptRoot 'Sorgenti\Importazione.cs') (Join-Path $PSScriptRoot 'Sorgenti\VerificheEvoluzione.cs') (Join-Path $PSScriptRoot 'Sorgenti\Aggiornamenti.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Compilazione non riuscita.' }
    & "$stage\Volontariato.Server.exe" --self-test
    if ($LASTEXITCODE -ne 0) { throw 'Verifiche interne non superate.' }
    & (Join-Path $PSScriptRoot 'VerificaAggiornamenti.ps1')
    Stop-Service VolontariatoLAN; $stopped=$true
    New-Item -ItemType Directory $old | Out-Null
    Copy-Item (Join-Path $root 'Volontariato.Server.exe') $old
    Copy-Item (Join-Path $root 'App') $old -Recurse
    Copy-Item (Join-Path $root 'Sorgenti') $old -Recurse
    New-Item -ItemType Directory (Join-Path $old 'Radice') | Out-Null
    Get-ChildItem $root -File | ForEach-Object {Copy-Item $_.FullName (Join-Path $old 'Radice')}
    foreach ($dataName in @('Dati','DatiCostruzione')) {
        $dataArchive=Join-Path $root ($dataName+'\archive.dat')
        if (Test-Path $dataArchive) {
            $backupDirectory=Join-Path $root ($dataName+'\Backups')
            New-Item -ItemType Directory $backupDirectory -Force | Out-Null
            Copy-Item $dataArchive (Join-Path $backupDirectory ('pre-aggiornamento-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.dat'))
        }
    }
    $changed=$true
    Copy-Item (Join-Path $stage 'Volontariato.Server.exe') $root -Force
    Copy-Item (Join-Path $PSScriptRoot 'App\*') (Join-Path $root 'App') -Force
    Copy-Item (Join-Path $PSScriptRoot 'Sorgenti\*.cs') (Join-Path $root 'Sorgenti') -Force
    Copy-Item (Join-Path $PSScriptRoot 'RecuperaArchivio.ps1') $root -Force
    Copy-Item (Join-Path $PSScriptRoot 'ConfiguraAccessoMobile.ps1') $root -Force
    Copy-Item (Join-Path $PSScriptRoot 'RiattivaLogin.ps1') $root -Force
    Copy-Item (Join-Path $PSScriptRoot 'RiattivaLogin.cmd') $root -Force
    if ($Costruzione) {
        $testData=Join-Path $root 'DatiCostruzione'
        New-Item -ItemType Directory $testData -Force | Out-Null
        & icacls.exe $testData '/inheritance:r' '/grant:r' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F' '*S-1-5-19:(OI)(CI)M'
        if ($LASTEXITCODE -ne 0) { throw 'Permessi archivio di costruzione non impostati.' }
        [IO.File]::WriteAllText($constructionFlag,'Modalita costruzione - archivio di prova separato - '+(Get-Date -Format o))
    }
    & (Join-Path $PSScriptRoot 'InstallaAggiornamenti.ps1') -Root $root
    Copy-Item (Join-Path $PSScriptRoot 'versione.json') $root -Force
    Start-Service VolontariatoLAN; $stopped=$false
    Write-Host 'Aggiornamento completato. Ricarica il gestionale sugli altri PC.' -ForegroundColor Green
    if (Test-Path $constructionFlag) {
        Write-Host 'MODALITA COSTRUZIONE: accesso dal PC senza login, archivio prove separato.' -ForegroundColor Yellow
        Write-Host 'Usa RiattivaLogin.cmd per tornare al login e all archivio ordinario.'
        Start-Process ('https://'+$env:COMPUTERNAME.ToLowerInvariant()+':8765/')
    }
} catch {
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    if ($stopped -and $changed) {
        if (-not $constructionWasEnabled -and (Test-Path $constructionFlag)) { Remove-Item $constructionFlag -Force }
        Copy-Item (Join-Path $old 'Volontariato.Server.exe') $root -Force
        Copy-Item (Join-Path $old 'App\*') (Join-Path $root 'App') -Force
        Copy-Item (Join-Path $old 'Sorgenti\*') (Join-Path $root 'Sorgenti') -Force
        Get-ChildItem (Join-Path $old 'Radice') -File | ForEach-Object {Copy-Item $_.FullName $root -Force}
        Start-Service VolontariatoLAN -ErrorAction SilentlyContinue
        Write-Host 'Ripristinata la versione precedente del programma. Archivio conservato.'
    }
    elseif ($stopped) {Start-Service VolontariatoLAN -ErrorAction SilentlyContinue}
} finally { if (Test-Path $stage) { Remove-Item $stage -Recurse -Force } }
Read-Host 'Premi INVIO per chiudere'
