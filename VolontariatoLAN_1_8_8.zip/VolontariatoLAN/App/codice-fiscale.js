'use strict';
// Calcolo locale del codice base. Nessun dato personale viene inviato a servizi esterni.
const cfBirthFields=[
 F('sex','Sesso anagrafico','select',{options:[['','Da indicare'],['M','Maschile'],['F','Femminile']]}),
 F('birthPlaceType','Luogo di nascita','select',{options:[['Italia','Comune italiano'],['Estero','Stato estero']]}),
 F('birthPlace','Comune / Stato di nascita','text',{help:'Scrivi almeno due caratteri e scegli il luogo dalla ricerca qui sotto.'}),
 F('birthProvince','Provincia di nascita','text',{help:'Sigla della provincia; EE per Stato estero.'}),
 F('birthPlaceCode','Codice catastale del luogo di nascita','text',{help:'Compilato dalla ricerca. Per luoghi non presenti o Stati esteri puoi inserire il codice Belfiore verificato.'})
];
// La scheda e l'inserimento rapido usano gli stessi dieci campi visibili.
// I dati aggiuntivi delle vecchie schede restano conservati dal salvataggio.
schemas.patients=[
 F('surname','Cognome','text',{required:true}),F('name','Nome','text',{required:true}),
 F('birthPlace','Luogo di nascita','patient-birth-place'),F('birthDate','Data di nascita','date'),
 F('taxCode','Codice fiscale','patient-cf',{full:true}),
 F('address','Indirizzo di residenza','text',{full:true}),F('city','Comune di residenza'),
 F('postcode','CAP'),F('phone','Telefono'),F('email','Mail','email')
];
columns.patients[1]=['Nascita',r=>date(r.birthDate)+(r.birthPlace?'<small>'+E(r.birthPlace)+(r.birthProvince?' ('+E(r.birthProvince)+')':'')+'</small>':'')];
importFields.patients.splice(importFields.patients.indexOf('birthDate')+1,0,...cfBirthFields.map(f=>f.key));

function cfSearchText(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[’`´]/g,"'").trim().replace(/\s+/g,' ');}
const cfPlaceIndex=CF_PLACES.map((r,i)=>({id:String(i),name:r[0],province:r[1],code:r[2],from:r[3],to:r[4],search:cfSearchText(r[0]),alias:cfSearchText(r[5])}));
function cfBirthDate(value){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))throw new Error('Inserisci la data di nascita completa.');
 const [y,m,d]=value.split('-').map(Number),dateValue=new Date(0);dateValue.setUTCFullYear(y,m-1,d);dateValue.setUTCHours(0,0,0,0);
 if(y<1||dateValue.getUTCFullYear()!==y||dateValue.getUTCMonth()!==m-1||dateValue.getUTCDate()!==d)throw new Error('Data di nascita non valida.');
 if(value>day())throw new Error('La data di nascita non può essere futura.');
 return {year:y,month:m,day:d};
}
function cfNamePart(value,isName=false){
 const normalized=cfSearchText(value).replace(/Æ/g,'AE').replace(/Œ/g,'OE').replace(/Ø/g,'O').replace(/Ł/g,'L');
 if(!normalized||/[^A-Z '\-.]/.test(normalized))throw new Error('Nome e cognome devono essere completi; per caratteri non latini usa il CF riportato sul documento.');
 const letters=normalized.replace(/[^A-Z]/g,'');if(!letters)throw new Error('Inserisci nome e cognome.');
 const consonants=letters.replace(/[AEIOU]/g,''),vowels=letters.replace(/[^AEIOU]/g,'');
 return isName&&consonants.length>=4?consonants[0]+consonants[2]+consonants[3]:(consonants+vowels+'XXX').slice(0,3);
}
function cfChecksum(first15){
 if(!/^[A-Z0-9]{15}$/.test(first15))throw new Error('Codice fiscale da controllare non valido.');
 const odd=[1,0,5,7,9,13,15,17,19,21,2,4,18,20,11,3,6,8,12,14,16,10,22,25,24,23];
 let total=0;for(let i=0;i<15;i++){const c=first15[i],index=/\d/.test(c)?Number(c):c.charCodeAt(0)-65;total+=i%2?index:odd[index];}
 return String.fromCharCode(65+total%26);
}
function calculateBaseCF(record){
 const birth=cfBirthDate(record.birthDate),sex=String(record.sex||'').toUpperCase();
 if(!['M','F'].includes(sex))throw new Error('Indica il sesso anagrafico per calcolare il CF.');
 const code=String(record.birthPlaceCode||'').trim().toUpperCase();if(!/^[A-Z]\d{3}$/.test(code))throw new Error('Scegli il luogo di nascita o inserisci un codice catastale verificato (una lettera e tre cifre).');
 const first15=cfNamePart(record.surname)+cfNamePart(record.name,true)+String(birth.year).padStart(4,'0').slice(-2)+'ABCDEHLMPRST'[birth.month-1]+String(birth.day+(sex==='F'?40:0)).padStart(2,'0')+code;
 return first15+cfChecksum(first15);
}
function cfPlaceMatches(query,birthDate,province='',exact=false){
 const q=cfSearchText(query),p=cfSearchText(province);if(q.length<2)return [];
 const seen=new Set();return cfPlaceIndex.filter(r=>{
  if(p&&r.province!==p||birthDate&&(birthDate<r.from||birthDate>r.to))return false;
  if(exact?r.search!==q&&r.alias!==q:!r.search.includes(q)&&!r.alias.includes(q))return false;
  const key=r.name+'|'+r.province+'|'+r.code;if(seen.has(key))return false;seen.add(key);return true;
 }).sort((a,b)=>(a.search===q?0:1)-(b.search===q?0:1)||a.name.localeCompare(b.name,'it')||a.province.localeCompare(b.province));
}
function resolveCFPlace(record,manualConfirmed=false){
 cfBirthDate(record.birthDate);
 if(!String(record.birthPlace||'').trim())throw new Error('Indica il comune o lo Stato di nascita.');
 const type=record.birthPlaceType||'Italia',code=String(record.birthPlaceCode||'').trim().toUpperCase();
 if(type==='Italia'){
  const matches=cfPlaceMatches(record.birthPlace,record.birthDate,record.birthProvince,true),codes=[...new Set(matches.map(r=>r.code))];
  const choice=code?matches.find(r=>r.code===code):codes.length===1?matches[0]:null;
  if(choice)return {...record,birthPlace:choice.name,birthProvince:choice.province,birthPlaceCode:choice.code};
  if(!manualConfirmed)throw new Error(matches.length?'Luogo ambiguo: scegli il comune corretto dalla ricerca.':'Comune non trovato alla data indicata: cerca la denominazione storica oppure conferma un codice catastale verificato.');
 }else if(type!=='Estero')throw new Error('Tipo di luogo di nascita non valido.');
 if(!manualConfirmed)throw new Error('Per lo Stato estero conferma il codice catastale verificato.');
 if(!/^[A-Z]\d{3}$/.test(code)||type==='Estero'&&!/^Z\d{3}$/.test(code))throw new Error('Codice catastale non valido; per gli Stati esteri inizia con Z.');
 return {...record,birthPlaceCode:code,birthProvince:type==='Estero'?'EE':String(record.birthProvince||'').trim().toUpperCase()};
}
const beforeCFFormFields=formFields;
formFields=function(fields,record={}){return fields.map(f=>{
 if(f.type==='patient-birth-place')return `<div class="patient-birth-field"><label>${E(f.label)}<input name="birthPlace" type="text" value="${E(record.birthPlace||'')}" maxlength="150" autocomplete="off"></label><div id="cf-place-results" class="patient-place-results"></div>${['sex','birthPlaceType','birthProvince','birthPlaceCode'].map(key=>`<input name="${key}" type="hidden" value="${E(record[key]||(key==='birthPlaceType'?'Italia':''))}">`).join('')}</div>`;
 if(f.type==='patient-cf')return `<div class="full"><div class="patient-cf-row"><label>Codice fiscale<input name="taxCode" type="text" value="${E(record.taxCode||'')}" maxlength="16" autocomplete="off"></label><button type="button" data-action="patient-calculate-cf">Calcola CF</button></div><div id="cf-tools" hidden></div><div id="cf-result" class="form-help" role="status" aria-live="polite"></div></div>`;
 return beforeCFFormFields([f],record);
 }).join('');};
const beforeCFCollect=collect;
collect=function(form,fields,base={}){const record=beforeCFCollect(form,fields,base);if(fields.some(f=>f.type==='patient-cf'))for(const key of ['sex','birthPlaceType','birthProvince','birthPlaceCode'])record[key]=String(form.elements[key]?form.elements[key].value:base[key]||'').trim();return record;};
function cfToolsHTML(record={},manual=false){return `<section class="notice info"><strong>Calcola CF</strong><p>Indica il sesso anagrafico necessario per il calcolo.</p><label>Sesso anagrafico<select name="cfCalculationSex">${options([['','Da indicare'],['M','Maschile'],['F','Femminile']],record.sex||'',false)}</select></label>${manual?`<p>Luogo non risolto dalla ricerca: indica un codice catastale verificato.</p><div class="form-grid"><label>Comune italiano / Stato estero<select name="cfCalculationType">${options(['Italia','Estero'],record.birthPlaceType||'Italia',false)}</select></label><label>Codice catastale verificato<input name="cfCalculationCode" value="${E(record.birthPlaceCode||'')}" maxlength="4"></label></div><label><input name="cfManualConfirmed" type="checkbox" style="width:auto"> Ho verificato il codice catastale.</label>`:'<input name="cfManualConfirmed" type="hidden" value="">'}<div class="actions" style="margin-top:12px"><button type="button" data-action="patient-confirm-cf">Conferma e calcola CF</button><button type="button" data-action="patient-cancel-cf">Annulla calcolo</button></div><small>Il codice base proposto va confrontato con la tessera sanitaria, anche in caso di omocodia.</small></section>`;}
function cfReadForm(form){return Object.fromEntries(['surname','name','birthDate','sex','birthPlaceType','birthPlace','birthProvince','birthPlaceCode','taxCode'].map(key=>[key,String(form.elements[key]?.value||'').trim()]));}
function cfRefreshPlaces(form){
 const record=cfReadForm(form),target=form.querySelector('#cf-place-results');if(!target)return;
 if(!record.birthDate){target.textContent=record.birthPlace?'Inserisci la data di nascita per cercare il comune.':'';return;}
 try{cfBirthDate(record.birthDate);}catch(ex){target.textContent=ex.message;return;}
 const matches=cfPlaceMatches(record.birthPlace,record.birthDate,record.birthProvince);
 target.innerHTML=matches.slice(0,8).map(r=>`<button type="button" data-action="patient-select-birthplace" data-id="${r.id}">${E(r.name)} (${E(r.province)})</button>`).join(' ')+(matches.length>8?'<p>Molti risultati: precisa il nome del comune.</p>':'');
 if(record.birthPlace.length>=2&&!matches.length)target.textContent='Nessun comune trovato per questa data/provincia. Puoi usare la denominazione storica o un codice catastale verificato.';
}
function mountPatientCF(form){
 if(!form||!canBill()||form._record?.archived)return;
 if(!form.elements.birthPlaceType.value)form.elements.birthPlaceType.value='Italia';
 for(const key of ['birthPlace','birthDate'])form.elements[key].addEventListener('input',()=>{
  form.elements.birthPlaceCode.value='';form.elements.birthProvince.value='';form.elements.birthPlaceType.value='Italia';form._cfSelected=false;
  const tools=form.querySelector('#cf-tools');tools.hidden=true;tools.innerHTML='';
  cfRefreshPlaces(form);const result=form.querySelector('#cf-result');if(result)result.textContent='Dati di nascita modificati: ricalcola il CF quando necessario.';
 });
 for(const key of ['surname','name'])form.elements[key].addEventListener('input',()=>{const result=form.querySelector('#cf-result');if(result)result.textContent='Dati anagrafici modificati: ricalcola il CF quando necessario.';});
 cfRefreshPlaces(form);
}
function applyCalculatedCF(form){
 if(!canBill()||form._record?.archived)throw new Error('Scheda non modificabile.');
 const resolved=resolveCFPlace(cfReadForm(form),!!form.elements.cfManualConfirmed?.checked),code=calculateBaseCF(resolved);
 const duplicate=state.tables.patients.find(p=>p.id!==form._record?.id&&String(p.taxCode||'').trim().toUpperCase()===code);
 if(duplicate)throw new Error('CF già presente per '+duplicate.surname+' '+duplicate.name+': richiama la scheda esistente oppure verifica il CF attribuito alla persona.');
 const old=String(form.elements.taxCode.value||'').trim().toUpperCase();
 if(old&&old!==code&&!confirm('CF presente: '+old+'\nCF calcolato: '+code+'\nVuoi sostituirlo? Confronta prima il codice con la tessera sanitaria.'))return false;
 for(const key of ['birthPlace','birthProvince','birthPlaceCode'])form.elements[key].value=resolved[key];
 form.elements.taxCode.value=code;form.elements.taxCode.dispatchEvent(new Event('input',{bubbles:true}));
 const result=form.querySelector('#cf-result');if(result)result.textContent='CF proposto: '+code+'. Verifica sulla tessera sanitaria e salva la scheda.';
 return true;
}
const beforeCFEdit=edit;edit=function(table,id,override){beforeCFEdit(table,id,override);if(table==='patients')mountPatientCF($('#record-form'));};
const beforeCFQuickPatient=quickPatientForBooking;quickPatientForBooking=function(){beforeCFQuickPatient();const f=$('#quick-patient-form');if(f)mountPatientCF(f);};
document.addEventListener('click',ev=>{
 const button=ev.target.closest('[data-action]');if(!button||!['patient-calculate-cf','patient-select-birthplace','patient-confirm-cf','patient-cancel-cf'].includes(button.dataset.action))return;
 const form=button.closest('form');if(!form||busy)return;
 try{
  if(!canBill()||form._record?.archived)throw new Error('Scheda non modificabile.');
  if(button.dataset.action==='patient-calculate-cf'){
   const record=cfReadForm(form);cfBirthDate(record.birthDate);if(!record.birthPlace)throw new Error('Inserisci il luogo di nascita.');
   let manual=false;try{const resolved=resolveCFPlace(record);for(const key of ['birthPlace','birthProvince','birthPlaceCode'])form.elements[key].value=resolved[key];}catch{manual=true;}
   const tools=form.querySelector('#cf-tools');tools.innerHTML=cfToolsHTML(cfReadForm(form),manual);tools.hidden=false;
  }else if(button.dataset.action==='patient-confirm-cf'){
   form.elements.sex.value=form.elements.cfCalculationSex.value;
   if(form.elements.cfCalculationCode){form.elements.birthPlaceType.value=form.elements.cfCalculationType.value;form.elements.birthPlaceCode.value=form.elements.cfCalculationCode.value.trim().toUpperCase();form.elements.birthProvince.value=form.elements.birthPlaceType.value==='Estero'?'EE':'';}
   if(applyCalculatedCF(form)){const tools=form.querySelector('#cf-tools');tools.hidden=true;tools.innerHTML='';}
  }else if(button.dataset.action==='patient-cancel-cf'){const tools=form.querySelector('#cf-tools');tools.hidden=true;tools.innerHTML='';}
  else {const place=cfPlaceIndex.find(r=>r.id===button.dataset.id);if(!place)throw new Error('Luogo non trovato.');
   const birthDate=form.elements.birthDate.value;if(!birthDate||birthDate<place.from||birthDate>place.to)throw new Error('Luogo non valido alla data di nascita indicata.');
   form.elements.birthPlaceType.value='Italia';form.elements.birthPlace.value=place.name;form.elements.birthProvince.value=place.province;form.elements.birthPlaceCode.value=place.code;form._cfSelected=true;const tools=form.querySelector('#cf-tools');tools.hidden=true;tools.innerHTML='';cfRefreshPlaces(form);
  }
 }catch(ex){const result=form.querySelector('#cf-result');if(result)result.textContent=ex.message;else toast(ex.message,true);}
});

init();
