﻿# Non crea una VPN. Autorizza un gruppo di indirizzi della VPN gia configurata.
$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""; exit }
$root=Join-Path $env:ProgramData 'VolontariatoLAN'
try {
    if (-not (Get-Service VolontariatoLAN -ErrorAction SilentlyContinue)) { throw 'Installa prima il server.' }
    $config=Get-Content (Join-Path $root 'Postazioni\Sede.json') -Raw | ConvertFrom-Json
    Write-Host 'Per l accesso fuori sede deve gia esistere una VPN sul router/rete della sede.'
    Write-Host 'Non aprire la porta 8765 direttamente su Internet. Questo script non configura router o VPN.'
    $cidr=Read-Host 'Subnet IPv4 privata assegnata ai telefoni dalla VPN, ad esempio 10.8.0.0/24'
    $parts=$cidr.Split('/')
    $ip=$null; $prefix=0
    if ($parts.Length -ne 2 -or -not [Net.IPAddress]::TryParse($parts[0],[ref]$ip) -or -not [int]::TryParse($parts[1],[ref]$prefix) -or $prefix -lt 8 -or $prefix -gt 32 -or $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) { throw 'Inserisci una subnet IPv4 CIDR valida e limitata (prefisso da /8 a /32).' }
    $octets=$ip.GetAddressBytes()
    $private=($octets[0] -eq 10 -and $prefix -ge 8) -or ($octets[0] -eq 172 -and $octets[1] -ge 16 -and $octets[1] -le 31 -and $prefix -ge 12) -or ($octets[0] -eq 192 -and $octets[1] -eq 168 -and $prefix -ge 16) -or ($octets[0] -eq 100 -and $octets[1] -ge 64 -and $octets[1] -le 127 -and $prefix -ge 10)
    if (-not $private) { throw 'Usa il pool privato della VPN della sede; non un indirizzo pubblico.' }
    $addresses=@($config.addresses)
    if ($addresses.Count -eq 0) { throw 'Nessun indirizzo IPv4 esportato all installazione. Verifica la configurazione di rete.' }
    for($i=0;$i -lt $addresses.Count;$i++){Write-Host "$($i+1): $($addresses[$i])"}
    $n=0
    if (-not [int]::TryParse((Read-Host 'Numero dell indirizzo LAN del centrale raggiungibile dalla VPN'),[ref]$n) -or $n -lt 1 -or $n -gt $addresses.Count) { throw 'Selezione non valida.' }
    $url="https://$($addresses[$n-1]):8765/?mobile=1"
    Write-Host "Sara autorizzata la subnet $cidr sul profilo rete Privato per HTTPS 8765."
    if ((Read-Host 'Scrivi CONFIGURA per procedere') -ne 'CONFIGURA') { exit }
    if (Get-NetFirewallRule -Name 'VolontariatoLAN-VPN' -ErrorAction SilentlyContinue) { Get-NetFirewallRule -Name 'VolontariatoLAN-VPN' | Get-NetFirewallAddressFilter | Set-NetFirewallAddressFilter -RemoteAddress $cidr | Out-Null } else { New-NetFirewallRule -Name 'VolontariatoLAN-VPN' -DisplayName 'Volontariato LAN - utenti tramite VPN della sede' -Direction Inbound -Protocol TCP -LocalPort 8765 -Action Allow -Profile Private -RemoteAddress $cidr | Out-Null }
    $mobile=Join-Path $root 'Mobile'
    New-Item -ItemType Directory -Path $mobile -Force | Out-Null
    Copy-Item (Join-Path $root 'Postazioni\CertificatoSede.cer') $mobile -Force
    @("APP VOLONTARIATO - ACCESSO UTENTE","Indirizzo: $url","Impronta certificato: $($config.thumbprint)",'Installa e considera attendibile il certificato della sede sul telefono secondo le istruzioni del tuo sistema.','Collegati alla VPN della sede, apri l indirizzo e accedi con account volontario collegato alla sua anagrafica.','Aggiungi il collegamento alla schermata iniziale dal browser.','La VPN/router e la fiducia del certificato sul telefono devono essere configurati e collaudati a parte.','Non utilizzare credenziali amministratore sul telefono.') | Set-Content (Join-Path $mobile 'AccessoMobile.txt') -Encoding UTF8
    $payloadId=[Guid]::NewGuid().ToString()
    $profileId=[Guid]::NewGuid().ToString()
    $cert64=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $mobile 'CertificatoSede.cer')))
    $profile=@"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>PayloadType</key><string>Configuration</string><key>PayloadVersion</key><integer>1</integer>
<key>PayloadIdentifier</key><string>it.volontariato.sede.$profileId</string><key>PayloadUUID</key><string>$profileId</string>
<key>PayloadDisplayName</key><string>Volontariato - certificato della sede</string><key>PayloadRemovalDisallowed</key><false/>
<key>PayloadContent</key><array><dict>
<key>PayloadType</key><string>com.apple.security.root</string><key>PayloadVersion</key><integer>1</integer>
<key>PayloadIdentifier</key><string>it.volontariato.cert.$payloadId</string><key>PayloadUUID</key><string>$payloadId</string>
<key>PayloadDisplayName</key><string>Volontariato LAN - autorita della sede</string>
<key>PayloadCertificateFileName</key><string>CertificatoSede.cer</string><key>PayloadContent</key><data>$cert64</data>
</dict></array></dict></plist>
"@
    [IO.File]::WriteAllText((Join-Path $mobile 'CertificatoSede.mobileconfig'),$profile,[Text.Encoding]::UTF8)
    Write-Host "Materiale per il telefono: $mobile" -ForegroundColor Green
    Write-Host "Indirizzo app: $url"
    Write-Host 'Ora collauda l accesso con il Wi-Fi del telefono disattivato e la VPN attiva.'
} catch { Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red }
Read-Host 'Premi INVIO per chiudere'
